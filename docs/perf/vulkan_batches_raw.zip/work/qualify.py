from pathlib import Path
import os,subprocess,sys
r=Path(__file__).resolve().parent.parent;o=r/'build-vector-batchopt'
sys.path.insert(0,str(r/'tools'));from run_tests import import_msvc_env
tmp=o/'tmp';tmp.mkdir(exist_ok=True);os.environ['TEMP']=os.environ['TMP']=str(tmp)
import_msvc_env();os.environ['VULKAN_SDK']='E:/VulkanSDK/1.4.335.0'
os.environ['CMAKE_BUILD_PARALLEL_LEVEL']='4'
os.environ['PATH']=str(r/'build-perf-review/format-tool/clang_format/data/bin')+os.pathsep+os.environ['PATH']
for configuration,flags in [('release',['--release']),('debug',[])]:
 print('Starting full',configuration,flush=True)
 with (o/('full-'+configuration+'.log')).open('w') as log:
  p=subprocess.run([sys.executable,'tools/run_tests.py','--vulkan','--format',*flags],cwd=r,stdout=log,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError(configuration+' full suite failed')
 print('Full',configuration,'passed',flush=True)
