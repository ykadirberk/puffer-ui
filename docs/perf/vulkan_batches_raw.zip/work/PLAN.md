# Lossless native vector batching and staged uploads

Base: 48db13f08a2b897f37ffe381b31391c6cfd4721b. All 32 unrelated drafts
are hash-protected. Existing tests, shader bytes and golden references stay fixed.

1. Consolidate slot-owned STAGED geometry copies before its graphics command
   buffer, with one transfer-to-input dependency. Include upload in timestamps.
   Preserve bounded streaming, serial ownership, direct uploads and error policy.
2. Batch isolated Slug scenes in bounded prepared layer tiles. Preserve original
   Slug operands, integer pixel centers, blend order and per-instance clipping.
   Prepare all CPU/GPU storage outside drawing; retain immediate fallback.
3. Add independent regressions for exact pixels, overlap/order, clipping,
   lifecycle, tiny budgets/streaming, allocation freedom and command counts.
4. Alternate frozen baseline/candidate readback-free Release workloads: all
   180 frames, 5000-item Spiral direct/staged/cache/null and composed SVG.
   Keep setup/cold/all outliers. Compare all frames with immutable RGBA references.
5. Run full unchanged Debug/Release Vulkan/format/consumer/example suites,
   actual pui_showcase_vulkan checks, update docs/report and commit scoped files.
