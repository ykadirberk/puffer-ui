from pathlib import Path
import subprocess,sys,os,hashlib,json
r=Path(__file__).resolve().parent.parent;o=r/'build-vector-batchopt'
tmp=o/'tmp';tmp.mkdir(exist_ok=True);os.environ['TEMP']=os.environ['TMP']=str(tmp)
def run(name,args):
 print(name,flush=True)
 with (o/(name+'.log')).open('w') as log:
  subprocess.run([str(x) for x in args],cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
for mode,flags in [('direct',[]),('staged',['--staged'])]:
 run('final2-regressions-'+mode,[r/'out/build/x64-release/Release/pui_vulkan_batch_tests.exe',*flags])
run('measure-02',[sys.executable,r/'tools/compare_vulkan_batches.py','--before',o/'before','--after',r/'out/build/x64-release/Release','--spiral-references',r/'build-vulkan-gaussian-fix','--vector-references',r/'tests/golden/vector_batch/frames.zip','--output',o/'measure-02','--pairs','8'])
run('ablation-02',[sys.executable,o/'ablation.py','ablation-02','measure-02'])
run('summary-final',[sys.executable,o/'summarize.py','measure-02','ablation-02'])
sources={p.relative_to(r).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for directory in ['include','src','examples','tests','tools'] for p in (r/directory).rglob('*') if p.is_file() and p.suffix in ['.h','.inl','.cpp','.vert','.frag','.glsl','.py','.ps1'] and '__pycache__' not in p.parts}
(o/'timed-sources-final.json').write_text(json.dumps(sources,indent=2))
run('qualify',[sys.executable,o/'qualify.py'])
