# Active task checkpoint (2026-11-04)

User asks: optimize native Slug 480-draw GPU cost and STAGED 5000-item Spiral
without visual changes; add regressions, before/after measurements, all-frame
goldens, commit. User reiterated no permission needed and final actual showcase
check. No push requested. Do not spawn subagents. Latest AGENTS user message
includes our batch documentation section. Preserve all 32 unrelated drafts.

Base/current HEAD: 48db13f08a2b897f37ffe381b31391c6cfd4721b, branch
codex/vulkan-native-harfbuzz. No commit yet for this task. Previous goal COMPLETE
belongs to previous feature; do not create/update a goal for this ordinary task.

Implemented and frozen:
- frame_slot.uploads second primary buffer STAGED; one copy per populated
  append-only page at submit, transfer/input barrier, submit upload then graphics
  with same serial. Timestamps start before upload. Removed per-draw copy/barriers
  from shape/text/vector paths. Direct input and all shaders unchanged.
- Prepared isolated Slug scene tiles (max16), original absolute pixel centers,
  clip/paint/Slug operands and final overlap order. 480->30 draws. Only already
  isolated roots batched; original immediate fallback remains. Fixed CPU scratch,
  actual-alignment/budget fallback, no per-draw allocations. Last refinement keeps
  hot fields before arrays and uses immutable asset identity to avoid a separate
  simple-path scene-count branch. Final source hashes timed-sources-final.json.
- New vulkan_vector_batch.inl; test_vulkan_batch.cpp required command/count,
  streaming, overlap, mixed simple/composed, clips/reflection/1x-4x DPI and budget
  regressions. Native registry +2 ->55 cases. Three new Python tool tests ->22.
- tools/compare_vulkan_batches.py; tests/golden/vector_batch/frames.zip (2.7MB)
  all180 immutable base SVG RGBA frames (direct/staged identical), receipt+README.
- Docs vector_paths.md/vulkan.md/AGENTS updated, new perf_vulkan_batches.md
  measurements filled; VALIDATION_PENDING/EVIDENCE_PENDING must finish.

Validation so far:
- Final new direct/staged regression suites pass.
- Final measurement measure-02:144 runs/25920 frames and2880 exact golden
  comparisons (2160 oldSpiral incl late+cache,720 newSVG all180 per mode/cache).
  Baseline capture360 + identity360 done. No --update ever used.
- Final ablation-02:36 runs/6480 frames, baseline/uploads-only/combined.
- Previous candidate measure-01+ablation:32400 frames retained. simple-recheck
  eight runs1440; initial batch diagnostic2 runs360. Total timed66600 to package.
- Source audit passes:124 existing test/oracle files unchanged,32 drafts,
  all238 measured source files unchanged,11 shader files exact,360 old refs exact,
  SDL submodule clean. New untracked C++ files manual clang22.1.3 dryrun passed.
- Full Release --vulkan --format --release PASSED, all consumers/examples etc.
- Full Debug PASSED (qualify.py session3065), all steps including55native cases,
  examples/consumers/goldens/API/tutorial/format. Full Release also PASSED.
  qualify.log/full-debug.log certify completion. Do NOT overlap builds/tests.
- finish_validation.py waits for 'Full debug passed', then sequentially runs
  remaining_checks.py and showcase_checks.py. Session33076. finish-validation.log.
  Remaining checks CURRENTLY running: core-off passed, HBOFF native builds near
  final links, then indexed staged/tutorial and single-header native consumer.
  Remaining checks: old build-vector-paths core-off/HBOFF indexed staged/tutorial,
  actual generated single native/HB/STAGED header consumer. May need fixing that
  new ignored consumer if compile issue (do not alter existing tests).
  Showcase script1080 frames:before/after180SVG,640SVG,5000Spiral noHUD,3 full BMP
  pairs must exact; creates showcase-final.json. Strict fresh folder requirement.
- Full suites/remaining checks use task/tmp TEMP/TMP; default sandbox temp had
  access errors. MSVC wrapper build-vulkan-startup-opt/build.py. Python cache path.

Final measured values (summary.json/summary-final.log authoritative):
case: CPU before/after; GPU before/after ms
null2.926105/2.984993 (+2.01%)
spiral direct plain3.573884/3.608540; .644265/.647813
direct cache3.597092/3.641350; .641514/.633321
staged plain3.683561/3.633759(-1.35%);1.021057/.782446(-23.37%)
staged cache3.664592/3.675818(+.31%);1.020552/.784887(-23.09%)
vector direct complex3.315675/1.116484;3.316263/1.093559(-67.02%)
vector staged complex4.586741/1.082636;4.601710/1.047876(-77.23%)
simple direct CPU .799187/.822605(+2.93%), GPU flat .267314/.267821
simple staged CPU .797884/.812815(+1.87%), GPU .271273/.273737
STAGED cache worst INCREASE17.1673->18.6338; plain worst18.7954->17.9027.
Do NOT claim universal CPU/peak win or fully explain residual differences.
Null .text/.data/.pdata byte exact; rdata only3 debug timestamp bytes differ,
proving external timing variability but no normalization justified.
Final ablation vector staged GPU4.584421->3.051296 uploads-only->.964614 combined.
Current driver8389024 vs previous report8388996; frozen baseline remeasured current.
Images composed1253632->4325632 (+3072000 bytes~2.93MiB); path233728->3324032
(extra18304 CPU scratch). All within unchanged64MiB cache; simple no layerimages,
oldSpiral no vectorassets. Upload budgets equal. Logical upload bytes unchanged;
wholepage copies include <=31byte alignment holes per append. Allocation claims
are C++draw/flush and renderer upload buffers, not entire driver allocations.

Remaining work:
1. Wait full Debug and remaining/showcase checks (3065/33076); inspect every error.
2. Final live actual pui_showcase_vulkan inspection (default and --vectors with
   opacity/rotation; can also SDL demo smoke per AGENTS). Computer Use skill read
   fully this task: ...openai-bundled/computer-use/26.1027.30824/skills/computer-use/
   SKILL.md and docs guidance/api/confirmations. Use ONLY node_repl @oai/sky for
   UI inputs. Tool tools.mcp__node_repl__js available, discover if needed.
   No Sky calls this task yet; globals may be from previous goal CLOSED windows.
   Initialize sky if absent, list_windows/select exactly one returned window;
   one input + refresh each. No terminal/ChatGPT/Codex UI automation. For --vectors
   args launch actual exe via CLI Popen then select Sky returned window (Sky
   launch_app lacks args). Close normally Alt+F4; no user process killing.
   Write task/live-check.json completed true with honest observed details.
   No foreground FPS claim from offscreen timing or live visual observation.
3. Finish docs validation/evidence placeholders after passes (55cases/config,
   22tools,all existing tests fixed, total66600 frames and final2880 golden).
4. Run audit.py again after all checks (assert all measured code unchanged).
5. package.py gated on fullRelease/Debug,remaining,showcase,live and noPENDING.
   Produces docs/perf/vulkan_batches.{json,_frames.csv.gz,_raw.zip,_bundle.json}.
   Includes all66600 frames, prior candidate/ablation, rejected attempts/logs.
   Update report evidence links before packaging (raw contains report).
6. Scoped diff/review then commit ONLY21 task files; .git read-only sandbox so
   require_escalated for git add/commit with explicit list. User authorized.
   Suggested: perf(vulkan): batch isolated Slug scenes and consolidate staged uploads
   Do not add32 unrelated drafts. No push.
7. Append roadmap outsideworkspace via require_escalated allowed by AGENTS old
   on-disk instructions: C:/Users/Kadir Berk/.opencode/plan/pufferui-roadmap.md.
   Record commit/test/measured caveats. Verify status, draft hashes, commit.
8. Final Turkish outcome+hash, GPU table, mixedCPU/peak/memory caveats, exactpixels,
   tests+report links. Memory used registry MEMORY.md:351-353 from previous runs;
   append exact memory citation block last, rollout01a14f95-edf4-7610-80c9-d9095bdb1ee6.

Tools/processes:
Python C:/Users/Kadir Berk/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe
SDK E:/VulkanSDK/1.4.335.0; clang build-perf-review/format-tool/clang_format/data/bin
Use login:false, PYTHONUTF8=1 for Unicode report helpers. Task folder ignored.
No overlapping performance/build. All measurements complete; do not redo unless
source changes. Do not change implementation again just to chase noisy <3%CPU.
One earlier full suite intentionally interrupted for queue refinement; one early
reference-only launch overlapped linking and was stopped BEFOREtiming. Preserve
logs, exclude passcounts; report already transparently records.
