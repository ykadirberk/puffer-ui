from pathlib import Path
import csv,gzip,hashlib,json,statistics,sys
r=Path(__file__).resolve().parent.parent;o=r/'build-vector-batchopt';sys.path.insert(0,str(r/'tools'))
from compare_vulkan_batches import distribution
measurement=sys.argv[1] if len(sys.argv)>1 else 'measure-01'
ablation_name=sys.argv[2] if len(sys.argv)>2 else 'ablation'
main=json.loads((o/measurement/'receipt.json').read_text());ablation=json.loads((o/ablation_name/'receipt.json').read_text())
summary={'base_commit':json.loads((o/'baseline.json').read_text())['commit'],'hardware':{'name':'AMD Radeon RX 9070 XT','vendor':4098,'device':30032,'driver':8389024},'cases':{},'ablation':{},'runs':main['runs'],'ablation_runs':ablation['runs'],'goldens':main['goldens'],'reference_hashes':main['reference_hashes'],'binaries':main['binaries'],'ablation_binaries':ablation['binaries'],'frame_records':0}
records=[]
for group,receipt,folder in [('main',main,o/measurement),('ablation',ablation,o/ablation_name)]:
 for case in sorted({run['case'] for run in receipt['runs']}):
  values={}
  for label in sorted({run['revision'] for run in receipt['runs'] if run['case']==case}):
   runs=[run for run in receipt['runs'] if run['case']==case and run['revision']==label]
   allrows=[]
   for run in runs:
    rows=list(csv.DictReader((folder/(run['name']+'.csv')).open()))
    for row in rows:
     record={'group':group,'case':case,'revision':label,'run':run['name'],**row};records.append(record);allrows.append(record)
   times=[float(row['total_ms']) for row in allrows]
   info={'wall':distribution(times),'cold_median_ms':statistics.median(run['summary']['cold_ms'] for run in runs),'peak_frames':sorted([{'run':row['run'],'frame':int(row['frame']),'ms':float(row['total_ms'])} for row in allrows],key=lambda x:x['ms'],reverse=True)[:20]}
   for field in ['setup_ms','path_residency_bytes','image_bytes']:
    if field in runs[0]['summary']:info[field]=statistics.median(run['summary'][field] for run in runs)
   if 'gpu_total_ms' in runs[0]['summary']:info['gpu_mean_ms']=statistics.mean(run['summary']['gpu_total_ms']/180 for run in runs)
   for field in ['draws','upload_bytes','total_upload_bytes','resident_bytes','submit_ms','slot_wait_ms','draw_cpp_allocations','draw_buffer_allocations']:
    if field in allrows[0]:info[field]=distribution([float(row[field]) for row in allrows])
   values[label]=info
  if group=='main':
   a,b=values['before'],values['after'];values['wall_change_percent']=(b['wall']['mean']/a['wall']['mean']-1)*100
   if 'gpu_mean_ms' in a:values['gpu_change_percent']=(b['gpu_mean_ms']/a['gpu_mean_ms']-1)*100
   before={run['pair']:run for run in receipt['runs'] if run['case']==case and run['revision']=='before'}
   changes=[(run['summary']['wall']['mean']/before[run['pair']]['summary']['wall']['mean']-1)*100 for run in receipt['runs'] if run['case']==case and run['revision']=='after']
   values['paired_cpu_changes_percent']=changes;values['median_paired_cpu_change_percent']=statistics.median(changes)
  summary['cases' if group=='main' else 'ablation'][case]=values
summary['frame_records']=len(records)
fields=['group','case','revision','run','frame','total_ms']+sorted(set().union(*(set(row) for row in records))-{'group','case','revision','run','frame','total_ms'})
with gzip.open(o/'frames.csv.gz','wt',newline='') as file:
 writer=csv.DictWriter(file,fieldnames=fields);writer.writeheader();writer.writerows(records)
(o/'summary.json').write_text(json.dumps(summary,indent=2))
for case,values in summary['cases'].items():
 a,b=values['before'],values['after'];print(case,'CPU',round(a['wall']['mean'],6),'->',round(b['wall']['mean'],6),f"{values['wall_change_percent']:+.2f}%",'GPU',round(a.get('gpu_mean_ms',0),6),'->',round(b.get('gpu_mean_ms',0),6),'max',round(a['wall']['maximum'],4),'->',round(b['wall']['maximum'],4))
print('Ablation:')
for case,values in summary['ablation'].items():
 print(case,[(k,round(v['wall']['mean'],6),round(v['gpu_mean_ms'],6)) for k,v in values.items()])
print(len(records),'retained frame rows')
