from pathlib import Path
import csv,gzip,hashlib,io,json,zipfile,shutil
r=Path(__file__).resolve().parent.parent;o=r/'build-vector-batchopt';dest=r/'docs/perf'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['full-release.log','full-debug.log']:
 assert 'all steps passed' in (o/name).read_text(encoding='utf-8',errors='replace'),name
assert 'Dependency-OFF boundaries and native STAGED Slug amalgamation consumer passed' in (o/'remaining-checks.log').read_text(encoding='utf-8',errors='replace')
assert json.loads((o/'showcase-final.json').read_text())['all_exact']
assert json.loads((o/'live-check.json').read_text())['application_frame_review_passed']
assert 'PENDING' not in (r/'docs/perf_vulkan_batches.md').read_text(encoding='utf-8')
summary=json.loads((o/'summary.json').read_text());prototype=json.loads((o/'candidate1-summary.json').read_text())
summary['first_candidate_cases']=prototype['cases'];summary['first_candidate_ablation']=prototype['ablation']
summary['protected']=json.loads((o/'protected-audit.json').read_text())
summary['timed_source_hashes']=json.loads((o/'timed-sources-final.json').read_text())
summary['null_code_control']=json.loads((o/'null-code-control.json').read_text())
summary['showcase']=json.loads((o/'showcase-final.json').read_text())
summary['live']=json.loads((o/'live-check.json').read_text())
summary['validation_date']='2026-11-04'
records=[]
for dataset,file in [('final',o/'frames.csv.gz'),('first_candidate',o/'candidate1-frames.csv.gz')]:
 with gzip.open(file,'rt') as f:
  records += [{'dataset':dataset,**row} for row in csv.DictReader(f)]
for file in sorted((o/'simple-recheck').glob('*.csv')):
 with file.open() as f:
  records += [{'dataset':'simple_recheck','group':'diagnostic','run':file.stem,**row} for row in csv.DictReader(f)]
for file in [o/'batch-diagnostic.csv',o/'batch-diagnostic-staged.csv']:
 with file.open() as f:
  records += [{'dataset':'initial_diagnostic','group':'diagnostic','run':file.stem,**row} for row in csv.DictReader(f)]
summary['retained_timed_frames']=len(records)
fields=['dataset','group','case','revision','run','frame','total_ms']+sorted(set().union(*(set(row) for row in records))-{'dataset','group','case','revision','run','frame','total_ms'})
with gzip.open(dest/'vulkan_batches_frames.csv.gz','wt',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(records)
(dest/'vulkan_batches.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
raw=dest/'vulkan_batches_raw.zip'
with zipfile.ZipFile(raw,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(o.rglob('*')):
  if not p.is_file() or p.suffix not in ['.csv','.json','.log','.py','.md','.cpp','.patch']:continue
  rel=p.relative_to(o)
  if any(part in ['baseline','tmp','vector-references'] for part in rel.parts):continue
  if p.name=='pufferui_single.h':continue
  archive.write(p,'work/'+rel.as_posix())
 for p in [r/'tools/compare_vulkan_batches.py',r/'tests/test_vulkan_batch.cpp',r/'tests/test_vulkan_batch_tools.py',r/'tests/golden/vector_batch/README.md',r/'docs/perf_vulkan_batches.md']:
  archive.write(p,'source/'+p.relative_to(r).as_posix())
 for p in sorted((o/'showcase-final').glob('*-after.bmp')):
  archive.write(p,'application-frames/'+p.name)
for p in [raw,dest/'vulkan_batches.json',dest/'vulkan_batches_frames.csv.gz',r/'tests/golden/vector_batch/frames.zip']:
 print(p.relative_to(r),p.stat().st_size,sha(p))
(dest/'vulkan_batches_bundle.json').write_text(json.dumps({p.relative_to(r).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in [raw,dest/'vulkan_batches.json',dest/'vulkan_batches_frames.csv.gz',r/'tests/golden/vector_batch/frames.zip']},indent=2))
print('Retained',len(records),'timed frames; package gates passed')
