from pathlib import Path
import os,subprocess,sys,json,hashlib
r=Path(__file__).resolve().parent.parent;o=r/'build-vector-batchopt'
sys.path.insert(0,str(r/'tools'));from run_tests import import_msvc_env
os.environ['TEMP']=os.environ['TMP']=str(o/'tmp');import_msvc_env()
os.environ['VULKAN_SDK']='E:/VulkanSDK/1.4.335.0';os.environ['CMAKE_BUILD_PARALLEL_LEVEL']='4'
def run(*args):
 print(' '.join(map(str,args)),flush=True);subprocess.run(list(map(str,args)),cwd=r,check=True)
core=r/'build-vector-paths/core-off'
run('cmake','--build',core,'--target','pui_core_tests','pui_vector_tests')
run(core/'Release/pui_core_tests.exe');run(core/'Release/pui_vector_tests.exe')
native=r/'build-vector-paths/native-offhb'
run('cmake','--build',native,'--target','pui_vulkan_tests','pui_vulkan_indexed_tests','pui_tut_vector_manual')
run(native/'Release/pui_vulkan_tests.exe');run(native/'Release/pui_vulkan_indexed_tests.exe','--staged')
run(native/'Release/pui_tut_vector_manual.exe','--selftest','--frames','8','--resize','800x560')
run('pwsh','-NoProfile','-File','tools/amalgamate.ps1','-Out',o/'pufferui_single.h')
consumer=o/'single_native.cpp'
consumer.write_text('''#define PUFFERUI_IMPLEMENTATION
#define PUFFERUI_ENABLE_VULKAN
#define PUFFERUI_ENABLE_HARFBUZZ
#include "pufferui_single.h"
#include <array>
int main() {
 using namespace pui;
 auto *d=create_vulkan_device({.validation=true,.vector_text=false,.upload_mode=vulkan_upload_mode::STAGED});
 if(!d)return 1;
 auto *s=create_vulkan_surface(d,{.width=32,.height=32});if(!s)return 2;
 auto *c=create_context(d,s);auto *w=add_window(c,nullptr,s,{0,0,32,32});ui u(c);
 auto v=load_svg("<svg viewBox='0 0 32 32'><g opacity='.7'><rect width='24' height='32' fill='red'/><rect x='8' width='24' height='32' fill='blue'/></g></svg>");
 bool ok=v && u.prepare_vector(v.image,{.max_pixel_size={64,64},.max_instances=32});
 begin_frame(c,*w,0,1.0/60);d->clear({0,0,0,0});
 for(int i=0;i<32;++i)ok=u.draw_vector({4,4,24,24},v.image,{.style={.opacity=.8f}})&&ok;
 end_frame(c);std::array<u8,4> pixel{};
 ok=d->read_pixels(s->scene_target(),16,16,1,1,pixel.data())&&ok;
 ok=ok&&pixel[2]>200&&pixel[0]<32&&pixel[3]>200&&violation_count(c)==0&&vulkan_statistics(d).validation_errors==0&&vulkan_last_result(d)==VK_SUCCESS;
 destroy_vector(v.image);destroy_context(c);d->destroy_surface(s);destroy_vulkan_device(d);return ok?0:3;
}
''')
b=r/'out/build/x64-release'
run('cl','/nologo','/std:c++20','/EHsc','/O2','/MD','/DNDEBUG','/I'+str(o),'/I'+str(r/'vendored/stb'),'/I'+str(r/'build-vulkan-compute/harfbuzz-src/src'),'/IE:/VulkanSDK/1.4.335.0/include',consumer,'/Fe'+str(o/'single_native.exe'),'/Fo'+str(o/'single_native.obj'),'/link','E:/VulkanSDK/1.4.335.0/Lib/vulkan-1.lib',b/'_deps/pufferui_harfbuzz-build/harfbuzz-gpu.lib',b/'_deps/pufferui_harfbuzz-build/harfbuzz.lib')
run(o/'single_native.exe')
print('Dependency-OFF boundaries and native STAGED Slug amalgamation consumer passed',flush=True)
