from pathlib import Path
import subprocess,sys,time,os
r=Path(__file__).resolve().parent.parent;o=r/'build-vector-batchopt'
os.environ['PYTHONUTF8']='1';os.environ['TEMP']=os.environ['TMP']=str(o/'tmp')
while True:
 text=(o/'qualify.log').read_text(encoding='utf-8',errors='replace')
 if 'Full debug passed' in text:break
 if 'Traceback' in text:raise RuntimeError('Full suite failed; inspect qualify.log')
 time.sleep(1)
for name,script in [('remaining-checks','remaining_checks.py'),('showcase-checks','showcase_checks.py')]:
 print('Starting',name,flush=True)
 with (o/(name+'.log')).open('w',encoding='utf-8') as log:
  subprocess.run([sys.executable,str(o/script)],cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'passed',flush=True)
