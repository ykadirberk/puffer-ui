from pathlib import Path
import hashlib,json,subprocess,sys,os
r=Path(__file__).resolve().parent.parent;o=r/'build-vector-batchopt'/(sys.argv[1] if len(sys.argv)>1 else 'ablation');o.mkdir(exist_ok=False)
sys.path.insert(0,str(r/'tools'));from compare_vulkan_batches import parse
after=sys.argv[2] if len(sys.argv)>2 else 'measure-01'
bins={label:{name:r/folder/(name+'.exe') for name in ['pui_vulkan_startup_spiral_tests','pui_vulkan_vector_data_tests']} for label,folder in [('before','build-vector-batchopt/before'),('uploads','build-vector-batchopt/staged-only'),('combined','build-vector-batchopt/'+after+'/after')]}
receipt={'binaries':{label:{name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in files.items()} for label,files in bins.items()},'runs':[]}
orders=[['before','uploads','combined'],['combined','uploads','before'],['uploads','before','combined'],['combined','before','uploads']]
for case,exe,args in [('spiral-staged-plain','pui_vulkan_startup_spiral_tests',['--bench','--staged']),('spiral-staged-cache','pui_vulkan_startup_spiral_tests',['--bench','--staged','--cache']),('vector-staged-complex','pui_vulkan_vector_data_tests',['--bench','--staged','--complex'])]:
 for repetition,order in enumerate(orders):
  for label in order:
   name=f'{case}-{repetition:02}-{label}';print(name,flush=True)
   result=subprocess.run([str(bins[label][exe]),*args],cwd=r,capture_output=True,text=True,timeout=240)
   (o/(name+'.csv')).write_text(result.stdout);(o/(name+'.log')).write_text(result.stderr)
   if result.returncode:raise RuntimeError(name)
   rows,summary=parse(result.stdout,result.stderr)
   receipt['runs'].append({'name':name,'case':case,'revision':label,'repetition':repetition,'summary':summary})
(o/'receipt.json').write_text(json.dumps(receipt,indent=2));print('36 ablation runs / 6480 complete frames retained',flush=True)
