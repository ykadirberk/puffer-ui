from pathlib import Path
import hashlib,json,subprocess,sys,os
r=Path(__file__).resolve().parent.parent;o=r/'build-vector-batchopt';m=json.loads((o/'baseline.json').read_text())
snapshot=o/'baseline'
for name,expected in m['tracked'].items():
    if not name.startswith('include/'):continue
    data=subprocess.check_output(['git','show',m['commit']+':'+name],cwd=r)
    # Git normalizes text newlines; record canonical object bytes separately.
    p=snapshot/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
sys.path.insert(0,str(r/'tools'));from run_tests import import_msvc_env
import_msvc_env()
b=r/'out/build/x64-release'
args=['cl','/nologo','/std:c++20','/EHsc','/O2','/Ob2','/MD','/GL','/DNDEBUG','/DPUFFERUI_BATCH_BASELINE','/DPUFFERUI_ENABLE_VULKAN','/DPUFFERUI_ENABLE_HARFBUZZ','/DPUFFERUI_ENABLE_SDL3']
for p in [snapshot/'include',r/'vendored/stb',b/'vendored/SDL/include-revision',r/'vendored/SDL/include',r/'build-vulkan-compute/harfbuzz-src/src',Path('E:/VulkanSDK/1.4.335.0/include')]:args+=['/I'+str(p)]
args += [str(r/'tests/test_vulkan_batch.cpp'),'/Fe'+str(o/'before/pui_vulkan_batch_tests.exe'),'/Fo'+str(o/'before/reference.obj'),'/link','/LTCG','/INCREMENTAL:NO']
args += [str(b/'vendored/SDL/SDL3-static.lib'),'E:/VulkanSDK/1.4.335.0/Lib/vulkan-1.lib',str(b/'_deps/pufferui_harfbuzz-build/harfbuzz-gpu.lib'),str(b/'_deps/pufferui_harfbuzz-build/harfbuzz.lib')]
args += [x+'.lib' for x in ['kernel32','user32','gdi32','winmm','imm32','version','uuid','advapi32','setupapi','shell32','hid','dinput8','uiautomationcore','comctl32','ole32','oleaut32','winspool','comdlg32']]
(o/'reference-command.json').write_text(json.dumps(args,indent=2))
subprocess.run(args,cwd=r,check=True)
(o/'reference-source.json').write_text(json.dumps({'base_commit':m['commit'],'harness_sha256':hashlib.sha256((r/'tests/test_vulkan_batch.cpp').read_bytes()).hexdigest(),'headers':{p.relative_to(snapshot).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in snapshot.rglob('*') if p.is_file()}},indent=2))
