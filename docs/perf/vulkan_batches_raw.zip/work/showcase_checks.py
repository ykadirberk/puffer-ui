from pathlib import Path
import subprocess,hashlib,json,os
r=Path(__file__).resolve().parent.parent;o=r/'build-vector-batchopt';folder=o/'showcase-final';folder.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before=o/'before/pui_showcase_vulkan.exe';after=r/'out/build/x64-release/Release/pui_showcase_vulkan.exe'
cases=[('svg',['--vectors']),('svg-640',['--vectors','--resize','640x480']),('spiral-5000',['--page','1','--tiles','5000','--lab-mode','4','--lab-size','64'])]
receipt={'cases':[],'all_exact':True,'binaries':{'before':sha(before),'after':sha(after)}}
for name,flags in cases:
 images={}
 for label,exe in [('before',before),('after',after)]:
  image=folder/(name+'-'+label+'.bmp');command=[str(exe),'--selftest','--frames','180','--no-hud',*flags,'--screenshot',str(image)]
  print(name,label,flush=True);p=subprocess.run(command,cwd=r,capture_output=True,text=True,timeout=300)
  (folder/(name+'-'+label+'.log')).write_text(p.stdout+p.stderr,encoding='utf-8')
  if p.returncode or not image.exists():raise RuntimeError(name+' '+label+' failed')
  images[label]=image
 exact=images['before'].read_bytes()==images['after'].read_bytes();receipt['all_exact'] &= exact
 receipt['cases'].append({'case':name,'frames_each':180,'arguments':flags,'exact_full_bmp':exact,'hashes':{label:sha(path) for label,path in images.items()}})
 if not exact:raise RuntimeError(name+' actual showcase BMP changed')
(o/'showcase-final.json').write_text(json.dumps(receipt,indent=2));print('Actual showcase: 1080 frames, three complete before/after BMP pairs exact',flush=True)
