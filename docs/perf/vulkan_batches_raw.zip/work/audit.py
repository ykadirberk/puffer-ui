from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parent.parent;o=r/'build-vector-batchopt'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((o/'baseline.json').read_text());timed=json.loads((o/'timed-sources-final.json').read_text())
tests={p:h for p,h in b['tracked'].items() if p.startswith('tests/')}
assert all(sha(r/p)==h for p,h in tests.items()),'Existing test/oracle changed'
assert all(sha(r/p)==h for p,h in b['drafts'].items()),'Unrelated report changed'
assert all(sha(r/p)==h for p,h in timed.items()),'Measured source changed'
shaders={p:h for p,h in b['tracked'].items() if p.startswith('src/shaders/vulkan/') or p.endswith('/vulkan_shaders.inl') or p.endswith('/vulkan_vector_shaders.inl')}
assert all(sha(r/p)==h for p,h in shaders.items()),'Shader bytes changed'
assert not subprocess.check_output(['git','-C','vendored/SDL','status','--porcelain'],cwd=r,text=True).strip()
for mode,frames in b['references'].items():
 assert len(frames)==180
 assert all(sha(r/'build-vulkan-gaussian-fix'/('spiral-'+mode)/name)==h for name,h in frames.items())
receipt={'base':b['commit'],'existing_test_and_oracle_files_unchanged':len(tests),'unrelated_drafts_unchanged':len(b['drafts']),'measured_source_files_unchanged':len(timed),'shader_files_byte_exact':len(shaders),'immutable_spiral_references_unchanged':360,'SDL_submodule_clean':True,'vector_archive_sha256':sha(r/'tests/golden/vector_batch/frames.zip')}
(o/'protected-audit.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
