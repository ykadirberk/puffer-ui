#define PUFFERUI_IMPLEMENTATION
#define PUFFERUI_ENABLE_VULKAN
#define PUFFERUI_ENABLE_HARFBUZZ
#include "pufferui_single.h"
#include <array>
int main() {
 using namespace pui;
 auto *d=create_vulkan_device({.validation=true,.vector_text=false,.upload_mode=vulkan_upload_mode::STAGED});
 if(!d)return 1;
 auto *s=create_vulkan_surface(d,{.width=32,.height=32});if(!s)return 2;
 auto *c=create_context(d,s);auto *w=add_window(c,nullptr,s,{0,0,32,32});ui u(c);
 auto v=load_svg("<svg viewBox='0 0 32 32'><g opacity='.7'><rect width='24' height='32' fill='red'/><rect x='8' width='24' height='32' fill='blue'/></g></svg>");
 bool ok=v && u.prepare_vector(v.image,{.max_pixel_size={64,64},.max_instances=32});
 begin_frame(c,*w,0,1.0/60);d->clear({0,0,0,0});
 for(int i=0;i<32;++i)ok=u.draw_vector({4,4,24,24},v.image,{.style={.opacity=.8f}})&&ok;
 end_frame(c);std::array<u8,4> pixel{};
 ok=d->read_pixels(s->scene_target(),16,16,1,1,pixel.data())&&ok;
 ok=ok&&pixel[2]>200&&pixel[0]<32&&pixel[3]>200&&violation_count(c)==0&&vulkan_statistics(d).validation_errors==0&&vulkan_last_result(d)==VK_SUCCESS;
 destroy_vector(v.image);destroy_context(c);d->destroy_surface(s);destroy_vulkan_device(d);return ok?0:3;
}
