from pathlib import Path
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
r=Path(__file__).resolve().parent.parent;o=r/'build-vector-batchopt';s=json.loads((o/'summary.json').read_text())
lines=['All values below pool every frame of the eight alternating pairs, in milliseconds.','',
'| Workload | CPU mean before → after | CPU change | GPU mean before → after | GPU change |',
'| --- | --- | --- | --- | --- |']
for name,values in s['cases'].items():
 a,b=values['before'],values['after'];gpu=f"{a['gpu_mean_ms']:.6f} → {b['gpu_mean_ms']:.6f}" if 'gpu_mean_ms' in a else 'n/a'
 change=f"{values['gpu_change_percent']:+.2f}%" if 'gpu_change_percent' in values else 'n/a'
 lines.append(f"| {name} | {a['wall']['mean']:.6f} → {b['wall']['mean']:.6f} | {values['wall_change_percent']:+.2f}% | {gpu} | {change} |")
lines+=['','| Spiral mode | p95 before → after | p99 before → after | Maximum before → after | Frame 0 median before → after |','| --- | --- | --- | --- | --- |']
for name,values in s['cases'].items():
 if not name.startswith('spiral'):continue
 a,b=values['before'],values['after'];lines.append(f"| {name} | {a['wall']['p95']:.4f} → {b['wall']['p95']:.4f} | {a['wall']['p99']:.4f} → {b['wall']['p99']:.4f} | {a['wall']['maximum']:.4f} → {b['wall']['maximum']:.4f} | {a['cold_median_ms']:.4f} → {b['cold_median_ms']:.4f} |")
lines+=['','The STAGED GPU reduction is repeatable across plain/cache and the separate',
'ablation. CPU results are mixed: STAGED plain improves 1.35%; cached mean is',
'+0.31%, and its absolute worst increases 17.1673→18.6338 ms. DIRECT CPU means',
'increase 0.97–1.23%. Simple-path CPU means increase 1.87–2.93%. These raw costs',
'remain in the qualification; there is no universal CPU or worst-frame speedup.',
'The null control also increases 2.01% despite byte-identical `.text` and `.pdata`',
'sections in its before/after executables. That establishes timing variability',
'outside a changed null algorithm, but does not prove that it explains every',
'native CPU difference. No control-normalized speedup is substituted for the',
'measured values. Run/frame identities for all peaks are retained.','',
'| STAGED ablation | GPU baseline | GPU uploads only | GPU final combined |',
'| --- | --- | --- | --- |']
for name,values in s['ablation'].items():
 lines.append(f"| {name} | {values['before']['gpu_mean_ms']:.6f} | {values['uploads']['gpu_mean_ms']:.6f} | {values['combined']['gpu_mean_ms']:.6f} |")
lines+=['','The uploads-only binary retains the old 480-draw composition. It reduces',
'composed STAGED GPU cost from 4.584421 to 3.051296 ms; scene batching reduces',
'it further to 0.964614 ms in that series. CPU ablation samples are retained',
'separately; cached Spiral CPU remains mixed. This isolates concrete transfer/',
'pass overhead rather than attributing all timing changes to HarfBuzz shaping.','',
'Every native vector draw/flush sample reports zero counted C++ allocations and',
'zero draw-time upload-buffer allocations. Spiral vertices, indices, draw counts',
'and **logical** upload bytes match before/after at every frame. Consolidated',
'copies also transfer existing 32-byte alignment gaps (at most 31 bytes per',
'append); logical upload counters are not claimed to measure physical PCIe bytes.',
'Reserved Spiral upload memory stays 68,681,728 bytes DIRECT / 135,790,592 STAGED.','',
'| Composed SVG residency | Before | After |','| --- | --- | --- |']
a=s['cases']['vector-direct-complex']['before'];b=s['cases']['vector-direct-complex']['after']
for label,key in [('Vulkan image allocations (bytes)','image_bytes'),('Renderer path accounting (bytes)','path_residency_bytes')]:
 lines.append(f"| {label} | {int(a[key]):,} | {int(b[key]):,} |")
lines+=['','Prepared tiles add 3,072,000 image bytes (about 2.93 MiB) in this scene, plus',
'18,304 bytes of fixed CPU batch scratch. This is an explicit bounded memory/',
'GPU-time tradeoff within the unchanged 64 MiB vector cache. Simple sources',
'create no layer images; old Spiral scenes create no vector assets or targets.',
'Native Slug remains analytic coverage and is not replaced with the portable',
'prepared-texture representation.','',
'The earlier candidate and all diagnostic/recheck samples remain in the raw',
'evidence. Its simple-path CPU increase prompted a queue-discriminator/layout',
'refinement; the final table above still reports the residual observed increase.',
'Interrupted build/validation attempts are retained and excluded from pass counts.',
'One preliminary reference-only launch overlapped linking and was stopped before',
'timing; the final series starts only after the candidate build completed.']
text='\n'.join(lines)
patch='*** Begin Patch\n*** Update File: D:/myimgui/docs/perf_vulkan_batches.md\n@@\n-MEASUREMENTS_PENDING\n'+''.join('+'+line+'\n' for line in text.splitlines())+'*** End Patch\n'
(o/'measurement.patch').write_text(patch,encoding='utf-8')
print(patch)
