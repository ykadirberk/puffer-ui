from pathlib import Path
import csv,gzip,hashlib,io,json,os,statistics,subprocess,sys,zipfile
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent;m=w/'measurements'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((w/'baseline.json').read_text());receipt=json.loads((m/'receipt.json').read_text())
def unchanged(items):
 for name,value in items.items():assert sha(r/name)==value,name
unchanged(receipt['protected_hashes']);unchanged(receipt['source_hashes'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==b['commit']
gates={c:json.loads((w/f'gate-{c}-qualified.json').read_text()) for c in ['release','debug']}
assert all(x['exit_code']==0 for x in gates.values())
extra=json.loads((w/'extra/results.json').read_text());smoke=json.loads((w/'smoke/results.json').read_text())
assert all(x['exit_code']==0 for x in extra+smoke)
assert json.loads((w/'smoke/exact.json').read_text())['overview_effects_exact']
mutants=json.loads((w/'mutants/results.json').read_text());assert all(x['exit_code']==1 for x in mutants)
for name,value in receipt['binary_hashes']['after'].items():assert sha(r/'out/build/x64-release/Release'/(name+'.exe'))==value,name
for mode,refs in b['references'].items():
 for name,value in refs.items():assert sha(r/'build-vulkan-gaussian-fix'/('spiral-'+mode)/name)==value
stem='vulkan_startup_optimizations';dest=r/'docs/perf';report=r/'docs/perf_vulkan_startup_optimizations.md'
outputs=[report,*[dest/(stem+s) for s in ['.json','_frames.csv.gz','_raw.zip','_spiral.png']]]
assert not set(p.relative_to(r).as_posix() for p in outputs)&(set(b['tracked'])|set(b['drafts']))
with (dest/(stem+'_frames.csv.gz')).open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as zipped:zipped.write((m/'frames.csv').read_bytes())
sys.path.insert(0,str(r/'build-vulkan-blur-opt4/plot_lib'));os.environ['MPLCONFIGDIR']=str(w/'mplconfig')
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
rows=list(csv.DictReader((m/'frames.csv').open()));s=receipt['summary'];colors={'before':'#bb5533','after':'#14758c'}
fig,axes=plt.subplots(3,2,figsize=(16,12),layout='constrained')
for row,scenario in enumerate(['startup','late']):
 for col,mode in enumerate(['direct','staged']):
  ax=axes[row,col]
  for side in ['before','after']:
   groups=[[float(x['total_ms']) for x in rows if x['scenario']==scenario and x['mode']==mode and x['side']==side and int(x['repeat'])==repeat] for repeat in range(8)]
   for values in groups:ax.plot(range(180),values,color=colors[side],alpha=.12,lw=.7)
   ax.plot(range(180),[statistics.median(values[f] for values in groups) for f in range(180)],color=colors[side],lw=1.7,label=side)
  ax.set(title=f'{scenario}: {mode.upper()} - every frame, 8 runs / side',xlabel='Frame',ylabel='CPU wall ms');ax.grid(alpha=.2);ax.legend()
ax=axes[2,0]
for pos,mode in enumerate(['direct','staged']):
 for side,offset in [('before',-.15),('after',.15)]:
  values=[x['cold_ms'] for x in receipt['runs'] if x['scenario']=='startup' and x['mode']==mode and x['side']==side]
  ax.scatter([pos+offset]*len(values),values,color=colors[side],alpha=.7,label=side if pos==0 else None)
  ax.plot([pos+offset-.1,pos+offset+.1],[statistics.median(values)]*2,color=colors[side],lw=2)
ax.set(xticks=[0,1],xticklabels=['DIRECT','STAGED'],ylabel='Frame 0 wall ms',title='Startup frame 0 - every observed cold sample');ax.grid(alpha=.2);ax.legend()
ax=axes[2,1]
for side in ['before','after']:
 groups=[[float(x['total_ms']) for x in rows if x['scenario']=='null' and x['side']==side and int(x['repeat'])==repeat] for repeat in range(8)]
 for values in groups:ax.plot(range(180),values,color=colors[side],alpha=.12,lw=.7)
 ax.plot(range(180),[statistics.median(values[f] for values in groups) for f in range(180)],color=colors[side],lw=1.7,label=side)
ax.set(title='Unchanged null-renderer control - every frame',xlabel='Frame',ylabel='CPU wall ms');ax.grid(alpha=.2);ax.legend()
fig.suptitle('PufferUI production startup + 5000-item Spiral | RX 9070 XT | all cold/outlier frames retained',fontsize=14)
fig.savefig(dest/(stem+'_spiral.png'),dpi=150);plt.close(fig)
proof=dict(gates=gates,extra=extra,smoke=smoke,mutants=mutants,
 original_test_files=sum(p.startswith('tests/') for p in b['tracked']),protected_drafts=len(b['drafts']),
 native_cases_per_configuration={c:(w/f'gate-{c}-qualified.log').read_text(errors='replace').count('==== Vulkan ') for c in gates},
 new_fan_tests=dict(exact_streams=80000,exact_bounds=400000,rounding_modes=4,warm_fans=1000,direction_evaluations=8000,bounds_positions=17000),
 immutable_spiral_checks=sum(x['exact_frames'] for x in receipt['exact_checks']),
 gaussian_reference_hashes={p.name:sha(p) for p in (r/'build-vulkan-blur-opt4/css-goldens').iterdir() if p.is_file()},
 source_baseline=b['commit'],branch=subprocess.check_output(['git','branch','--show-current'],cwd=r,text=True).strip())
def fmt(value):return f'{value:.4f}'
def pair(x,key):return f"{fmt(x['before'][key])} / {fmt(x['after'][key])}"
def performance_table(scenario):
 text='| Upload | Mean before / after ms | Paired mean change | p99 before / after ms | Absolute worst before / after ms | GPU before / after ms |\n|---|---:|---:|---:|---:|---:|\n'
 for mode,x in s[scenario].items():
  text+=f"| {mode.upper()} | {pair(x,'mean_ms')} | {x['paired_mean_percent']:+.2f}% ({x['improved_pairs']}/8 improve) | {pair(x,'p99_ms')} | {pair(x,'absolute_max_ms')} | {pair(x,'gpu_ms') if scenario!='null' else 'n/a'} |\n"
 return text
setup_table='| Upload | Frame 0 before / after ms | Frame 1 before / after ms | Setup before / after ms | Setup + frame 0 before / after ms | Setup + first two before / after ms |\n|---|---:|---:|---:|---:|---:|\n'
for mode,x in s['startup'].items():setup_table+=f"| {mode.upper()} | {pair(x,'cold_ms')} | {pair(x,'frame1_ms')} | {pair(x,'setup_ms')} | {pair(x,'setup_frame0_ms')} | {pair(x,'setup_first_two_ms')} |\n"
peak_table='| Upload | Frame 127 before / after ms | Frame 128 before / after ms |\n|---|---:|---:|\n'
for mode,x in s['late'].items():peak_table+=f"| {mode.upper()} | "+' | '.join(f"{fmt(x['before']['same_frames_ms'][f])} / {fmt(x['after']['same_frames_ms'][f])}" for f in ['127','128'])+' |\n'
control_table='| Upload | Same executable late / preflight frame 0 ms | Late / preflight setup + first two ms | Paired 180-frame mean change |\n|---|---:|---:|---:|\n'
for mode,x in s['preparation-control'].items():control_table+=f"| {mode.upper()} | {pair(x,'cold_ms')} | {pair(x,'setup_first_two_ms')} | {x['paired_mean_percent']:+.2f}% |\n"
maxima=[]
for scenario,modes in s.items():
 for mode,x in modes.items():
  for side in ['before','after']:
   worst=max(x[side]['maxima'],key=lambda y:y['max_ms']);maxima.append(f"- {scenario} / {mode} / {side}: {worst['max_ms']:.4f} ms at frame {worst['max_frame']}, repeat {worst['repeat']}.")
text=f'''# Vulkan startup preparation and exact rounded-fan reuse

Date: 2026-11-02. Baseline: `{b['commit']}`; branch `{proof['branch']}`.
Windows, MSVC Release, AMD Radeon RX 9070 XT, vendor/device 4098/30032,
driver 8388996. Production source and binary hashes are in the receipt.

## Changes

Known initial Spiral scenes prepare CPU geometry storage and every completed
native upload slot before the first frame clock. The new
`vulkan_prepare_surface_geometry(surface, capacity)` accepts an idle, ready
surface and retains the existing extent-dependent limits, budgets, direct/staged
storage and late continuation fallback. All slots are checked before mutation;
recording, in-flight group/slot serials, dirty/zero-size surfaces and active
painting decline. This entry does not submit, wait, reset command buffers or
trim another surface. Global budget pressure declines softly; actual native
allocation/map errors retain their existing sticky failure behavior. A false
return can leave a bounded or partial reservation.

The application performs its explicit loading wait before native preparation.
The bootstrap callback runs after fonts/theme and before selftest VSync policy;
otherwise a dirty WSI swapchain would silently prevent preparation. Offscreen
VSync changes no longer dirty a surface that has no presentation mode. The
ready-checking atomic exercises the actual SDL bootstrap ordering. The model,
animation time, RNG and UI frame count are not advanced. Existing CPU
resize-to-commit preparation is retained, including its memory touches.

Rounded fans retain the exact original vertex, UV, color and index arithmetic.
Fixed corner directions use the existing immutable arc table, except the first
angle is evaluated at use to preserve signed-zero behavior under changing FP
rounding modes. Known internal fans use the center and 16 emitted endpoints
for the original bounds; nonfinite input falls back to the complete ordered
scan. Arbitrary user meshes always keep the full scan, including 73/324 meshes.
No shape, AA segment, shadow, primitive order, font or shader is changed.

## Protocol and startup accounting

The actual showcase runs 180 fixed 1/60s frames, 1360x860, size-64 Spiral,
5000 -> 5003 items, with real keyboard Adds at 90/120/150. Eight alternating
before/after pairs per mode retain **{receipt['timed_frames']:,} timed frames**
across 112 process starts. The startup workload is the same source compiled
against frozen old headers/examples and current sources; the baseline-only
macro reproduces the missing old prepare callback. The original native Spiral
and null harnesses remain unchanged and are measured separately. A same-binary
late/preflight control isolates setup placement. Timing has no readbacks or
concurrent project build/test/window. Every frame and outlier is retained.

Mean and p99 are medians of eight run statistics; p99 is sorted element 177.
Worst is the absolute maximum across all runs. Paired change is the median
matched run-mean change. GPU is completed interval total / 180; delayed samples
are not attributed to the current CPU frame. CPU and GPU overlap.

{setup_table}
**Preparation moves existing work into setup. It does not eliminate that work
or establish faster total application startup.** Setup, setup + frame 0 and
setup + the first two frames above are medians of per-run sums, not sums of
independent medians. Full process times and explicit preparation times remain
in the receipt. Both native slots are prepared up front; the old path paid the
second slot on frame 1. Historical 53.2625 ms had no subphase trace, so this
report does not retrospectively assign its exact cost to an allocator/driver.

Startup 180-frame wall/GPU results:

{performance_table('startup')}
Frame-0 medians improve by
{(1-s['startup']['direct']['after']['cold_ms']/s['startup']['direct']['before']['cold_ms'])*100:.2f}% DIRECT /
{(1-s['startup']['staged']['after']['cold_ms']/s['startup']['staged']['before']['cold_ms'])*100:.2f}% STAGED.
The startup cohort's STAGED absolute maximum nevertheless rises from
{s['startup']['staged']['before']['absolute_max_ms']:.4f} to
{s['startup']['staged']['after']['absolute_max_ms']:.4f} ms;
no universal worst-frame reduction is claimed.

## Unchanged late-hint harness and null control

The original native harness still calls the paint callback directly; it does
not opt into application setup. Its frame 0 remains a real cold preparation
case. This measures rounded-fan reuse without silently excluding its old work.

{performance_table('late')}
Same-index recurring geometry peaks in that unchanged harness:

{peak_table}
The same candidate binary, with only preparation placement switched:

{control_table}
The unchanged null-renderer actual showcase control:

{performance_table('null')}
The unchanged DIRECT harness has a {s['late']['direct']['paired_mean_percent']:+.2f}%
paired mean change and only {s['late']['direct']['improved_pairs']}/8 improved pairs:
this cohort does not establish a sustained DIRECT throughput improvement.
The bounded work regressions establish removal of the redundant operations;
measured aggregate benefits are modest and depend on the preparation boundary.

These are measured cohort results, not a universal per-frame or worst-frame
guarantee. All absolute maxima are listed below, including regressions. The Add
animation still sends many targets through the visible center and retains its
geometry burst. Per-frame geometry, draw/submission counts and upload bytes
match where fields are common. This change does not claim reduced physical
VRAM, per-process 3D utilization or foreground FPS. Startup moves storage earlier
and can increase memory held before the first frame.

![All measured traces and cold samples](perf/{stem}_spiral.png)

## Regression and visual qualification

- New fan regressions compare **80,000 complete streams** and **400,000 bounds**
  against independent unchanged scalar references across four FP rounding modes,
  extreme/nonfinite values, signed zero, prefixes, UVs and radii. A warmed 1,000
  fans perform exactly 8,000 direction evaluations and 17,000 bounds visits with
  no allocation; nonfinite fallback and arbitrary-mesh full scanning are pinned.
  Isolated direction/bounds slow-path mutants each fail the respective bound.
- New native preflight regressions cover direct/staged, 20/32-byte vertices,
  one/two slots, all-slot in-flight/recording guards, no-op reuse, extent/resize,
  budget pressure, bounded/oversized requests and native allocation/map failures.
  Actual translucent pixels match reference rendering. The 180-frame startup
  regression pins CPU storage pointers and every native geometry buffer handle.
- Full Release and Debug `python tools/run_tests.py --vulkan --format` pass:
  **{proof['native_cases_per_configuration']['release']} native cases each**, existing core/pump/performance/allocation suites,
  SDL goldens, 1150/5000 Spiral and peak references, all example selftests,
  installed consumers, API/tutorial drift, Python telemetry tests and formatting.
- SDL OFF / HarfBuzz OFF builds and passes base Vulkan plus direct/staged
  preflight regressions. Immutable CSS Gaussian goldens pass in both modes:
  36 cases at 1x through 4x DPI, 576 exact frames and 144 idle hits.
- **{proof['immutable_spiral_checks']:,} complete immutable Spiral RGBA comparisons** cover before/after,
  startup/original harnesses, direct/staged, candidate cache off/on and late
  control. Every comparison checks all 180 frames, including frame 0 and all
  observed peak indices. Complete RGBA for all observed maxima and neighbours
  is archived; all 360 original direct/staged reference hashes remain fixed.
- Actual standard executable Overview and Effects screenshots are exact against
  frozen production. The standard 5000-item CLI and new ready-asserting atomic
  selftests pass. The two-window demo launches and exits normally after a
  bounded three-second smoke. The atomic README image is generated and reviewed.
  Hidden selftests/captures are not foreground performance certification.
- All **{proof['original_test_files']} original test/oracle files** and **{proof['protected_drafts']}
  pre-existing unrelated report drafts** retain their hashes. Existing test
  bodies, tolerances, fonts, shaders and golden bytes are unchanged.

Final full gates are separate from earlier failed new-fixture/overlapping-build
attempts. Those logs are archived too. Corrections were in new fixtures and the
bootstrap ordering, without weakening existing expectations. The supplementary
fresh CMake compiler probe initially hit MSVC's C1902 PDB-manager mismatch;
embedded debug information fixes that build setup. Production flags are unchanged.
The demo does not parse `--selftest`; the first supplementary invocation timed
out. Its final smoke instead verifies both windows and sends normal close
requests only to the newly launched owned process, then requires exit zero.

## All-run maxima

{chr(10).join(maxima)}

Every per-run maximum and all 20,160 timings remain in the machine-readable
evidence; no sample was trimmed or rerun to replace an adverse observation.

## Evidence and reproduction

[Receipt and hashes](perf/{stem}.json),
[all frames](perf/{stem}_frames.csv.gz),
[raw measurements, frozen sources/binaries and peak RGBA](perf/{stem}_raw.zip).

```powershell
python tools/compare_vulkan_startup.py `
  build-vulkan-startup-opt/before out/build/x64-release/Release `
  --baseline build-vulkan-startup-opt/baseline.json `
  --reference build-vulkan-gaussian-fix/spiral-direct `
  --output build-vulkan-startup-repeat --runs 8
```

Use a fresh output directory. The raw archive includes the frozen old headers,
examples, original test sources, baseline executable hashes and matched startup
build command. Normal users launch the Release showcase directly:

```powershell
& "out/build/x64-release/Release/pui_showcase_vulkan.exe" --page 1 --tiles 5000 --lab-mode 4 --lab-size 64
```

No Python launcher is required. See the resource-preparation atomic, native
documentation and tutorial chapter 10 for explicit application integration.
'''
report.write_text(text,encoding='utf-8')
changed=subprocess.check_output(['git','diff','--name-only'],cwd=r,text=True).splitlines()
new=['examples/atomic/vulkan_preparation.cpp','tests/test_fan_performance.inl','tests/test_vulkan_preflight.cpp','tests/test_vulkan_startup_spiral.cpp','tests/test_vulkan_startup_tools.py','tools/compare_vulkan_startup.py','docs/img/readme/vulkan-preparation.png']
peak_frames={0,1,126,127,128,157,158}
for run in receipt['runs']:
 if run['scenario']!='null':peak_frames.update(f for f in range(run['max_frame']-1,run['max_frame']+2) if 0<=f<180)
archive=dest/(stem+'_raw.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in m.rglob('*'):
  if p.is_file():z.write(p,'measurement/'+p.relative_to(m).as_posix())
 for p in w.glob('*.log'):z.write(p,'qualification/'+p.name)
 for p in w.glob('gate-*.json'):z.write(p,'qualification/'+p.name)
 for name in ['baseline.json','compile_before.py','gate.py','qualify.py','extra.py','postqual.py','finish.py','targeted.json','mutants.py','package.py']:
  p=w/name
  if p.exists():z.write(p,'reproduction/'+name)
 for directory in ['extra','smoke','mutants']:
  for p in ((w/directory).glob('*') if directory=='mutants' else (w/directory).rglob('*')):
   if p.is_file():z.write(p,'qualification/'+directory+'/'+p.relative_to(w/directory).as_posix())
 for name in b['tracked']:
  if name.startswith(('include/','examples/')):z.write(w/'before'/name,'frozen/'+name)
  elif name.startswith(('tests/','src/shaders/','assets/fonts/')) and (r/name).suffix!='.bmp':z.write(r/name,'frozen/'+name)
 for name in ['startup-build.json','startup-build.log','tests/test_vulkan_startup_spiral.cpp']:
  z.write(w/'before'/name,'frozen/'+name)
 for name in changed+new:z.write(r/name,'candidate/'+name)
 z.write(report,'candidate/'+report.relative_to(r).as_posix())
 z.write(r/'out/build/x64-release/Release/pui_showcase_vulkan.exe','candidate/pui_showcase_vulkan.exe')
 z.write(w/'before/pui_showcase_vulkan.exe','frozen/pui_showcase_vulkan.exe')
 for f in sorted(peak_frames):
  name=f'frame-{f:03d}.rgba';z.write(r/'build-vulkan-gaussian-fix/spiral-direct'/name,'immutable-peaks/'+name)
 z.writestr('qualification/proofs.json',json.dumps(proof,indent=2)+'\n')
 z.writestr('immutable-peaks/format.json',json.dumps(dict(width=1360,height=860,format='RGBA8',frames=sorted(peak_frames),direct_staged_identical=True),indent=2)+'\n')
assert archive.stat().st_size<95*1024*1024,'GitHub single-file limit'
receipt.update(qualification=proof,baseline=b,
 candidate_manifest={name:sha(r/name) for name in changed+new},
 artifacts={p.relative_to(r).as_posix():dict(sha256=sha(p),bytes=p.stat().st_size) for p in outputs if p.suffix!='.json'})
(dest/(stem+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(outputs=[str(p) for p in outputs],qualification=proof,summary=s),indent=2))
