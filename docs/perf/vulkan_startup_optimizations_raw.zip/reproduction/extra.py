from pathlib import Path
import json,os,subprocess,sys
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'tools'));from run_tests import import_msvc_env
from compare_vulkan_native_optimizations import environment
import_msvc_env();env=environment({});env['VULKAN_SDK']='E:/VulkanSDK/1.4.335.0';env['CMAKE_BUILD_PARALLEL_LEVEL']='4'
o=w/'extra';o.mkdir(exist_ok=True);cases=[]
if (o/'results.json').exists() and not (o/'initial').exists():
 import shutil
 (o/'initial').mkdir()
 for name in ['results.json','minimal-configure.log']:
  if (o/name).exists():shutil.copy2(o/name,o/'initial'/name)
def run(name,cmd):
 with (o/(name+'.log')).open('w') as log:result=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 cases.append(dict(name=name,command=cmd,exit_code=result.returncode));(o/'results.json').write_text(json.dumps(cases,indent=2)+'\n');print(name,result.returncode,flush=True);result.check_returncode()
for mode in ['direct','staged']:
 run('gaussian-'+mode,[str(r/'out/build/x64-release/Release/pui_vulkan_gaussian_tests.exe'),'--goldens',str(r/'build-vulkan-blur-opt4/css-goldens'),*(['--staged'] if mode=='staged' else [])])
minimal=w/'minimal-embedded'
run('minimal-configure',['cmake','-S',str(r),'-B',str(minimal),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_MSVC_DEBUG_INFORMATION_FORMAT=Embedded','-DPUFFERUI_WITH_SDL3=OFF','-DPUFFERUI_WITH_HARFBUZZ=OFF','-DPUFFERUI_WITH_VULKAN=ON'])
run('minimal-build',['cmake','--build',str(minimal),'--target','pui_vulkan_tests','pui_vulkan_preflight_tests'])
for name in ['pui_vulkan_tests','pui_vulkan_preflight_tests']:
 run(name+'-minimal',[str(minimal/'Release'/f'{name}.exe')])
 if name.endswith('preflight_tests'):run(name+'-minimal-staged',[str(minimal/'Release'/f'{name}.exe'),'--staged'])
format_exe=r/'build-perf-review/format-tool/clang_format/data/bin/clang-format.exe'
run('format-new-files',[str(format_exe),'--dry-run','--Werror','tests/test_fan_performance.inl','tests/test_vulkan_preflight.cpp','tests/test_vulkan_startup_spiral.cpp','examples/atomic/vulkan_preparation.cpp'])
