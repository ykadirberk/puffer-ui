from pathlib import Path
import hashlib,json,os,subprocess,sys,time
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent
while not (w/'gate-debug-qualified.json').exists():time.sleep(5)
for mode in ['release','debug']:
 assert json.loads((w/f'gate-{mode}-qualified.json').read_text())['exit_code']==0
print('Full qualification passed; starting supplementary checks',flush=True)
subprocess.run([sys.executable,str(w/'extra.py')],cwd=r,check=True)
sys.path.insert(0,str(r/'tools'))
from compare_vulkan_native_optimizations import environment
env=environment({});env['VULKAN_SDK']='E:/VulkanSDK/1.4.335.0'
o=w/'smoke';o.mkdir(exist_ok=False);results=[]
def run(name,cmd):
 with (o/(name+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 results.append(dict(name=name,command=cmd,exit_code=p.returncode));(o/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,p.returncode,flush=True);p.check_returncode()
run('readme-shot',['pwsh','-NoProfile','-File','tools/readme_shots.ps1','-Names','vulkan-preparation'])
sys.path.insert(0,str(r/'build-vulkan-blur-opt4/plot_lib'));from PIL import Image
for page in [0,3]:
 images=[]
 for side,directory in [('before',w/'before'),('after',r/'out/build/x64-release/Release')]:
  image=o/f'showcase-{page}-{side}.bmp'
  run(f'showcase-{page}-{side}',[str(directory/'pui_showcase_vulkan.exe'),'--selftest','--frames','100','--page',str(page),'--no-script','--no-hud','--screenshot',str(image)])
  with Image.open(image) as bitmap:images.append((bitmap.size,bitmap.convert('RGBA').tobytes()))
 assert images[0]==images[1],f'Standard executable pixels changed on page {page}'
run('spiral-standard-cli',[str(r/'out/build/x64-release/Release/pui_showcase_vulkan.exe'),'--selftest','--frames','8','--page','1','--tiles','5000','--lab-mode','4','--lab-size','64','--no-script','--no-hud'])
run('demo',[str(r/'out/build/x64-release/Release/pui_demo.exe'),'--selftest'])
(o/'exact.json').write_text(json.dumps(dict(overview_effects_exact=True,pages=[0,3],dimensions=list(images[0][0])),indent=2)+'\n')
print('Supplementary checks passed; starting isolated timing',flush=True)
with (w/'measurements.log').open('w') as log:
 p=subprocess.run([sys.executable,'tools/compare_vulkan_startup.py',str(w/'before'),str(r/'out/build/x64-release/Release'),'--baseline',str(w/'baseline.json'),'--reference',str(r/'build-vulkan-gaussian-fix/spiral-direct'),'--output',str(w/'measurements'),'--runs','8'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
print('Measurements exit',p.returncode,flush=True);p.check_returncode()
