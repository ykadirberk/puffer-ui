from pathlib import Path
import json,os,shutil,subprocess,sys
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'tools'));from run_tests import import_msvc_env
import_msvc_env();o=w/'mutants';o.mkdir(exist_ok=False);results=[]
for name in ['directions','bounds']:
 d=o/name;d.mkdir();shutil.copytree(r/'include',d/'include')
 f=d/'include/pufferui/impl/renderer_primitives.inl';s=f.read_text()
 if name=='directions':
  assert s.count('s == 0')==1;s=s.replace('s == 0','s >= 0',1)
 else:
  start=s.index('inline rect rounded_fan_bounds(');end=s.index('\ntemplate <class UvFn>',start)
  s=s[:start]+'inline rect rounded_fan_bounds(const vertex *vertices) { return vertex_bounds(vertices, 73); }\n'+s[end:]
 f.write_text(s)
 cmd=['cl','/nologo','/std:c++20','/EHsc','/O2','/MD','/DNDEBUG','/DPUFFERUI_INTERNAL_TESTS','/DPUFFERUI_ASSET_DIR="'+(r/'assets').as_posix()+'"','/I'+str(d/'include'),'/I'+str(r/'vendored/stb'),str(r/'src/pufferui_impl.cpp'),'/Fo'+str(d/'probe.obj'),'/Fe'+str(d/'probe.exe')]
 with (d/'build.log').open('w') as log:subprocess.run(cmd,cwd=r,env=os.environ,stdout=log,stderr=subprocess.STDOUT,check=True)
 with (d/'run.log').open('w') as log:p=subprocess.run([str(d/'probe.exe')],cwd=r,stdout=log,stderr=subprocess.STDOUT)
 needle='fan_direction_work == 8000' if name=='directions' else 'fan_bounds_work == 17000'
 assert p.returncode!=0 and needle in (d/'run.log').read_text()
 results.append(dict(name=name,exit_code=p.returncode,expected_failed_assertion=needle));print(name,'regression detected',flush=True)
(o/'results.json').write_text(json.dumps(results,indent=2)+'\n')
