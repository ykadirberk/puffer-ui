from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent;before=w/'before'
sys.path.insert(0,str(r/'tools'));from run_tests import import_msvc_env
import_msvc_env();os.environ['VULKAN_SDK']='E:/VulkanSDK/1.4.335.0'
(before/'tests').mkdir(exist_ok=True);shutil.copy2(r/'tests/test_vulkan_startup_spiral.cpp',before/'tests/test_vulkan_startup_spiral.cpp')
libs=r/'out/build/x64-release';manifest=Path(os.environ['VSINSTALLDIR'])/'VC/Tools/MSVC'/os.environ['VCToolsVersion']/'include/manifest/segmentheap.manifest'
systems=['kernel32','user32','gdi32','winmm','imm32','version','uuid','advapi32','setupapi','shell32','hid','dinput8','uiautomationcore','comctl32','ole32','oleaut32','winspool','comdlg32']
cmd=['cl','/nologo','/std:c++20','/EHsc','/O2','/Ob2','/GL','/MD','/Z7','/DNDEBUG','/DWIN32','/D_WINDOWS','/DPUFFERUI_STARTUP_BASELINE','/DPUFFERUI_ENABLE_VULKAN','/DPUFFERUI_ENABLE_SDL3','/DPUFFERUI_ENABLE_HARFBUZZ','/DPUFFERUI_NATIVE_TELEMETRY','/DPUFFERUI_ASSET_DIR="'+(r/'assets').as_posix()+'"','/I'+str(before/'include'),'/I'+str(r/'vendored/stb'),'/I'+str(r/'vendored/SDL/include'),'/I'+str(libs/'vendored/SDL/include-revision'),'/I'+str(r/'build-vulkan-compute/harfbuzz-src/src'),'/IE:/VulkanSDK/1.4.335.0/Include',str(before/'tests/test_vulkan_startup_spiral.cpp'),'/Fo'+str(before/'startup.obj'),'/Fe'+str(before/'pui_vulkan_startup_spiral_tests.exe'),'/link','/LTCG','/DEBUG','/OPT:REF','/OPT:ICF','/INCREMENTAL:NO','/MANIFEST:EMBED','/MANIFESTINPUT:'+str(manifest),str(libs/'vendored/SDL/SDL3-static.lib'),str(libs/'_deps/pufferui_harfbuzz-build/harfbuzz.lib'),str(libs/'_deps/pufferui_harfbuzz-build/harfbuzz-gpu.lib'),'E:/VulkanSDK/1.4.335.0/Lib/vulkan-1.lib',*[x+'.lib' for x in systems]]
with (before/'startup-build.log').open('w') as log:
 log.write(repr(cmd)+'\n');log.flush();subprocess.run(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(before/'startup-build.json').write_text(json.dumps(dict(command=cmd,source_sha256=sha(before/'tests/test_vulkan_startup_spiral.cpp'),binary_sha256=sha(before/'pui_vulkan_startup_spiral_tests.exe')),indent=2)+'\n')
print('Frozen-source startup baseline built',flush=True)
