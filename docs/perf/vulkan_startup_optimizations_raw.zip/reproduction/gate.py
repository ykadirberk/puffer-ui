from pathlib import Path
import json,os,subprocess,sys,time
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'tools'));from run_tests import import_msvc_env
from compare_vulkan_native_optimizations import environment
import_msvc_env();env=environment({});env['VULKAN_SDK']='E:/VulkanSDK/1.4.335.0'
env['PATH']=str(r/'build-perf-review/format-tool/clang_format/data/bin')+os.pathsep+env['PATH']
env['CMAKE_BUILD_PARALLEL_LEVEL']='4'
config=sys.argv[1];tag=sys.argv[2] if len(sys.argv)>2 else 'final';stem=f'gate-{config}-{tag}'
(w/(stem+'.pid')).write_text(str(os.getpid())+'\n')
cmd=[sys.executable,'tools/run_tests.py','--vulkan','--format',*(['--release'] if config=='release' else []),*sys.argv[3:]];t=time.perf_counter()
with (w/(stem+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
(w/(stem+'.json')).write_text(json.dumps(dict(command=cmd,exit_code=p.returncode,seconds=time.perf_counter()-t),indent=2)+'\n')
print('Full',config,'gate exit',p.returncode,'seconds',round(time.perf_counter()-t,1),flush=True)
print('\n'.join((w/(stem+'.log')).read_text(errors='replace').splitlines()[-66:]),flush=True);sys.exit(p.returncode)
