from pathlib import Path
import subprocess,sys
w=Path(__file__).resolve().parent
for config in ['release','debug']:
 subprocess.run([sys.executable,str(w/'gate.py'),config,'qualified'],check=True)
print('Both final complete gates passed',flush=True)
