from pathlib import Path
import ctypes as c,json,os,subprocess,sys,time
from ctypes import wintypes as t
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent;o=w/'smoke'
sys.path.insert(0,str(r/'tools'));from compare_vulkan_native_optimizations import environment
env=environment({});env['VULKAN_SDK']='E:/VulkanSDK/1.4.335.0'
results=json.loads((o/'results.json').read_text());assert all(x['exit_code']==0 for x in results)
u=c.WinDLL('user32',use_last_error=True)
u.GetWindowThreadProcessId.argtypes=[t.HWND,c.POINTER(t.DWORD)];u.PostMessageW.argtypes=[t.HWND,t.UINT,t.WPARAM,t.LPARAM]
callback=c.WINFUNCTYPE(t.BOOL,t.HWND,t.LPARAM);u.EnumWindows.argtypes=[callback,t.LPARAM]
with (o/'demo-bounded.log').open('w') as log:
 p=subprocess.Popen([str(r/'out/build/x64-release/Release/pui_demo.exe')],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 try:
  time.sleep(3);assert p.poll() is None,'Demo failed during bounded smoke'
  handles=[]
  @callback
  def collect(hwnd,_):
   pid=t.DWORD();u.GetWindowThreadProcessId(hwnd,c.byref(pid))
   if pid.value==p.pid:handles.append(hwnd)
   return True
  u.EnumWindows(collect,0);assert len(handles)>=2,'Demo did not create both windows'
  for hwnd in handles:u.PostMessageW(hwnd,0x10,0,0)
  code=p.wait(timeout=15);assert code==0,code
  results.append(dict(name='demo-bounded-normal-close',command=p.args,pid=p.pid,windows=len(handles),exit_code=code))
 finally:
  if p.poll() is None:p.kill();p.wait()
(o/'results.json').write_text(json.dumps(results,indent=2)+'\n')
(o/'exact.json').write_text(json.dumps(dict(overview_effects_exact=True,pages=[0,3],dimensions=[1360,860],demo_initial_selftest_argument_unsupported=True),indent=2)+'\n')
print('Supplementary smoke passed; starting isolated 112-process timing',flush=True)
with (w/'measurements.log').open('w') as log:
 p=subprocess.run([sys.executable,'tools/compare_vulkan_startup.py',str(w/'before'),str(r/'out/build/x64-release/Release'),'--baseline',str(w/'baseline.json'),'--reference',str(r/'build-vulkan-gaussian-fix/spiral-direct'),'--output',str(w/'measurements'),'--runs','8'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
print('Measurements exit',p.returncode,flush=True);p.check_returncode()
