from pathlib import Path
import os,subprocess,sys
R=Path(__file__).resolve().parent.parent;W=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools'));from run_tests import import_msvc_env
import_msvc_env();os.environ['VULKAN_SDK']='E:/VulkanSDK/1.4.335.0'
os.environ['CMAKE_BUILD_PARALLEL_LEVEL']='4'
os.environ['PATH']=str(R/'build-perf-review/format-tool/clang_format/data/bin')+os.pathsep+os.environ['PATH']
(W/'tmp').mkdir(exist_ok=True);os.environ['TEMP']=os.environ['TMP']=str(W/'tmp');os.environ['PYTHONUTF8']='1'
print('Command:',sys.argv[1:],flush=True)
subprocess.run(sys.argv[1:],cwd=R,check=True)
