from pathlib import Path
import csv,hashlib,json,os,shutil,statistics,subprocess,sys
R=Path(__file__).resolve().parent.parent;W=Path(__file__).resolve().parent
assert 'All measurements,Debug,boundaries and final application checks passed' in (W/'post-release.log').read_text()
sys.path.insert(0,str(R/'tools'));from run_tests import import_msvc_env
import_msvc_env();os.environ['TEMP']=os.environ['TMP']=str(W/'tmp')
text=(W/'baseline/include/pufferui/impl/vulkan_draw.inl').read_text()
start=text.index('template <bool Simd = INTEGER_SIMD>\ninline geometry_span plan_geometry_span')
end=text.index('\ninline i32 geometry_vertex_offset',start)
legacy=text[start:end].replace('plan_geometry_span(', 'frozen_plan_geometry_span(',1)
(W/'kernel_legacy.inl').write_text(legacy)
data=W/'kernel-input.bin'
shutil.copy2(R/'build-vector-batch-review-20261104/captured-indices.bin',data)
digest=hashlib.sha256(data.read_bytes()).hexdigest()
assert digest=='33688d84ce844fe251afc4249f86e22b4878a6ee66768eee50901dcb626ce892'
args=json.loads((W/'reference-command.json').read_text())
args=[a.replace(str(W/'baseline/include'),str(R/'include')) for a in args if a!='/DPUFFERUI_VECTOR_CPU_BASELINE']
for i,a in enumerate(args):
    if a.endswith('test_vulkan_vector_cpu.cpp'):args[i]=str(W/'kernel.cpp')
    if a.startswith('/Fe'):args[i]='/Fe'+str(W/'kernel.exe')
    if a.startswith('/Fo'):args[i]='/Fo'+str(W/'kernel.obj')
(W/'kernel-command.json').write_text(json.dumps(args,indent=2))
subprocess.run(args,cwd=R,check=True)
result=subprocess.run([str(W/'kernel.exe'),str(data)],cwd=R,capture_output=True,text=True,check=True)
(W/'kernel.csv').write_text(result.stdout);(W/'kernel.log').write_text(result.stderr)
assert 'reference_simd_gate=1 production_simd=1 exact_split_tuples=3' in result.stderr
rows=list(csv.DictReader(result.stdout.splitlines()));assert len(rows)==384
assert len({r['checksum'] for r in rows})==1
out={'input_sha256':digest,'input_bytes':data.stat().st_size,'reference_simd_gate':1,'production_simd':1,'samples':384,'no_owned_gpu_work':True}
for label in ['before','after']:
    values=[float(r['kernel_ms']) for r in rows if r['version']==label]
    out[label]={'mean_ms':statistics.mean(values),'median_ms':statistics.median(values),'maximum_ms':max(values),'run_means':[statistics.mean(float(r['kernel_ms']) for r in rows if r['version']==label and int(r['pair'])==pair) for pair in range(8)]}
changes=[(b/a-1)*100 for a,b in zip(out['before']['run_means'],out['after']['run_means'])]
out['paired_percent']=changes;out['paired_median_percent']=statistics.median(changes)
out['correction']='Earlier review component reference lost PUI_VK_INTEGER_SIMD after header undef and measured scalar versus SSE2; its74percent result is not a matched SSE2 result. Actual frozen-executable frame/golden runs were unaffected.'
(W/'kernel-summary.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2),flush=True)
