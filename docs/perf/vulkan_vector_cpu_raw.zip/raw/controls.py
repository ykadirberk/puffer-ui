from pathlib import Path
import hashlib,json,os,shutil,struct,subprocess,sys
R=Path(__file__).resolve().parent.parent;W=Path(__file__).resolve().parent;O=W/'controls';O.mkdir(exist_ok=False)
assert 'All measurements,Debug,boundaries and final application checks passed' in (W/'post-release.log').read_text()
sys.path.insert(0,str(R/'tools'));from compare_vulkan_batches import parse
env=os.environ.copy()
for key in ['PUFFERUI_VULKAN_VALIDATION','VK_INSTANCE_LAYERS']:env.pop(key,None)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
bins={}
for label in ['a','b']:
    directory=O/label;directory.mkdir()
    for name in ['pui_vulkan_vector_data_tests','pui_vulkan_startup_spiral_tests','pui_showcase_tests']:
        source=W/'after'/(name+'.exe');p=directory/source.name;shutil.copy2(source,p);bins[label,name]=p
receipt={'runs':[],'binaries':{f'{label}/{name}':digest(p) for (label,name),p in bins.items()}}
for name in ['pui_vulkan_vector_data_tests','pui_vulkan_startup_spiral_tests','pui_showcase_tests']:
    assert digest(bins['a',name])==digest(bins['b',name])
for case,exe,args in [('vector-direct-complex','pui_vulkan_vector_data_tests',['--bench','--complex']),('vector-staged-complex','pui_vulkan_vector_data_tests',['--bench','--complex','--staged']),('spiral-staged-cache','pui_vulkan_startup_spiral_tests',['--bench','--staged','--cache']),('null','pui_showcase_tests',['--bench','null','--tiles','5000'])]:
    for pair in range(4):
        for label in (['a','b'] if pair%2==0 else ['b','a']):
            name=f'{case}-{pair:02}-{label}';print(name,flush=True)
            result=subprocess.run([str(bins[label,exe]),*args],cwd=R,env=env,capture_output=True,text=True,timeout=180)
            (O/(name+'.csv')).write_text(result.stdout);(O/(name+'.log')).write_text(result.stderr)
            if result.returncode:raise RuntimeError(name)
            rows,summary=parse(result.stdout,result.stderr)
            receipt['runs'].append({'name':name,'case':case,'revision':label,'pair':pair,'summary':summary})
(O/'receipt.json').write_text(json.dumps(receipt,indent=2))

def sections(p):
    data=p.read_bytes();pe=struct.unpack_from('<I',data,0x3c)[0];assert data[pe:pe+4]==b'PE\0\0'
    n=struct.unpack_from('<H',data,pe+6)[0];size=struct.unpack_from('<H',data,pe+20)[0];offset=pe+24+size
    out={}
    for i in range(n):
        at=offset+i*40;name=data[at:at+8].rstrip(b'\0').decode()
        length,start=struct.unpack_from('<II',data,at+16)
        out[name]=data[start:start+length]
    return out
a=sections(W/'before/pui_showcase_tests.exe');b=sections(W/'after/pui_showcase_tests.exe')
pe={}
for name in ['.text','.data','.pdata','.rdata']:
    pe[name]={'before_bytes':len(a[name]),'after_bytes':len(b[name]),'identical':a[name]==b[name],
              'different_bytes':sum(x!=y for x,y in zip(a[name],b[name]))+abs(len(a[name])-len(b[name]))}
(W/'null-code-control.json').write_text(json.dumps(pe,indent=2))
print('32 same-binary control runs /5760 full frames retained;null sections:',pe,flush=True)
