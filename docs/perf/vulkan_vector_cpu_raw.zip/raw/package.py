from pathlib import Path
import csv,gzip,hashlib,json,shutil,subprocess,sys,zipfile
R=Path(__file__).resolve().parent.parent;W=Path(__file__).resolve().parent;P=R/'docs/perf'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
assert 'Full release and new regressions passed' in (W/'validate-release.log').read_text()
for name in ['full-release','full-debug']:assert 'all steps passed' in (W/(name+'.log')).read_text()
assert 'All measurements,Debug,boundaries and final application checks passed' in (W/'post-release.log').read_text()
assert 'Matched SSE2 probe,same-binary controls and protected audit passed' in (W/'final-controls.log').read_text()
assert read(W/'framebuffer-review.json')['review_passed']
assert read(W/'showcase-final.json')['all_exact']
assert 'PENDING' not in (R/'docs/perf_vulkan_vector_cpu.md').read_text()
subprocess.run([sys.executable,str(W/'audit.py')],cwd=R,check=True)
for p in (W/'after').glob('*.exe'):
    assert digest(p)==digest(R/'out/build/x64-release/Release'/p.name),p.name

rows=[]
for phase,filename in [('before_after','frames.csv.gz'),('same_binary_control','controls-frames.csv.gz')]:
    with gzip.open(W/filename,'rt',encoding='utf-8') as f:
        rows.extend({'kind':'application_frame','phase':phase,**row} for row in csv.DictReader(f))
assert len(rows)==31680
for row in csv.DictReader((W/'kernel.csv').open()):
    rows.append({'kind':'cpu_kernel_scan','phase':'matched_sse2','case':'planner_kernel','revision':row['version'],'run':'kernel-'+row['pair'],**row})
assert len(rows)==32064
fields=['kind','phase','case','revision','pair','run','frame']+sorted({k for row in rows for k in row}-{'kind','phase','case','revision','pair','run','frame'})
frame_path=P/'vulkan_vector_cpu_frames.csv.gz'
with gzip.open(frame_path,'wt',encoding='utf-8',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)

base=read(W/'baseline.json');receipt=read(W/'measure/receipt.json');source=read(W/'timed-sources.json')
summary={'qualification_completed_local_date':'2026-11-05','base_revision':base['commit'],
         'branch':subprocess.check_output(['git','branch','--show-current'],cwd=R).decode().strip(),
         'changes':['Reuse one checked placement and source binding per native vector submission.','Reduce192-index blocks through four independent signed SSE2 min/max chains;retain scalar greedy tuples.'],
         'hardware':{'os':'Windows x64 Release/MSVC','adapter':'AMD Radeon RX 9070 XT','vendor':4098,'device':30032,'driver':8389024},
         'timed_application_frames':31680,'timed_cpu_kernel_scans':384,'discarded_timed_samples':0,
         'main':read(W/'summary.json'),'same_binary_control':read(W/'controls-summary.json'),
         'matched_sse2_component':read(W/'kernel-summary.json'),'null_code_control':read(W/'null-code-control.json'),
         'main_receipt':receipt,'same_binary_receipt':read(W/'controls/receipt.json'),
         'baseline':base,'timed_sources':source,
         'binaries':{label:{p.name:digest(p) for p in (W/label).glob('*.exe')} for label in ['before','after']},
         'reference_harness':read(W/'reference-source.json'),'simple_reference':read(W/'simple-reference/receipt.json'),
         'showcase':read(W/'showcase-final.json'),'framebuffer_review':read(W/'framebuffer-review.json'),
         'audit':read(W/'audit.json'),
         'validation':{'full_release':'passed','full_debug':'passed','native_cases_each':57,'python_tool_tests':25,'new_regression_merge_cases_each':442368,'all_exact_full_images':3600,'initial_simple_captures':360,'existing_tests_changed':False,'existing_oracles_changed':False,'unrelated_drafts_changed':False,'offs_and_amalgamation':'passed'},
         'limits':['Corrected component comparison is51percent,not the earlier unmatched74percent probe.','Higher composed SVG frame/GPU control means and some higher cold/absolute peaks remain in rawresults.','No universal GPU/startup/worst-frame improvement or foreground pacing/utilization claim.','Native immutable fixtures qualify the recorded adapter/driver.']}
json_path=P/'vulkan_vector_cpu.json';json_path.write_text(json.dumps(summary,indent=2),encoding='utf-8')

raw_path=P/'vulkan_vector_cpu_raw.zip'
skip={'baseline','before','after','simple-reference','tmp'}
with zipfile.ZipFile(raw_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(W.rglob('*')):
        if not p.is_file() or any(part in skip for part in p.relative_to(W).parts):continue
        if p.suffix not in ['.cpp','.h','.inl','.py','.json','.csv','.log','.bin','.bmp']:continue
        if p.suffix=='.bmp' and not p.stem.endswith('-after'):continue
        z.write(p,'raw/'+p.relative_to(W).as_posix())
    for name in ['receipt.json','direct.log','staged.log']:
        z.write(W/'simple-reference'/name,'raw/simple-reference/'+name)
    z.write(R/'docs/perf_vulkan_vector_cpu.md','report.md')
with zipfile.ZipFile(raw_path) as z:
    assert z.testzip() is None
    assert z.getinfo('raw/kernel-input.bin').file_size==33162744

bundle={'base_revision':base['commit'],'timed_application_frames':31680,'timed_cpu_kernel_scans':384,
        'exact_full_image_comparisons':3600,'initial_simple_captures':360,
        'files':{p.relative_to(R).as_posix():{'bytes':p.stat().st_size,'sha256':digest(p)} for p in [json_path,frame_path,raw_path,R/'tests/golden/vector_cpu/frames.zip']}}
(P/'vulkan_vector_cpu_bundle.json').write_text(json.dumps(bundle,indent=2))
print(json.dumps(bundle,indent=2))
