// Matched SSE2 component probe; no GPU work is created by this executable.
#define PUFFERUI_IMPLEMENTATION
#include <pufferui/vulkan.h>
#include <atomic>
#include <fstream>
#include <vector>

// The implementation header intentionally undefines this private macro. Restore
// its guaranteed-x64 value for the frozen reference included OUTSIDE that header.
// Without this gate a copied reference silently benchmarks the scalar body.
#define PUI_VK_INTEGER_SIMD 1
namespace pui::vk_detail
{
static_assert(INTEGER_SIMD && PUI_VK_INTEGER_SIMD == 1);
#include "kernel_legacy.inl"
} // namespace pui::vk_detail
#undef PUI_VK_INTEGER_SIMD

using span_fn = pui::vk_detail::geometry_span (*)(const pui::i32 *, pui::i32, pui::i32,
                                                 VkDeviceSize, VkDeviceSize);
static std::vector<pui::i32> indices;
__declspec(noinline) static pui::u64 run_kernel(span_fn volatile &function)
{
    pui::u64 checksum = 0;
    for (pui::i32 at = 0; at < static_cast<pui::i32>(indices.size());)
    {
        std::atomic_signal_fence(std::memory_order_seq_cst);
        const auto span = function(indices.data(), at, static_cast<pui::i32>(indices.size()),
                                   20, 32ull * 1024 * 1024);
        if (span.end <= at) std::abort();
        checksum += static_cast<pui::u64>(span.end) + span.low + span.high;
        at = span.end;
    }
    return checksum;
}
int main(int argc, char **argv)
{
    if (argc != 2) return 2;
    indices.resize(8290686);
    std::ifstream file(argv[1], std::ios::binary);
    file.read(reinterpret_cast<char *>(indices.data()), indices.size() * sizeof(pui::i32));
    if (!file || file.peek() != std::char_traits<char>::eof()) return 1;
    span_fn volatile before = &pui::vk_detail::frozen_plan_geometry_span<>;
    span_fn volatile after = &pui::vk_detail::plan_geometry_span<>;
    pui::i32 at = 0, tuples = 0;
    while (at < static_cast<pui::i32>(indices.size()))
    {
        const auto a = before(indices.data(), at, static_cast<pui::i32>(indices.size()),
                               20, 32ull * 1024 * 1024);
        const auto b = after(indices.data(), at, static_cast<pui::i32>(indices.size()),
                              20, 32ull * 1024 * 1024);
        if (a.end != b.end || a.low != b.low || a.high != b.high || a.end <= at) return 1;
        at = a.end;
        ++tuples;
    }
    std::fprintf(stderr, "reference_simd_gate=1 production_simd=%d exact_split_tuples=%d "
                          "function_addresses_equal=%d index_count=%zu\n",
                  pui::vk_detail::INTEGER_SIMD, tuples, before == after, indices.size());
    if (tuples != 3) return 1;
    std::puts("pair,version,iteration,kernel_ms,checksum");
    for (pui::i32 pair = 0; pair < 8; ++pair)
        for (pui::i32 order = 0; order < 2; ++order)
        {
            const bool old = pair % 2 == 0 ? order == 0 : order == 1;
            for (pui::i32 i = 0; i < 24; ++i)
            {
                const pui::f64 start = pui::vk_detail::wall_ms();
                const auto sum = run_kernel(old ? before : after);
                const pui::f64 ms = pui::vk_detail::wall_ms() - start;
                std::printf("%d,%s,%d,%.9f,%llu\n", pair, old ? "before" : "after", i, ms,
                              static_cast<unsigned long long>(sum));
            }
        }
    return 0;
}
