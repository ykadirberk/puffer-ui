from pathlib import Path
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent;S=json.loads((W/'summary.json').read_text());K=json.loads((W/'kernel-summary.json').read_text());A=json.loads((W/'controls-summary.json').read_text())
lines=['The main series contains 144 runs / **25920 timed frames**. Means and',
       'quantiles below pool all eight runs per revision; paired changes are medians',
       'of the eight matched run-mean changes. No control normalization is applied.','',
       '| Workload | Frame wall mean before / after (ms) | Paired change | Improving pairs | GPU mean before / after (ms) |',
       '| --- | ---: | ---: | ---: | ---: |']
for name,v in S['cases'].items():
    a,b=v['before'],v['after'];gpu=f"{a['gpu_mean_ms']:.6f} / {b['gpu_mean_ms']:.6f}" if 'gpu_mean_ms' in a else 'n/a'
    lines.append(f"| {name} | {a['wall']['mean']:.6f} / {b['wall']['mean']:.6f} | {v['paired_mean_percent']:+.2f}% | {v['improving_pairs']}/8 | {gpu} |")
lines+=['','| Workload | p95 before / after (ms) | p99 before / after (ms) | Absolute maximum before / after (ms) | Frame 0 median before / after (ms) |',
        '| --- | ---: | ---: | ---: | ---: |']
for name,v in S['cases'].items():
    a,b=v['before'],v['after'];lines.append(f"| {name} | {a['wall']['p95']:.4f} / {b['wall']['p95']:.4f} | {a['wall']['p99']:.4f} / {b['wall']['p99']:.4f} | {a['wall']['maximum']:.4f} / {b['wall']['maximum']:.4f} | {a['frame0_median_ms']:.4f} / {b['frame0_median_ms']:.4f} |")
lines+=['','| Spiral mode / frame | Matched-index median wall before / after (ms) | Median slot wait before / after (ms) |',
        '| --- | ---: | ---: |']
for name,v in S['cases'].items():
    if not name.startswith('spiral'):continue
    for frame in ['127','128']:
        a,b=v['before']['peak_frame_medians'][frame],v['after']['peak_frame_medians'][frame]
        lines.append(f"| {name} / {frame} | {a['total_ms']:.4f} / {b['total_ms']:.4f} | {a['slot_wait_ms']:.4f} / {b['slot_wait_ms']:.4f} |")
lines+=['','Simple-path run means improve in all eight pairs per upload mode. The main',
        'STAGED/cache worst decreases 20.4462 -> 17.5638 ms, but native peaks are not',
        'eliminated. DIRECT/cache and simple DIRECT absolute maxima increase. The',
        'composed SVG controls also retain higher frame/GPU means. This revision is',
        'not qualified as a universal GPU, startup or worst-frame improvement.','',
        'Every frame retains identical draw counts, logical upload bytes, native',
        'geometry/index counts, submission counts and reservations where those counters',
        'apply. Simple/composed vector draw allocations remain zero. Spiral upload',
        'reservation stays 68681728 bytes DIRECT / 135790592 bytes STAGED; source/layer',
        'image residency and instance budgets are unchanged.','',
        '### Matched SSE2 component probe and correction','',
        'The earlier exploratory review reported about 74% for an extracted planner.',
        'That reference was included after the implementation header had undefined',
        '`PUI_VK_INTEGER_SIMD`, silently selecting its scalar body. That percentage',
        'was not an old-SSE2/new-SSE2 comparison and is not used in this qualification.',
        'The actual frozen-executable frame timings and golden comparisons were',
        'unaffected. Existing report drafts are preserved; this correction records',
        'the qualification boundary without changing their historical bytes.','',
        'The corrected probe explicitly restores and asserts the guaranteed SSE2 gate',
        'around the frozen original function. Both paths use the same compilation',
        'target/flags and input: 8290686 indices captured from the actual largest',
        'frame-127 Spiral draw. All three split tuples and all checksums match. The',
        'probe creates no GPU work. Eight alternating groups of 24 complete scans per',
        'version retain 384 samples, including the first scan.','',
        '| Matched complete index scan | Before SSE2 | After SSE2 |','| --- | ---: | ---: |',
        f"| Mean (ms) | {K['before']['mean_ms']:.6f} | {K['after']['mean_ms']:.6f} |",
        f"| Median (ms) | {K['before']['median_ms']:.6f} | {K['after']['median_ms']:.6f} |",
        f"| Maximum (ms) | {K['before']['maximum_ms']:.6f} | {K['after']['maximum_ms']:.6f} |",'',
        f"The corrected paired median reduction is **{-K['paired_median_percent']:.2f}%**, not 74%.",
        'This component improvement does not imply the same reduction in total frame',
        'time: geometry production, validation, copies, GPU work and waits remain.','',
        '### Same-executable controls','',
        'Four additional alternating pairs per case compare exact copies of the',
        'current executables. These 32 runs / 5760 frames are retained separately',
        'from the before/after cohort.','',
        '| Case | A / B pooled frame mean (ms) | A-B paired change | A / B maximum (ms) | A / B GPU mean (ms) |',
        '| --- | ---: | ---: | ---: | ---: |']
for name,v in A.items():
    a,b=v['a'],v['b'];gpu=f"{a['gpu_mean_ms']:.6f} / {b['gpu_mean_ms']:.6f}" if 'gpu_mean_ms' in a else 'n/a'
    lines.append(f"| {name} | {a['mean_ms']:.6f} / {b['mean_ms']:.6f} | {v['paired_percent']:+.2f}% | {a['maximum_ms']:.4f} / {b['maximum_ms']:.4f} | {gpu} |")
lines+=['','Identical copies can have materially different pooled means and peaks. The',
        'additional cached Spiral control reaches 19.7807 ms despite the 17.5638 ms',
        'main-cohort maximum; no permanent upper bound follows from either cohort.',
        'The null before/after executables also have identical `.text`, `.data` and',
        '`.pdata` sections, with three changed bytes in `.rdata`. This demonstrates',
        'variation without a changed null algorithm, but does not establish a complete',
        'cause for every native/GPU difference. Higher composed-control means remain',
        'reported rather than normalized away.','',
        'All **31680 timed application frames** and the 384 corrected component samples',
        'are retained. No foreground FPS or Task Manager utilization claim follows',
        'from these unpaced offscreen measurements.']
validation='''Full unchanged Release and Debug `tools/run_tests.py --vulkan --format
[--release]` gates pass: 57 native cases each, all existing suites/goldens,
every example, installed core/SDL/Vulkan consumers, API/tutorial checks and
clang-format 22.1.3. All 25 portable Python tools tests pass, including the three
new fixture/completeness/readback/allocation guards. New C++ files also pass an
explicit formatting check.

- Final qualification compares **3600 complete images exactly**: 2160 original
  Spiral frames (before/after, both uploads, cache off/on and prepared/late),
  720 composed SVG frames and 720 simple-path frames. Every 180-frame sequence
  includes frame 0 and all timed peak indices. Timing runs have no readbacks;
  correctness uses the identical fixed-time workload and unchanged counters.
- Initial pre-fix simple captures add 360 full frames across DIRECT/STAGED.
  Both sets are identical; the immutable archive retains one 180-frame set and
  both hash maps. No previous fixture, assertion or tolerance was changed.
- Core/SDL/Vulkan/HarfBuzz-OFF boundaries, existing indexed STAGED tests and the
  explicit vector tutorial pass. An actual amalgamated native/HarfBuzz/STAGED
  consumer renders overlapping isolated SVGs, checks resulting color/alpha and
  reports zero validation errors. Both frozen/current fixed vector fixtures pass;
  both capture executables refuse an existing reference directory.
- Actual `pui_showcase_vulkan` checks run 1080 application frames across before/
  after SVG, 640x480 SVG and 5000-item Spiral cases. All three full BMP pairs are
  byte-identical. Candidate framebuffers were inspected for curve/stroke/gradient,
  clipping, text and layout quality. This is application-framebuffer/scripted
  evidence, not a live interaction or foreground-pacing certification.
- The protected audit preserves all 128 original test/oracle files, all 36
  initial report drafts, 360 old Spiral hashes, both new simple capture sets and
  all 242 measured source hashes. The pinned SDL submodule is clean.
- Build/check/timing phases are sequential. Preliminary harness compilation
  retries are retained separately and are not counted as completed gates.

[Machine-readable results, hashes and per-run peaks](perf/vulkan_vector_cpu.json),
[every retained application frame and corrected CPU scan](perf/vulkan_vector_cpu_frames.csv.gz),
[raw logs, commands, component input and application captures](perf/vulkan_vector_cpu_raw.zip),
and [bundle hashes](perf/vulkan_vector_cpu_bundle.json).'''
doc='D:/myimgui/docs/perf_vulkan_vector_cpu.md'
patch='*** Begin Patch\n*** Update File: '+doc+'\n@@\n-MEASUREMENTS_PENDING\n'+''.join('+'+line+'\n' for line in lines)+'@@\n-VALIDATION_PENDING\n'+''.join('+'+line+'\n' for line in validation.splitlines())+'*** End Patch\n'
print(patch)
