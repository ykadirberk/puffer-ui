from pathlib import Path
import subprocess,sys
R=Path(__file__).resolve().parent.parent;W=Path(__file__).resolve().parent
assert 'All measurements,Debug,boundaries and final application checks passed' in (W/'post-release.log').read_text()
for name in ['kernel','controls','audit']:
    print(name,flush=True)
    with (W/(name+'-final.log')).open('w',encoding='utf-8') as log:
        result=subprocess.run([sys.executable,str(W/(name+'.py'))],cwd=R,stdout=log,stderr=subprocess.STDOUT)
    if result.returncode:raise RuntimeError(name+' failed')
print('Matched SSE2 probe,same-binary controls and protected audit passed',flush=True)
