from pathlib import Path
import os,subprocess,sys
R=Path(__file__).resolve().parent.parent;W=Path(__file__).resolve().parent
os.environ['TEMP']=os.environ['TMP']=str(W/'tmp');os.environ['PYTHONUTF8']='1'
def run(name,args):
    print(name,flush=True)
    with (W/(name+'.log')).open('w',encoding='utf-8') as log:
        p=subprocess.run([str(x) for x in args],cwd=R,stdout=log,stderr=subprocess.STDOUT)
    if p.returncode:raise RuntimeError(name+' failed')
bin=R/'out/build/x64-release/Release'
for mode,flags in [('direct',[]),('staged',['--staged'])]:
    run('new-regressions-'+mode,[bin/'pui_vulkan_vector_cpu_tests.exe',*flags])
run('new-tool-regressions',[sys.executable,'-m','unittest','discover','-s','tests','-p','test_vulkan_vector_cpu_tools.py'])
fmt=R/'build-perf-review/format-tool/clang_format/data/bin/clang-format.exe'
run('new-format',[fmt,'--dry-run','--Werror','tests/test_vulkan_vector_cpu.cpp','tests/test_vulkan_vector_cpu.inl','include/pufferui/impl/vulkan_vector.inl','include/pufferui/impl/vulkan_draw.inl','include/pufferui/impl/renderer_vector.inl'])
run('full-release',[sys.executable,W/'build.py',sys.executable,'tools/run_tests.py','--vulkan','--format','--release'])
print('Full release and new regressions passed',flush=True)
