template <bool Simd = INTEGER_SIMD>
inline geometry_span frozen_plan_geometry_span(const i32 *indices, i32 start, i32 count,
                                        VkDeviceSize stride, VkDeviceSize capacity)
{
    geometry_span span{start, 0x7fffffff, 0};
    if (count - start >= 24)
    {
        // A sparse first triangle can exceed the arena on its own. Keep that
        // fallback at one triangle's reads instead of probing an entire block.
#if defined(PUFFERUI_VULKAN_INDEXED_TESTS)
        ++span_work.triangles;
#endif
        const i32 low = std::min(indices[start], std::min(indices[start + 1], indices[start + 2]));
        const i32 high =
            std::max(0, std::max(indices[start], std::max(indices[start + 1], indices[start + 2])));
        if ((static_cast<VkDeviceSize>(high) - low + 1) * stride + 3 * sizeof(i32) > capacity)
            return span;
    }
    constexpr i32 block = Simd && INTEGER_SIMD ? 192 : 24;
    while (span.end < count)
    {
        // A fitting block proves that every prefix fits: its vertex interval
        // and index bytes can only grow. Refine a boundary with the original
        // triangle rule so uploads, sparse fallback and draw order stay exact.
        if (count - span.end >= block)
        {
#if defined(PUFFERUI_VULKAN_INDEXED_TESTS)
            ++span_work.blocks;
#endif
            i32 low = 0x7fffffff, high = 0;
#if PUI_VK_INTEGER_SIMD
            if constexpr (Simd)
            {
                __m128i lower4 = _mm_set1_epi32(low), upper4 = _mm_setzero_si128();
                const auto minimum = [](__m128i a, __m128i b)
                {
                    const auto cmp = _mm_cmpgt_epi32(a, b);
                    return _mm_or_si128(_mm_and_si128(cmp, b), _mm_andnot_si128(cmp, a));
                };
                const auto maximum = [](__m128i a, __m128i b)
                {
                    const auto cmp = _mm_cmpgt_epi32(a, b);
                    return _mm_or_si128(_mm_and_si128(cmp, a), _mm_andnot_si128(cmp, b));
                };
                for (i32 i = 0; i < block; i += 4)
                {
                    const __m128i value =
                        _mm_loadu_si128(reinterpret_cast<const __m128i *>(indices + span.end + i));
                    lower4 = minimum(lower4, value);
                    upper4 = maximum(upper4, value);
#if defined(PUFFERUI_VULKAN_INTEGER_TESTS)
                    ++index_work.planning_vectors;
#endif
                }
                lower4 = minimum(lower4, _mm_shuffle_epi32(lower4, 0x4e));
                lower4 = minimum(lower4, _mm_shuffle_epi32(lower4, 0xb1));
                upper4 = maximum(upper4, _mm_shuffle_epi32(upper4, 0x4e));
                upper4 = maximum(upper4, _mm_shuffle_epi32(upper4, 0xb1));
                low = _mm_cvtsi128_si32(lower4);
                high = _mm_cvtsi128_si32(upper4);
            }
            else
#endif
                for (i32 i = 0; i < block; ++i)
                {
                    low = std::min(low, indices[span.end + i]);
                    high = std::max(high, indices[span.end + i]);
#if defined(PUFFERUI_VULKAN_INTEGER_TESTS)
                    ++index_work.planning_scalars;
#endif
                }
            low = std::min(span.low, low);
            high = std::max(span.high, high);
            if ((static_cast<VkDeviceSize>(high) - low + 1) * stride +
                    static_cast<VkDeviceSize>(span.end - start + block) * 4 <=
                capacity)
            {
                span.low = low;
                span.high = high;
                span.end += block;
                continue;
            }
        }
#if defined(PUFFERUI_VULKAN_INDEXED_TESTS)
        ++span_work.triangles;
#endif
        const i32 low =
            std::min(span.low, std::min(indices[span.end],
                                        std::min(indices[span.end + 1], indices[span.end + 2])));
        const i32 high =
            std::max(span.high, std::max(indices[span.end],
                                         std::max(indices[span.end + 1], indices[span.end + 2])));
        if ((static_cast<VkDeviceSize>(high) - low + 1) * stride +
                static_cast<VkDeviceSize>(span.end - start + 3) * 4 >
            capacity)
            break;
        span.low = low;
        span.high = high;
        span.end += 3;
    }
    return span;
}