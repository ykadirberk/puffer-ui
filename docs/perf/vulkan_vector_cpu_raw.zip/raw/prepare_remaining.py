from pathlib import Path
R=Path(__file__).resolve().parent.parent;W=Path(__file__).resolve().parent
for name in ['remaining_checks.py','showcase_checks.py']:
    text=(R/'build-vector-batchopt'/name).read_text()
    needle="o=r/'build-vector-batchopt'"
    assert text.count(needle)==1
    (W/name).write_text(text.replace(needle,"o=r/'build-vector-cpu-opt'"),encoding='utf-8')
