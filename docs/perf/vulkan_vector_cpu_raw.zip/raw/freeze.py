from pathlib import Path
import hashlib,json,shutil,subprocess
R=Path(__file__).resolve().parent.parent;W=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def files(args):return subprocess.check_output(['git',*args,'-z'],cwd=R).decode().split('\0')
tracked=files(['ls-files']);drafts=files(['ls-files','--others','--exclude-standard'])
base={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),
      'tracked':{p:digest(R/p) for p in tracked if p and (R/p).is_file()},
      'drafts':{p:digest(R/p) for p in drafts if p and (R/p).is_file()},'binaries':{}}
assert base['commit']=='a0dbe72c5e642540bcd758c69360d05e449ead9a'
assert len(base['drafts'])==36
before=W/'before';before.mkdir(exist_ok=False)
for name in ['pui_vulkan_vector_data_tests','pui_vulkan_startup_spiral_tests','pui_vulkan_native_spiral_tests','pui_showcase_tests','pui_vulkan_batch_tests','pui_showcase_vulkan','pui_demo']:
    p=R/'out/build/x64-release/Release'/(name+'.exe');target=before/p.name
    shutil.copy2(p,target);base['binaries'][name]=digest(target)
for p in (R/'include').rglob('*'):
    if p.is_file():
        target=W/'baseline'/p.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
refs=R/'build-vulkan-gaussian-fix'
base['references']={mode:{p.name:digest(p) for p in sorted((refs/('spiral-'+mode)).glob('frame-*.rgba'))} for mode in ['direct','staged']}
assert all(len(v)==180 for v in base['references'].values())
(W/'baseline.json').write_text(json.dumps(base,indent=2))
print('Frozen',base['commit'],len(base['tracked']),'tracked files,',len(base['drafts']),'drafts and',len(base['binaries']),'binaries')
