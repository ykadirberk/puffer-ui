from pathlib import Path
import hashlib,json,os,subprocess,zipfile
R=Path(__file__).resolve().parent.parent;W=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
root=W/'simple-reference';root.mkdir(exist_ok=False)
exe=W/'before/pui_vulkan_vector_cpu_tests.exe';receipt={'base_revision':json.loads((W/'baseline.json').read_text())['commit'],'executable_sha256':digest(exe),'frames':{},'format':'RGBA8,512x512,180 frames','verification_adapter':'AMD Radeon RX 9070 XT','driver':8389024}
env=os.environ.copy()
for key in ['PUFFERUI_VULKAN_VALIDATION','VK_INSTANCE_LAYERS']:env.pop(key,None)
for mode in ['direct','staged']:
    directory=root/mode;args=[str(exe),*(['--staged'] if mode=='staged' else []),'--capture-reference',str(directory)]
    print('Capture',mode,flush=True)
    result=subprocess.run(args,cwd=R,env=env,capture_output=True,text=True,timeout=180)
    (root/(mode+'.log')).write_text(result.stdout+result.stderr)
    if result.returncode:raise RuntimeError(mode+': '+str(result.returncode)+' '+result.stderr)
    hashes={p.name:digest(p) for p in sorted(directory.glob('frame-*.rgba'))};assert len(hashes)==180
    receipt['frames'][mode]=hashes
assert receipt['frames']['direct']==receipt['frames']['staged']
(root/'receipt.json').write_text(json.dumps(receipt,indent=2))
fixture=R/'tests/golden/vector_cpu';fixture.mkdir(exist_ok=False)
with zipfile.ZipFile(fixture/'frames.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted((root/'direct').glob('frame-*.rgba')):z.write(p,p.name)
    z.write(root/'receipt.json','receipt.json')
with zipfile.ZipFile(fixture/'frames.zip') as z:assert z.testzip() is None
print('360 old-source captures,180 distinct immutable frames; DIRECT/STAGED exact',flush=True)
