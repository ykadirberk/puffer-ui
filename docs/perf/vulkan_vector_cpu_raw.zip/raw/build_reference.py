from pathlib import Path
import hashlib,json,os,subprocess,sys
R=Path(__file__).resolve().parent.parent;W=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools'));from run_tests import import_msvc_env
import_msvc_env();tmp=W/'tmp';tmp.mkdir(exist_ok=True);os.environ['TEMP']=os.environ['TMP']=str(tmp)
B=R/'out/build/x64-release'
args=['cl','/nologo','/std:c++20','/EHsc','/O2','/Ob2','/MD','/GL','/DNDEBUG','/DPUFFERUI_VECTOR_CPU_BASELINE','/DPUFFERUI_ENABLE_VULKAN','/DPUFFERUI_ENABLE_HARFBUZZ','/DPUFFERUI_ENABLE_SDL3']
args+=['/DPUFFERUI_ASSET_DIR="'+(R/'assets').as_posix()+'"']
for p in [W/'baseline/include',R/'vendored/stb',B/'vendored/SDL/include-revision',R/'vendored/SDL/include',R/'build-vulkan-compute/harfbuzz-src/src',Path('E:/VulkanSDK/1.4.335.0/include')]:args+=['/I'+str(p)]
args += [str(R/'tests/test_vulkan_vector_cpu.cpp'),'/Fe'+str(W/'before/pui_vulkan_vector_cpu_tests.exe'),'/Fo'+str(W/'before/vector-reference.obj'),'/link','/LTCG','/INCREMENTAL:NO']
args += [str(B/'vendored/SDL/SDL3-static.lib'),'E:/VulkanSDK/1.4.335.0/Lib/vulkan-1.lib',str(B/'_deps/pufferui_harfbuzz-build/harfbuzz-gpu.lib'),str(B/'_deps/pufferui_harfbuzz-build/harfbuzz.lib')]
args += [x+'.lib' for x in ['kernel32','user32','gdi32','winmm','imm32','version','uuid','advapi32','setupapi','shell32','hid','dinput8','uiautomationcore','comctl32','ole32','oleaut32','winspool','comdlg32']]
(W/'reference-command.json').write_text(json.dumps(args,indent=2))
subprocess.run(args,cwd=R,check=True)
(W/'reference-source.json').write_text(json.dumps({'base_commit':json.loads((W/'baseline.json').read_text())['commit'],'harness_sha256':hashlib.sha256((R/'tests/test_vulkan_vector_cpu.cpp').read_bytes()).hexdigest(),'headers':{p.relative_to(W/'baseline').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (W/'baseline').rglob('*') if p.is_file()}},indent=2))
