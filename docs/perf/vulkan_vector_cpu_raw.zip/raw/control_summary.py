from pathlib import Path
import csv,gzip,json,statistics
W=Path(__file__).resolve().parent;O=W/'controls';receipt=json.loads((O/'receipt.json').read_text());out={};frames=[]
for case in sorted({r['case'] for r in receipt['runs']}):
    values={}
    for label in ['a','b']:
        selected=[r for r in receipt['runs'] if r['case']==case and r['revision']==label]
        rows=[]
        for run in selected:
            for row in csv.DictReader((O/(run['name']+'.csv')).open()):
                detailed={'case':case,'revision':label,'pair':run['pair'],'run':run['name'],**row};rows.append(detailed);frames.append(detailed)
        info={'mean_ms':statistics.mean(float(r['total_ms']) for r in rows),'maximum_ms':max(float(r['total_ms']) for r in rows),'run_means':[r['summary']['wall']['mean'] for r in selected]}
        if case!='null':info['gpu_mean_ms']=statistics.mean(r['summary']['gpu_total_ms']/180 for r in selected)
        values[label]=info
    values['paired_percent']=statistics.median((b/a-1)*100 for a,b in zip(values['a']['run_means'],values['b']['run_means']))
    out[case]=values;print(case,values)
(W/'controls-summary.json').write_text(json.dumps(out,indent=2))
assert len(frames)==5760
fields=['case','revision','pair','run','frame']+sorted({k for r in frames for k in r}-{'case','revision','pair','run','frame'})
with gzip.open(W/'controls-frames.csv.gz','wt',encoding='utf-8',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(frames)
