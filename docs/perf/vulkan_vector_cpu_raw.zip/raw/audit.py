from pathlib import Path
import hashlib,json,subprocess,zipfile
R=Path(__file__).resolve().parent.parent;W=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((W/'baseline.json').read_text());allowed={'AGENTS.md','CMakeLists.txt','docs/vector_paths.md','docs/vulkan.md','include/pufferui/impl/renderer_vector.inl','include/pufferui/impl/vulkan_vector.inl','include/pufferui/impl/vulkan_draw.inl'}
for name,expected in base['tracked'].items():
    if name not in allowed:assert digest(R/name)==expected,name
for name,expected in base['drafts'].items():assert digest(R/name)==expected,name
for mode,values in base['references'].items():
    for name,expected in values.items():assert digest(R/'build-vulkan-gaussian-fix'/('spiral-'+mode)/name)==expected
reference=json.loads((W/'simple-reference/receipt.json').read_text())
for mode,values in reference['frames'].items():
    for name,expected in values.items():assert digest(W/'simple-reference'/mode/name)==expected
assert digest(W/'before/pui_vulkan_vector_cpu_tests.exe')==reference['executable_sha256']
source=json.loads((W/'reference-source.json').read_text())
assert digest(W/'reference-harness.cpp')==source['harness_sha256']
timed=json.loads((W/'timed-sources.json').read_text())
for name,expected in timed.items():assert digest(R/name)==expected,name
assert not subprocess.check_output(['git','-C','vendored/SDL','status','--porcelain'],cwd=R).strip()
with zipfile.ZipFile(R/'tests/golden/vector_cpu/frames.zip') as z:
    assert z.testzip() is None
    recorded=json.loads(z.read('receipt.json'))
    assert recorded==reference
    for name,expected in reference['frames']['direct'].items():assert hashlib.sha256(z.read(name)).hexdigest()==expected
out={'old_tracked_files_protected':len(base['tracked'])-len(allowed),'original_test_oracle_files_unchanged':sum(p.startswith('tests/') for p in base['tracked']),'unrelated_report_drafts_unchanged':len(base['drafts']),'spiral_reference_hashes_unchanged':360,'simple_capture_hashes_unchanged':360,'timed_source_hashes_unchanged':len(timed),'sdl_submodule_clean':True}
(W/'audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
