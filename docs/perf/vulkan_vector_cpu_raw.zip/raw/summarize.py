from pathlib import Path
import csv,gzip,hashlib,json,statistics,sys
R=Path(__file__).resolve().parent.parent;W=Path(__file__).resolve().parent;O=W/'measure'
sys.path.insert(0,str(R/'tools'));from compare_vulkan_batches import distribution
receipt=json.loads((O/'receipt.json').read_text());summary={'cases':{}};all_rows=[]
for case in sorted({r['case'] for r in receipt['runs']}):
    values={}
    for label in ['before','after']:
        runs=[r for r in receipt['runs'] if r['case']==case and r['revision']==label];rows=[]
        for run in runs:
            path=O/'batches'/(run['name']+'.csv')
            for row in csv.DictReader(path.open()):
                row={k:float(v) for k,v in row.items()}
                detailed={'case':case,'revision':label,'pair':run['pair'],'run':run['name'],**row}
                rows.append(detailed);all_rows.append(detailed)
        info={'wall':distribution([r['total_ms'] for r in rows]),
              'frame0_median_ms':statistics.median(r['total_ms'] for r in rows if r['frame']==0),
              'run_means':[r['summary']['wall']['mean'] for r in runs],
              'top10':sorted(rows,key=lambda r:r['total_ms'],reverse=True)[:10],
              'peak_frame_medians':{str(f):{k:statistics.median(r[k] for r in rows if r['frame']==f) for k in rows[0] if k not in ['case','revision','pair','run','frame']} for f in [0,90,120,125,126,127,128,129,150]}}
        if 'gpu_total_ms' in runs[0]['summary']:
            info['gpu_mean_ms']=statistics.mean(r['summary']['gpu_total_ms']/180 for r in runs)
        for key in ['setup_ms','image_bytes','path_residency_bytes','resident_bytes','total_upload_bytes']:
            if key in runs[0]['summary'] and isinstance(runs[0]['summary'][key],(int,float)):
                info[key]=statistics.median(r['summary'][key] for r in runs)
        values[label]=info
    a,b=values['before'],values['after']
    changes=[(y/x-1)*100 for x,y in zip(a['run_means'],b['run_means'])]
    values['paired_mean_percent']=statistics.median(changes);values['pair_changes']=changes
    values['improving_pairs']=sum(v<0 for v in changes)
    values['pooled_mean_percent']=(b['wall']['mean']/a['wall']['mean']-1)*100
    if 'gpu_mean_ms' in a:values['gpu_mean_percent']=(b['gpu_mean_ms']/a['gpu_mean_ms']-1)*100
    summary['cases'][case]=values
    print(case,'CPU',round(a['wall']['mean'],6),'->',round(b['wall']['mean'],6),'paired%',round(values['paired_mean_percent'],2),'improve',values['improving_pairs'],'GPU',round(a.get('gpu_mean_ms',0),6),'->',round(b.get('gpu_mean_ms',0),6),'max',round(a['wall']['maximum'],4),'->',round(b['wall']['maximum'],4),flush=True)
assert len(all_rows)==25920
indexed={(r['case'],r['revision'],r['pair'],r['frame']):r for r in all_rows}
for row in all_rows:
    if row['revision']!='before':continue
    other=indexed[row['case'],'after',row['pair'],row['frame']]
    fields=(['draws','upload_bytes','draw_cpp_allocations','draw_buffer_allocations','total_upload_bytes'] if row['case'].startswith('vector') else ['vertices','indices','draws','submissions','upload_bytes','resident_bytes','buffer_allocations','draw_buffer_allocations','glyph_upload_bytes'] if row['case'].startswith('spiral') else ['count','draws','vertices','indices'])
    assert all(row[k]==other[k] for k in fields),(row['case'],row['pair'],row['frame'])
summary['timed_frames']=len(all_rows);summary['runs']=len(receipt['runs'])
summary['exact_full_images']=sum(g['frames'] for g in receipt['goldens'])
assert summary['exact_full_images']==3600
(W/'summary.json').write_text(json.dumps(summary,indent=2))
fields=['case','revision','pair','run','frame']+sorted({k for row in all_rows for k in row}-{'case','revision','pair','run','frame'})
with gzip.open(W/'frames.csv.gz','wt',encoding='utf-8',newline='') as file:
    writer=csv.DictWriter(file,fieldnames=fields);writer.writeheader();writer.writerows(all_rows)
sources={p.relative_to(R).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['include','src','examples','tests','tools'] for p in (R/folder).rglob('*') if p.is_file() and p.suffix in ['.h','.cpp','.inl','.py','.ps1','.vert','.frag','.glsl'] and '__pycache__' not in p.parts}
(W/'timed-sources.json').write_text(json.dumps(sources,indent=2))
