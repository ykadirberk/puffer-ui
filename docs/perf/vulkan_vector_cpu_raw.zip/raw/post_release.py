from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
R=Path(__file__).resolve().parent.parent;W=Path(__file__).resolve().parent
assert 'Full release and new regressions passed' in (W/'validate-release.log').read_text()
os.environ['TEMP']=os.environ['TMP']=str(W/'tmp');os.environ['PYTHONUTF8']='1'
def run(name,args):
    print(name,flush=True)
    with (W/(name+'.log')).open('w',encoding='utf-8') as log:
        p=subprocess.run([str(x) for x in args],cwd=R,stdout=log,stderr=subprocess.STDOUT)
    if p.returncode:raise RuntimeError(name+' failed')
after=W/'after';after.mkdir(exist_ok=False)
for name in ['pui_vulkan_vector_data_tests','pui_vulkan_startup_spiral_tests','pui_vulkan_native_spiral_tests','pui_showcase_tests','pui_vulkan_batch_tests','pui_vulkan_vector_cpu_tests','pui_showcase_vulkan','pui_demo']:
    source=R/'out/build/x64-release/Release'/(name+'.exe');shutil.copy2(source,after/source.name)
run('measure',[sys.executable,R/'tools/compare_vulkan_vector_cpu.py','--before',W/'before','--after',after,'--spiral-references',R/'build-vulkan-gaussian-fix','--simple-references',R/'tests/golden/vector_cpu/frames.zip','--vector-references',R/'tests/golden/vector_batch/frames.zip','--output',W/'measure','--pairs','8'])
run('summary',[sys.executable,W/'summarize.py'])
run('full-debug',[sys.executable,W/'build.py',sys.executable,'tools/run_tests.py','--vulkan','--format'])
run('remaining-checks',[sys.executable,W/'remaining_checks.py'])
run('showcase-final',[sys.executable,W/'showcase_checks.py'])
print('All measurements,Debug,boundaries and final application checks passed',flush=True)
