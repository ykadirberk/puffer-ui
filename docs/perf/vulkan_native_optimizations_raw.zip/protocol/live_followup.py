from pathlib import Path
import copy, hashlib, io, json, subprocess, zipfile

root=Path(__file__).resolve().parents[1]
work=root/'build-vulkan-native-opt3'
code_commit='126afac678535f7b2e85b615383be7acc0dd182b'
def digest(data): return hashlib.sha256(data).hexdigest()
def committed(path): return subprocess.check_output(['git','show',code_commit+':'+path],cwd=root)
def load(path): return json.loads(path.read_text(encoding='utf-8-sig'))
report_path='docs/perf/vulkan_native_optimizations_final.json'
old= json.loads(committed(report_path))
for mapping in [old['measurements']['source_hashes'],old['measurements']['existing_tests'],old['preserved_unrelated']]:
    assert all(digest((root/p).read_bytes())==h for p,h in mapping.items())
events=load(work/'live-app-events.json')
assert events==[], 'Inspect any application error before accepting live verification'
live=dict(
    schema_version=1,date='2026-10-30',code_commit=code_commit,status='passed',
    scope='Foreground appearance and bounded functional smoke checks; no new performance cohort or foreground FPS certification.',
    standard_no_argument_launch=True,foreground_inspected=True,demo_foreground_inspected=True,
    foreground_fps_certified=False,all_opened_project_windows_closed=True,
    executables={name:dict(path=str(root/'out/build/x64-release/Release'/name),
                          sha256=digest((root/'out/build/x64-release/Release'/name).read_bytes()),args=[])
                 for name in ['pui_showcase_vulkan.exe','pui_demo.exe']},
    showcase=dict(
        label='vulkan showcase',startup_vsync='ON',startup_hud_fps_approx=180,
        vsync_sequence=['ON','OFF','ON'],off_transition_hud_fps=182,
        off_hud_observed_snapshots_fps=[1038,1142,1079,1143,955,1132,1148,1067,1020],
        restored_on_transition_hud_fps=922,
        restored_on_hud_fps_approx=180,
        layout=dict(mode='Spiral',tile_size=64,initial_items=14,final_items=17,actual_mouse_add_clicks=3),
        pages_observed=['Overview','Layout lab','Effects','Overview'],
        scrolling='Overview down/up observed; top position restored after settling.',
        effects='Liquid lens moved over colored shapes; blur and overlaid text updated.',
        appearance='No persistent glyph, blending, clipping or geometry corruption observed in the inspected states.',
        closed_normally=True),
    demo=dict(
        windows=['PufferUI (next) - window 1','PufferUI (next) - window 2'],
        main_button_clicks=[0,1],second_window_add_score_main_counter=[1,2],
        amount_slider=[3.50,6.90],inspector_amount=6.90,
        physical_keyboard_values=['PufferUI','aPufferUI','PufferUI'],
        physical_keyboard_actions=['a','BackSpace'],
        log_scroll_visible_lines_before=[1,6],log_scroll_visible_lines_after=[6,11],
        lifecycle=['two windows inspected','close window 2 from main control',
                   'main remains alive and shows Open window 2','close main with Alt+F4',
                   'no showcase/demo windows remain'],
        appearance='Both windows, shared model updates, text, cards, floating Inspector and log clipping inspected.',
        bulk_text_or_paste_verified=False),
    automation_notes=[
        'Initial activation attempts reported user input / missing foreground PID; fresh window selection and capture recovered. The initial disappeared windows were not classified as application crashes.',
        'One window-2 accessibility click produced out-of-bounds coordinates; the observed screenshot coordinate route succeeded.',
        'Bulk type_text attempts did not produce the requested string; direct set_value reported that the field is not settable. These methods are not certified. A physical a key and Backspace were observed in both screenshot and accessibility value.',
        'Assertions about pixel equality and performance remain the previous deterministic golden/timing results; these live checks add functional evidence only.'
    ],
    application_event_check=dict(event_ids=[1000,1001],lookback_minutes=60,
        filter_executables=['pui_showcase_vulkan.exe','pui_demo.exe'],matching_events=0,
        limitation='No matching event was found in this bounded query; no universal crash-free guarantee.'))
live_bytes=(json.dumps(live,indent=2)+'\n').encode()
(work/'live.json').write_bytes(live_bytes)
live_path='docs/perf/vulkan_native_optimizations_live.json'
(root/live_path).write_bytes(live_bytes)

raw_path='docs/perf/vulkan_native_optimizations_raw.zip'
raw_old=committed(raw_path)
buffer=io.BytesIO()
with zipfile.ZipFile(io.BytesIO(raw_old)) as original, zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for entry in original.infolist():
        if entry.filename=='live.json':
            output.writestr('live-20261029-locked.json',original.read(entry))
        else:
            output.writestr(entry,original.read(entry))
    output.writestr('live.json',live_bytes)
    output.writestr('live-app-events.json',(work/'live-app-events.json').read_bytes())
    output.writestr('protocol/live_followup.py',Path(__file__).read_bytes())
(root/raw_path).write_bytes(buffer.getvalue())
with zipfile.ZipFile(io.BytesIO(raw_old)) as original, zipfile.ZipFile(root/raw_path) as updated:
    for entry in original.infolist():
        destination='live-20261029-locked.json' if entry.filename=='live.json' else entry.filename
        assert original.read(entry)==updated.read(destination),entry.filename
    assert updated.read('live.json')==live_bytes

final=copy.deepcopy(old)
final['live']=live
final['artifact_hashes'][Path(raw_path).name]=digest((root/raw_path).read_bytes())
final['artifact_hashes'][Path(live_path).name]=digest(live_bytes)
final['archived_files']=['live-20261029-locked.json' if p=='live.json' else p for p in old['archived_files']]
final['archived_files']+=['live.json','live-app-events.json','protocol/live_followup.py']
final['validation']['live_followup']=dict(date='2026-10-30',code_commit=code_commit,
    production_source_hashes_preserved=192,original_test_oracle_hashes_preserved=77,
    unrelated_draft_hashes_preserved=9,all_original_raw_payloads_preserved=True,
    new_full_suite_run=False,live_receipt_byte_policy='docs/perf/.gitattributes preserves exact receipt bytes',
    reason='Documentation/evidence-only follow-up; measured implementation and tests unchanged.')
for key in old:
    if key not in ['live','artifact_hashes','archived_files','validation']:
        assert old[key]==final[key],key
for key,value in old['validation'].items():assert final['validation'][key]==value
(root/report_path).write_text(json.dumps(final,indent=2)+'\n')
assert (root/'docs/perf/vulkan_native_optimizations_frames.csv.gz').read_bytes()==committed('docs/perf/vulkan_native_optimizations_frames.csv.gz')
print('Live receipt added; all timed/golden data, original raw payloads, 192 source hashes, 77 original test/oracles and nine drafts preserved',flush=True)
