from pathlib import Path
import csv, hashlib, importlib.util, json, os, shutil, subprocess, time

root = Path(__file__).resolve().parents[1]
work = root / 'build-vulkan-native-opt3'
source = work/'pdh_reference.py'
if not source.exists(): shutil.copy2(root/'build-vulkan-native/pdh_reference.py', source)
spec = importlib.util.spec_from_file_location('native_opt3_pdh', source)
pdh = importlib.util.module_from_spec(spec); spec.loader.exec_module(pdh)
out = work/'gpu-qualified-final'; out.mkdir(exist_ok=False)
binaries = {side: work/'qualified-matched'/(side+'.exe') for side in ['before', 'after']}
runs = []
environment = os.environ.copy()
for name in ['PUFFERUI_TEST_PAGE', 'PUFFERUI_TEST_COVERAGE_BYTES', 'PUFFERUI_TEST_LEGACY_VERTICES']:
    environment.pop(name, None)
for repeat in range(3):
    for staged in [False, True]:
        for side in (['before', 'after'] if repeat % 2 == 0 else ['after', 'before']):
            stem = out/f'spiral-{side}-staged{int(staged)}-{repeat}'
            command = [str(binaries[side]), '--bench', '--windowed', '--hz', '60',
                       *(['--staged'] if staged else [])]
            query = pdh.Query(); samples = []; started = time.perf_counter()
            with stem.with_suffix('.csv').open('w') as stdout, stem.with_suffix('.log').open('w') as stderr:
                process = subprocess.Popen(command, cwd=root, env=environment, stdout=stdout, stderr=stderr,
                                           creationflags=subprocess.CREATE_NO_WINDOW)
                try:
                    query.sample(process.pid)
                    while process.poll() is None:
                        if time.perf_counter()-started > 45:
                            process.kill(); raise TimeoutError(command)
                        time.sleep(.25)
                        samples.extend(dict(elapsed=time.perf_counter()-started, pid=process.pid, **sample)
                                       for sample in query.sample(process.pid))
                finally:
                    query.close(query.handle)
                if process.wait(): raise RuntimeError(stem)
            records = [row for row in csv.DictReader(stem.with_suffix('.csv').read_text().splitlines())
                       if row.get('frame', '').isdecimal()]
            assert [int(row['frame']) for row in records] == list(range(180))
            stem.with_suffix('.pdh.json').write_text(json.dumps(samples, indent=2))
            runs.append(dict(side=side, staged=staged, repeat=repeat, command=command,
                             frames=180, elapsed=time.perf_counter()-started, summary=pdh.summarize(samples)))
            print(side, staged, repeat, 'PDH complete', flush=True)
receipt = dict(protocol='5000-item Spiral; per-PID Windows PDH; hidden native WSI; VSync off; fixed 60 Hz harness cap; all physical engines and invalid samples retained; no foreground FPS certification',
               binaries={side: dict(path=str(exe), sha256=hashlib.sha256(exe.read_bytes()).hexdigest())
                         for side, exe in binaries.items()},
               runs=runs)
(out/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
