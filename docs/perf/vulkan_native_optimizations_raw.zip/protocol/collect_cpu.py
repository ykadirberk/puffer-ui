from pathlib import Path
import csv, hashlib, io, json, os, statistics, subprocess, time

root = Path(__file__).resolve().parents[1]
work = root / 'build-vulkan-native-opt3'
out = work / 'cpu-qualified'
out.mkdir(exist_ok=False)
cases = {
    'harfbuzz': {'before': work/'before/hb-cpu.exe', 'after': work/'hb-after.exe'},
    'null-core': {'before': work/'before/pui_core_bench.exe',
                  'after': root/'out/build/x64-release/Release/pui_core_bench.exe'},
}
rows, runs = [], []
for repeat in range(6):
    for family, binaries in cases.items():
        for side in (['before', 'after'] if repeat % 2 == 0 else ['after', 'before']):
            exe = binaries[side]
            started = time.perf_counter()
            result = subprocess.run([str(exe)], cwd=root, capture_output=True,
                                    text=True, check=True, timeout=90)
            stem = out/f'{family}-{side}-{repeat}'
            stem.with_suffix('.csv').write_text(result.stdout)
            stem.with_suffix('.log').write_text(result.stderr)
            records = list(csv.DictReader(io.StringIO(result.stdout)))
            assert len(records) == (9 if family == 'harfbuzz' else 8), records
            rows.extend(dict(family=family, side=side, repeat=repeat, **row) for row in records)
            runs.append(dict(family=family, side=side, repeat=repeat,
                             process_ms=(time.perf_counter()-started)*1000))
            print(family, side, repeat, 'passed', flush=True)
fields = list(dict.fromkeys(key for row in rows for key in row))
with (out/'frames.csv').open('w', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader(); writer.writerows(rows)
receipt = dict(protocol='Six alternating runs; actual CPU-only implementation; no GPU device in text probe; original null core workloads unchanged',
               binaries={family: {side: dict(path=str(exe), sha256=hashlib.sha256(exe.read_bytes()).hexdigest())
                                  for side, exe in binaries.items()} for family, binaries in cases.items()},
               source=hashlib.sha256((work/'bench_hb_cpu.cpp').read_bytes()).hexdigest(),
               runs=runs, rows=rows)
(out/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
