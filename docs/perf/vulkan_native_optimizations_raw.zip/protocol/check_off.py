from pathlib import Path
import os, sys, subprocess

root = Path(__file__).resolve().parents[1]
work = root / 'build-vulkan-native-opt3'
sys.path.insert(0, str(root / 'tools'))
from run_tests import import_msvc_env
import_msvc_env()
os.environ['VULKAN_SDK'] = 'E:/VulkanSDK/1.4.335.0'
build = work / 'off-build'
commands = [
    ['cmake', '-S', str(root), '-B', str(build), '-G', 'Ninja',
     '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_MSVC_DEBUG_INFORMATION_FORMAT=Embedded',
     '-DPUFFERUI_WITH_VULKAN=ON', '-DPUFFERUI_WITH_HARFBUZZ=OFF',
     '-DPUFFERUI_WITH_SDL3=OFF', '-DPUFFERUI_BUILD_EXAMPLES=OFF'],
    ['cmake', '--build', str(build), '--target', 'pui_vulkan_tests',
     'pui_vulkan_interaction_tests', '-j', '3'],
    [str(build / 'Release/pui_vulkan_tests.exe')],
    [str(build / 'Release/pui_vulkan_interaction_tests.exe')],
    [str(build / 'Release/pui_vulkan_interaction_tests.exe'), '--staged'],
]
with (work / 'harfbuzz-off.log').open('w') as log:
    for command in commands:
        log.write('COMMAND ' + repr(command) + '\n'); log.flush()
        subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT, check=True)
print('Native HarfBuzz OFF + SDL OFF: direct/staged passed', flush=True)
