from pathlib import Path
import os,sys,subprocess,shutil
root=Path(__file__).resolve().parents[1]
work=root/'build-vulkan-native-opt3'
sys.path.insert(0,str(root/'tools'))
from run_tests import import_msvc_env
import_msvc_env()
manifest=Path(os.environ['VSINSTALLDIR'])/'VC/Tools/MSVC'/os.environ['VCToolsVersion']/'include/manifest/segmentheap.manifest'
libs=root/'out/build/x64-release'
system=['kernel32','user32','gdi32','winmm','imm32','version','uuid','advapi32','setupapi','shell32','hid','dinput8','uiautomationcore','comctl32','ole32','oleaut32','winspool','comdlg32']
hb=root/'build-vulkan-compute/harfbuzz-src/src'
common=['cl','/nologo','/std:c++20','/EHsc','/O2','/Ob2','/GL','/MD','/DNDEBUG',
    '/DPUFFERUI_ENABLE_VULKAN','/DPUFFERUI_ENABLE_SDL3','/DPUFFERUI_ENABLE_HARFBUZZ',
    '/DPUFFERUI_ASSET_DIR="'+(root/'assets').as_posix()+'"','/I'+str(root/'vendored/stb'),
    '/I'+str(root/'vendored/SDL/include'),'/I'+str(hb),'/IE:/VulkanSDK/1.4.335.0/Include']
links=['/link','/LTCG','/MANIFEST:EMBED','/MANIFESTINPUT:'+str(manifest),str(libs/'vendored/SDL/SDL3-static.lib'),
       str(libs/'_deps/pufferui_harfbuzz-build/harfbuzz.lib'),str(libs/'_deps/pufferui_harfbuzz-build/harfbuzz-gpu.lib'),
       'E:/VulkanSDK/1.4.335.0/Lib/vulkan-1.lib',*[name+'.lib' for name in system]]
with (work/'build-probes.log').open('w') as log:
    baseline=work/('before/optimization-bench-spiral.exe' if '--spiral-wrapper' in sys.argv else 'before/optimization-bench.exe')
    if '--after-only' not in sys.argv:
        assert not baseline.exists()
        command=[*common,'/DPUFFERUI_OPT3_BASELINE','/DPUFFERUI_NATIVE_TELEMETRY',
            '/I'+str(work/'before/include'),str(root/'tests/bench_vulkan_native_optimizations.cpp'),
            '/Fo'+str(baseline.with_suffix('.obj')),'/Fe'+str(baseline),
            *links,str(work/'before/pufferui_vulkan.lib')]
        log.write(repr(command)+'\n');log.flush();subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
    if '--spiral-wrapper' in sys.argv:
        print('Matched Spiral-only before wrapper built; original frozen artifacts unchanged',flush=True)
        sys.exit(0)
    source=work/'bench_hb_cpu.cpp';shutil.copy2(root/'build-vulkan-native/bench_hb_cpu.cpp',source)
    command=[*common,'/I'+str(root/'include'),str(source),'/Fo'+str(work/'hb-after.obj'),'/Fe'+str(work/'hb-after.exe'),*links]
    log.write(repr(command)+'\n');log.flush();subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Frozen before showcase and actual CPU HarfBuzz probes built',flush=True)
