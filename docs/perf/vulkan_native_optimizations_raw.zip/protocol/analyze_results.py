from pathlib import Path
from collections import defaultdict
import csv, hashlib, json, statistics, struct

root=Path(__file__).resolve().parents[1]; work=root/'build-vulkan-native-opt3'
receipt=json.loads((work/'qualified-matched/receipt.json').read_text())
rows=list(csv.DictReader((work/'qualified-matched/frames.csv').open()))
cpu=json.loads((work/'cpu-qualified/receipt.json').read_text())
gpu=json.loads((work/'gpu-qualified-final/receipt.json').read_text())
def med(values): return statistics.median(values)
def dist(values):
    values=sorted(values)
    return dict(mean=statistics.mean(values),median=med(values),p95=values[int((len(values)-1)*.95)],
                p99=values[int((len(values)-1)*.99)],maximum=values[-1],minimum=values[0])
summary=[]
for staged in [False,True]:
    before={r['repeat']:r for r in receipt['runs'] if r['staged']==staged and r['label']=='before'}
    for label in ['before','after','after-no-coverage','after-legacy-no-coverage']:
        runs=[r for r in receipt['runs'] if r['staged']==staged and r['label']==label]
        frames=[r for r in rows if int(r['staged'])==int(staged) and r['label']==label]
        summary.append(dict(staged=staged,label=label,frames=len(frames),
            run_mean_median_ms=med([r['wall']['mean'] for r in runs]),
            wall=dist([float(r['total_ms']) for r in frames]),
            cold=dist([r['cold_ms'] for r in runs]),
            gpu_median_ms=med([r['gpu_ms'] for r in runs]),
            gpu_range_ms=[min(r['gpu_ms'] for r in runs),max(r['gpu_ms'] for r in runs)],
            process_median_ms=med([r['process_ms'] for r in runs]),
            capacity_bytes=max(int(r['resident_bytes']) for r in frames),
            average_upload_bytes=statistics.mean([int(r['upload_bytes']) for r in frames]),
            glyph_upload_bytes=statistics.mean([int(r['glyph_upload_bytes']) for r in frames]),
            draw_buffer_allocations=sum(int(r['draw_buffer_allocations']) for r in frames),
            paired_wall_change_percent=dist([(r['wall']['mean']/before[r['repeat']]['wall']['mean']-1)*100 for r in runs]),
            optimization=runs[0]['optimization'],
            peaks=[dict(repeat=r['repeat'],frame=r['peak_frame'],ms=r['wall']['maximum']) for r in runs]))
cpu_summary=[]
groups=defaultdict(lambda:defaultdict(list))
for row in cpu['rows']:
    key=(row['family'],row.get('mode','null'),row.get('workload',row.get('case')))
    groups[key][row['side']].append(row)
for (family,mode,name),sides in groups.items():
    item=dict(family=family,mode=mode,workload=name)
    field='total_ms' if family=='harfbuzz' else 'ms_per_iteration'
    item['values']={side:dist([float(row[field]) for row in records]) for side,records in sides.items()}
    if family=='harfbuzz':
        item['shapes']={side:sorted({int(r['shape_calls']) for r in rs}) for side,rs in sides.items()}
        item['outlines']={side:sorted({int(r['outline_encodes']) for r in rs}) for side,rs in sides.items()}
    else:
        item['allocations']={side:sorted({float(r['allocations_per_iteration']) for r in rs}) for side,rs in sides.items()}
    item['change_percent']=(item['values']['after']['median']/item['values']['before']['median']-1)*100
    cpu_summary.append(item)
gpu_summary=[]
for staged in [False,True]:
    keys=sorted({key for r in gpu['runs'] if r['staged']==staged for key in r['summary']})
    for key in keys:
        sides={side:[r['summary'][key] for r in gpu['runs'] if r['staged']==staged and r['side']==side and key in r['summary']] for side in ['before','after']}
        if any(not values for values in sides.values()):continue
        values={side:dict(median_mean=med([v['mean'] for v in records]),maximum=max(v['max'] for v in records),samples=sum(v['samples'] for v in records)) for side,records in sides.items()}
        gpu_summary.append(dict(staged=staged,counter=key,values=values))
analysis=dict(spiral=summary,cpu=cpu_summary,pdh=gpu_summary,
              timed_frames=len(rows),exact_frames=receipt['exact_frames'])
(work/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n')
for s in summary:print(s['staged'],s['label'],'wall',round(s['run_mean_median_ms'],4),'gpu',round(s['gpu_median_ms'],4),'cold',round(s['cold']['median'],3),'worst',s['wall']['maximum'],'capacity',s['capacity_bytes'],'upload',round(s['average_upload_bytes']),'paired',round(s['paired_wall_change_percent']['median'],2),'stats',s['optimization'])
for s in cpu_summary:print('CPU',s['mode'],s['workload'],round(s['values']['before']['median'],6),round(s['values']['after']['median'],6),round(s['change_percent'],2),s.get('shapes',s.get('allocations')))
for s in gpu_summary:
    if 'engtype_3D' in s['counter'] or not s['counter'].startswith('engine/'):
        print('PDH',s['staged'],s['counter'],s['values'])
