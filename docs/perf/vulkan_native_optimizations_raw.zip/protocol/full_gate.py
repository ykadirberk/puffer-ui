from pathlib import Path
import os,sys,subprocess,json,hashlib
root=Path(__file__).resolve().parents[1]
work=root/'build-vulkan-native-opt3'
sys.path.insert(0,str(root/'tools'))
from run_tests import import_msvc_env
import_msvc_env()
os.environ['VULKAN_SDK']='E:/VulkanSDK/1.4.335.0'
os.environ['PATH']=str(root/'build-perf-review/format-tool/clang_format/data/bin')+os.pathsep+os.environ['PATH']
baseline=json.loads((work/'baseline.json').read_text())
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in baseline['existing_tests'].items())
for config in ['release','debug']:
    preset='x64-'+config
    commands=[['cmake','--preset',preset,'-DPUFFERUI_WITH_VULKAN=ON','-DPUFFERUI_WITH_HARFBUZZ=ON',
        '-DCMAKE_MSVC_DEBUG_INFORMATION_FORMAT=Embedded',
        '-DFETCHCONTENT_SOURCE_DIR_PUFFERUI_HARFBUZZ='+str(root/'build-vulkan-compute/harfbuzz-src')],
        ['cmake','--build',str(root/'out/build'/preset),'--target','pui_demo','pui_showcase_vulkan','pui_core_bench','pui_vulkan_native_opt3_bench','-j','3'],
        [sys.executable,'tools/run_tests.py','--vulkan','--format',*(['--release'] if config=='release' else [])]]
    with (work/f'full-{config}.log').open('w') as log:
        for command in commands:
            log.write('COMMAND '+repr(command)+'\n');log.flush()
            subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
    print(config,'full suite passed',flush=True)
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in baseline['existing_tests'].items())
print('Existing test sources and golden bytes remain unchanged',flush=True)
