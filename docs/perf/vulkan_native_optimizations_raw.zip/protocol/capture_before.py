from pathlib import Path
import subprocess,shutil,json,hashlib
root=Path(__file__).resolve().parents[1]
work=root/'build-vulkan-native-opt3'
assert shutil.disk_usage(work).free > 3*1024**3
cases=[('spiral-slug',work/'before/pui_vulkan_native_spiral_tests.exe',[]),
       ('overview-slug',work/'before/overview-after.exe',[]),
       ('text',work/'before/pui_vulkan_native_text_tests.exe',[])]
receipts={}
for label,exe,flags in cases:
    target=work/(label+'-before-rgba')
    with (work/(label+'-before-capture.log')).open('w') as log:
        subprocess.run([str(exe),*flags,'--capture',str(target)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
    files=sorted(target.glob('*.rgba'))
    assert len(files)==(96 if label=='text' else 180)
    receipts[label]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    print(label,len(files),'immutable frames',flush=True)
(work/'before-captures.json').write_text(json.dumps(receipts,indent=2)+'\n')
