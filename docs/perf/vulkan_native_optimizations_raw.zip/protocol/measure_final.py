from pathlib import Path
import subprocess, sys
root=Path(__file__).resolve().parents[1]
work=root/'build-vulkan-native-opt3'
command=[sys.executable,'tools/compare_vulkan_native_optimizations.py',
         str(work/'before/optimization-bench-spiral.exe'),
         str(root/'out/build/x64-release/Release/pui_vulkan_native_opt3_bench.exe'),
         '--output',str(work/'qualified-matched'),
         '--spiral-reference',str(work/'spiral-slug-before-rgba'),
         '--baseline-receipt',str(work/'baseline.json'),'--runs','6']
subprocess.run(command,cwd=root,check=True)
subprocess.run([sys.executable,str(work/'collect_cpu.py')],cwd=root,check=True)
print('All paired GPU/CPU timings and 2160 full-frame comparisons complete',flush=True)
