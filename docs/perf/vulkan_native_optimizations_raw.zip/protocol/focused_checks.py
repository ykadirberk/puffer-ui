from pathlib import Path
import subprocess,json,sys
root=Path(__file__).resolve().parents[1]
work=root/'build-vulkan-native-opt3'
binary=root/'out/build/x64-release/Release'
cases=[('pui_vulkan_native_optimization_tests',[]),
       ('pui_vulkan_native_optimization_tests',['--staged']),('pui_harfbuzz_tests',[])]
for staged in [False,True]:
    flags=['--staged'] if staged else []
    cases += [('pui_vulkan_native_text_tests',[*flags,'--reference',str(work/'text-before-rgba')]),
              ('pui_vulkan_native_text_tests',flags)]
    for cache in [False,True]:
        cases.append(('pui_vulkan_native_opt3_bench',[*flags,*(['--cache'] if cache else []),
            '--reference',str(work/'spiral-slug-before-rgba')]))
    cases.append(('pui_vulkan_native_spiral_tests',[*flags,'--bitmap','--reference',str(root/'build-vulkan-native/first-native-rgba')]))
results=[]
for index,(name,args) in enumerate(cases):
    command=[str(binary/(name+'.exe')),*args]
    with (work/f'focused-{index:02}-{name}.log').open('w') as log:
        p=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    results.append(dict(command=command,exit_code=p.returncode))
    print(index,name,args,'exit',p.returncode,flush=True)
(work/'focused.json').write_text(json.dumps(results,indent=2)+'\n')
sys.exit(any(r['exit_code'] for r in results))
