from pathlib import Path
import os,subprocess,sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools'))
from run_tests import import_msvc_env
import_msvc_env()
os.environ['VULKAN_SDK']='E:/VulkanSDK/1.4.335.0'
phase=sys.argv[1]
commands=[]
if phase in ['packed','coverage']:
    commands.append([sys.executable,'tools/compile_vulkan_shaders.py'])
files=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
files += subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
files=[p for p in files if Path(p).suffix in ['.cpp','.h','.inl'] and not p.startswith('vendored/')]
commands += [[str(root/'build-perf-review/format-tool/clang_format/data/bin/clang-format.exe'),'-i',*files],
             ['cmake','--build','out/build/x64-release','--target',*sys.argv[2:],'-j','3']]
with (root/f'build-vulkan-native-opt3/build-{phase}.log').open('w') as log:
    for command in commands:
        log.write(repr(command)+'\n');log.flush()
        subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
print(phase,'compile passed',flush=True)
