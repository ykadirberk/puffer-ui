from pathlib import Path
from collections import Counter
import csv, gzip, hashlib, json, statistics, zipfile

root=Path(__file__).resolve().parents[1]; work=root/'build-vulkan-native-opt3'
def load(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
baseline=load(work/'baseline.json'); measured=load(work/'qualified-matched/receipt.json')
analysis=load(work/'analysis.json'); cpu=load(work/'cpu-qualified/receipt.json')
pdh=load(work/'gpu-qualified-final/receipt.json'); platform=load(work/'platform.json')
old=load(root/'docs/perf/vulkan_native_harfbuzz_final.json')
assert all(digest(root/p)==h for p,h in baseline['existing_tests'].items())
assert all(digest(root/p)==h for p,h in measured['source_hashes'].items())
assert all(digest(root/p)==h for p,h in old['preserved_unrelated'].items())
assert measured['exact_frames']==2160 and analysis['timed_frames']==8640
assert all(not s['draw_buffer_allocations'] for s in analysis['spiral'])
live_path=work/'live.json'
live=load(live_path) if live_path.exists() else dict(status='blocked_pending_desktop_unlock',
    standard_no_argument_launch=True,foreground_inspected=False,
    reason='Windows lock screen was captured; desktop input stopped and the user was asked to unlock. No foreground FPS certification.')
validation={}
for config in ['release','debug']:
    path=work/f'full-{config}.log'
    content=path.read_text(errors='replace')
    assert 'step(s) failed' not in content and 'FAIL   ' not in content
    assert 'all core tests passed' in content and '0 failure(s)' in content
    validation[config]=dict(command='python tools/run_tests.py --vulkan --format'+(' --release' if config=='release' else ''),
                            passed=True,log_sha256=digest(path),
                            native_manifest_cases=len(load(root/'out/build'/('x64-'+config)/f'pufferui-vulkan-tests-{config.title()}.json')))
validation.update(harfbuzz_off_sdl_off_passed=True,original_test_and_golden_files_unchanged=len(baseline['existing_tests']),
                  python_tooling_tests=12,original_goldens_updated=False,
                  new_regression_frames_per_upload_mode=192,all_new_regressions_passed=True)
frames=root/'docs/perf/vulkan_native_optimizations_frames.csv.gz'
with frames.open('wb') as stream:
    with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0) as compressed:
        compressed.write((work/'qualified-matched/frames.csv').read_bytes())
archive=root/'docs/perf/vulkan_native_optimizations_raw.zip'
archived=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as out:
    for folder in ['qualified-matched','cpu-qualified','gpu-qualified-final']:
        for path in sorted((work/folder).iterdir()):
            if path.suffix in ['.csv','.log','.json']:
                relative=path.relative_to(work).as_posix();out.write(path,relative);archived.append(relative)
    for name in ['baseline.json','before-captures.json','full-release-initial.log','full-release.log',
                 'full-debug.log','harfbuzz-off.log','reclaim-regressions.log','build-benchmark-final.log',
                 'platform.json','core-code-sections.json','analysis.json']:
        path=work/name
        if path.exists():out.write(path,name);archived.append(name)
    for name in ['build_phase.py','full_gate.py','check_off.py','build_probes.py','build_benchmark_final.py',
                 'bench_hb_cpu.cpp','measure_final.py','collect_cpu.py','collect_gpu.py','pdh_reference.py',
                 'analyze_results.py','package_report.py','capture_before.py','focused_checks.py']:
        path=work/name
        if path.exists():out.write(path,'protocol/'+name);archived.append('protocol/'+name)
    if live_path.exists():out.write(live_path,'live.json');archived.append('live.json')
final=dict(date='2026-10-29',branch='codex/vulkan-native-harfbuzz',baseline_commit=baseline['commit'],
    preserved_main=old['preserved_main'],platform=platform,foreground_fps_certified=False,
    actual_workload='180 actual showcase frames, 5000 -> 5003 Spiral/64 items, Enter Add at frames 90/120/150',
    measurements=measured,analysis=analysis,cpu=cpu,windows_pdh=pdh,validation=validation,live=live,
    null_core_code_sections=load(work/'core-code-sections.json'),
    preserved_unrelated=old['preserved_unrelated'],
    local_reference_directory=str(work/'spiral-slug-before-rgba'),
    frozen_before_artifacts=baseline['binaries'],
    artifact_hashes={frames.name:digest(frames),archive.name:digest(archive)},
    archived_files=archived,
    limits=['Offscreen timings and hidden native WSI PDH are not foreground FPS certification.',
            'Cold/outlier frames and all six repeats are retained. Runtime drift is visible in the raw data.',
            'Coverage uses an additional bounded 4 MiB GPU image; sampled dedicated memory increases.',
            'Cold 5000 unique native runs and the 64-label hot set are slower; the larger/size-churn workloads improve.',
            'The direct default worst frame increases; no universal worst-frame improvement is claimed.',
            'Process elapsed time includes setup, but driver caches were exercised by qualification; this is not a cold-boot test.',
            'Golden passes replay every deterministic frame, separately from readback-free timing. The pipelined 192-frame regression covers in-flight lifetime.'])
(root/'docs/perf/vulkan_native_optimizations_final.json').write_text(json.dumps(final,indent=2)+'\n')

lines=['# Native Vulkan: exact Slug coverage, shaping reuse and compact uploads','',
'Date: 2026-10-29. Branch: `codex/vulkan-native-harfbuzz`. Before: `'+baseline['commit']+'`. Main remains `'+str(old['preserved_main'])+'`.','',
'All three optimizations are enabled on the native branch. Triangle topology, glyph positions, text size, gamma, clipping, draw order and blending are preserved. The candidate matches every immutable 5000-item Spiral reference frame.','',
'The native renderer now caches repeated Slug coverage in an R32 float image. The identity retains exact bounds, absolute baseline, scale, gamma and outline location; a hit uses `texelFetch` on the original glyph quad. Four bounded regions retire by GPU timeline. A newly reclaimed region admits glyphs before old pressure can retire it again. The image is prepared at a frame boundary, with no eviction wait or allocation in glyph submission. The default budget is 4 MiB; zero retains direct curve evaluation.','',
'Native layout uses an 8192-entry bounded associative cache with full identity checks. A per-font cache retains integer font-unit glyph IDs, clusters, advances and offsets, so changing size repeats the original per-glyph arithmetic without reshaping. Font objects and tables are prepared at `load_font`. The original bitmap cache and its quantized-size history remain independent. Logical payload limits are 4 MiB per font and 32 MiB per context; table metadata and retained pool rounding are additional storage.','',
'Shape vertices upload their original 20 bytes instead of expanding to 32-byte float colors. Integer RGBA8 attributes reconstruct exactly the original binary32 byte/255 values; UNORM conversion is not used. The original 32-byte route remains available with `compact_vertices=false`. Vertex bytes fall 37.5%; indices, native glyph instances and draw order are unchanged. Slots begin at 512 KiB; bounded high-water preparation leaves growth headroom before the next frame.','',
'**Protocol and qualification.** The unchanged actual showcase harness renders 180 frames at 1360 x 860, Spiral mode, size 64, starting with 5000 items. Real Enter activations add items at frames 90, 120 and 150. Six alternating repeats compare before/default/coverage-off/coverage-off-plus-32-byte variants in direct and staged upload modes. All 8640 timing frames, cold frames and outliers are retained. Timing has no per-frame readback. GPU totals are divided by 180 logical frames, not the number of GPU submission intervals.','',
'The old headers and static library were frozen before editing. A matching benchmark wrapper is compiled against those artifacts with `PUFFERUI_OPT3_BASELINE`; it reuses the original showcase test body unchanged. The final new wrapper is built in Release and Debug. Full suites completed before timing, and builds/tests did not overlap the qualified timing cohort.','',
'Golden passes separately replay all 180 deterministic frames for three candidate variants, two upload modes and frame-cache off/on: **2160 exact full-RGBA comparisons**. Every timed frame ID, including every peak, belongs to this set. The 180 before-reference frames and all 77 original test/oracle files retain their hashes. No golden update mode was used.','',
'**5000-item Spiral results.** Frame time below is the median of six run means. The paired change is the median of six before/after percentage changes matched by repeat; it differs from a ratio of two medians when runtime drift is present. GPU time is the median completed total/180.','',
'| Upload | Wall before / after (ms) | Median paired wall change | GPU before / after (ms) | GPU change | Worst before / after (ms) |',
'|---|---:|---:|---:|---:|---:|']
for staged in [False,True]:
    b=next(s for s in analysis['spiral'] if s['staged']==staged and s['label']=='before')
    a=next(s for s in analysis['spiral'] if s['staged']==staged and s['label']=='after')
    lines.append(f"| {'STAGED' if staged else 'DIRECT'} | {b['run_mean_median_ms']:.4f} / {a['run_mean_median_ms']:.4f} | {a['paired_wall_change_percent']['median']:+.2f}% | {b['gpu_median_ms']:.4f} / {a['gpu_median_ms']:.4f} | {(a['gpu_median_ms']/b['gpu_median_ms']-1)*100:+.2f}% | {b['wall']['maximum']:.4f} / {a['wall']['maximum']:.4f} |")
lines+=['','The DIRECT default worst frame increases; the result is not a universal peak-time improvement. Runtime drift affects several late repeats. All individual paired deltas, p95/p99, cold distributions, peak frame IDs and raw CSV rows remain in the JSON/ZIP.','',
'**Attribution controls and startup.** These controls are benchmark-only environment settings, not showcase UI or product CLI switches. The no-coverage variant retains the 20-byte stream and shaping caches. The legacy control additionally restores 32-byte float-color preparation.','',
'| Upload / variant | Wall run-mean median (ms) | GPU (ms/frame) | First-frame median (ms) | Whole-process median (ms) | Maximum (ms) |',
'|---|---:|---:|---:|---:|---:|']
for s in analysis['spiral']:
    lines.append(f"| {'STAGED' if s['staged'] else 'DIRECT'} / {s['label']} | {s['run_mean_median_ms']:.4f} | {s['gpu_median_ms']:.4f} | {s['cold']['median']:.4f} | {s['process_median_ms']:.2f} | {s['wall']['maximum']:.4f} |")
lines+=['','Coverage caching reduces GPU work but has CPU lookup/binding cost. On this CPU-heavy workload the coverage-off control can have a lower wall time. The complete default is retained with an explicit zero-budget diagnostic. Process time includes font/pipeline setup, but qualification has already exercised driver caches; it does not certify cold boot or uncached shader compilation.','',
'| Upload / variant | Mean uploaded bytes/frame | Peak upload-page capacity (MiB) | Draw-buffer allocations in timed frames |',
'|---|---:|---:|---:|']
for s in analysis['spiral']:
    lines.append(f"| {'STAGED' if s['staged'] else 'DIRECT'} / {s['label']} | {s['average_upload_bytes']:.1f} | {s['capacity_bytes']/1048576:.2f} | {s['draw_buffer_allocations']} |")
lines+=['','The default totals 41957 coverage hits, 14816 misses, 526 fills and 39 fill draws per 180-frame run, with no region eviction in this Spiral workload. Total payload falls about 24.5%; reserved page capacity is unchanged because bounded headroom and allocation buckets remain. Page capacity is not VRAM usage. The dedicated R32 allocation is exactly 4194304 bytes on this GPU.','',
'**CPU text workloads.** The probe compiles the actual implementation and uses no Vulkan device. Each value is the median total milliseconds across six alternating runs; call counts and every raw run are archived.','',
'| Mode / workload | Before (ms) | After (ms) | Change | Actual hb_shape calls before / after |',
'|---|---:|---:|---:|---:|']
for s in analysis['cpu']:
    if s['family']!='harfbuzz':continue
    shapes=str(s['shapes']['before'][0])+' / '+str(s['shapes']['after'][0])
    lines.append(f"| {s['mode']} / {s['workload']} | {s['values']['before']['median']:.5f} | {s['values']['after']['median']:.5f} | {s['change_percent']:+.2f}% | {shapes} |")
lines+=['','The 5000-label repeated workload avoids 35704 reshapes; exact-size churn avoids 2368. First-seen 5000 native strings are slower because both cache representations must be populated; the small 64-label warm set also has additional identity/lookup cost. Those regressions are retained rather than hidden by a single aggregate. First-use payloads and outlines remain lazy; warmed cache hits do not shape text again.','',
'**Independent null control.** No null speedup is claimed. Both PE `.text` sections are byte-identical: 187904 bytes, SHA256 `28ce665233672d5d9c0bbddd959d692bc0ea3f94f8296294110f856628f109e0`. The native/HarfBuzz changes are compiled out of this target. Measured timing differences, including the text-area outlier, are retained; allocation counts are unchanged.','',
'| Null workload | Before ms/iteration | After ms/iteration | Change | Allocations/iteration before / after |',
'|---|---:|---:|---:|---:|']
for s in analysis['cpu']:
    if s['family']!='null-core':continue
    lines.append(f"| {s['workload']} | {s['values']['before']['median']:.9g} | {s['values']['after']['median']:.9g} | {s['change_percent']:+.2f}% | {s['allocations']['before'][0]:g} / {s['allocations']['after'][0]:g} |")
lines+=['','**Matched GPU-resource sampling.** Three alternating repeats per upload mode run the same 180-frame workload through hidden native WSI with VSync off and a 60 Hz harness cap: 2160 paced frames. Windows PDH samples only the test PID. All engine/LUID counters and invalid samples are archived; the table shows the active discrete GPU. Means include process startup. This is separate supporting telemetry, not foreground FPS certification.','',
'| Upload / counter | Before median run mean | After median run mean | Before sampled maximum | After sampled maximum |',
'|---|---:|---:|---:|---:|']
for s in analysis['pdh']:
    if '0x00015B27' not in s['counter']:continue
    if 'engtype_3D' not in s['counter'] and not s['counter'].startswith(('dedicated/','shared/')):continue
    b=s['values']['before'];a=s['values']['after'];memory=not s['counter'].startswith('engine/')
    divisor=1048576 if memory else 1;unit='MiB' if memory else '%'
    label=s['counter'].split('/')[0] if memory else '3D'
    lines.append(f"| {'STAGED' if s['staged'] else 'DIRECT'} / {label} ({unit}) | {b['median_mean']/divisor:.4f} | {a['median_mean']/divisor:.4f} | {b['maximum']/divisor:.4f} | {a['maximum']/divisor:.4f} |")
lines+=['','Sampled dedicated memory increases by about 3.08 MiB in median run means, and its sampled maximum increases by 2 MiB. This is the coverage-cache tradeoff; shared usage is unchanged. Actual VRAM peaks between samples are not established.','',
'**Regressions and existing suites.** `pui_vulkan_native_optimization_tests` checks all 256 channel values against the independent float-color path, interpolated alpha/texture/clip output, exact upload-byte counts, 192 cache/uncached frames per upload mode, ligatures/Arabic/combining text, overlaps, DPI, gamma, blur ordering, oversized glyph fallback, pipelined GPU readback, timeline retirement, reclaim-under-pressure and integer-aligned hash distribution. CPU cases verify 5000-label reuse, size churn, exact scalar layouts and font identity.','',
'Both `python tools/run_tests.py --vulkan --format --release` and `python tools/run_tests.py --vulkan --format` pass, including 29 registered native cases per configuration, all core/pump/performance/showcase suites, existing SDL goldens, every example, installed consumers, API/tutorial drift and formatting. The separate HarfBuzz-OFF/SDL-OFF build passes direct/staged interaction checks. The tooling suite has 12 passing tests. New untracked C++/INL sources also pass explicit clang-format dry-run checks.','',
'The initial new aligned-position regression exposed a real retirement starvation bug. Its failed log is preserved; after the fix both complete suites pass. All 77 original files and the nine unrelated draft hashes remain unchanged. The SDL submodule is preserved.','',
'**Live status.** '+('Foreground native showcase and SDL demo checks passed; see the live receipt for exact actions.' if live.get('status')=='passed' else 'The standard no-argument native executable was launched, but Windows was locked during capture. Desktop input stopped and an unlock was requested. No live appearance or foreground performance claim is made.'),'',
'**Evidence and reproduction.**','',
'- [Complete machine-readable receipt](perf/vulkan_native_optimizations_final.json)','- [Every timed frame](perf/vulkan_native_optimizations_frames.csv.gz)',
'- [Raw runs, golden logs, full-suite logs and protocol sources](perf/vulkan_native_optimizations_raw.zip)','',
'The raw archive includes the exact compiler commands/probe sources. The before wrapper uses frozen `e18ed126` headers and `pufferui_vulkan.lib`; it does not use the new implementation. The immutable before capture directory remains local and every RGBA hash is committed in the receipt. On this checkout, rerun to a fresh output directory:',
'','```powershell',
'cmake --build out/build/x64-release --target pui_vulkan_native_opt3_bench',
'python tools/compare_vulkan_native_optimizations.py `',
'  build-vulkan-native-opt3/before/optimization-bench-spiral.exe `',
'  out/build/x64-release/Release/pui_vulkan_native_opt3_bench.exe `',
'  --output build-vulkan-native-opt3/repeat-new-directory `',
'  --spiral-reference build-vulkan-native-opt3/spiral-slug-before-rgba `',
'  --baseline-receipt build-vulkan-native-opt3/baseline.json --runs 6',
'```','',
'The standard native showcase remains directly runnable without Python:',
'','```powershell','& "D:\\myimgui\\out\\build\\x64-release\\Release\\pui_showcase_vulkan.exe"','```','']
(root/'docs/perf_vulkan_native_optimizations.md').write_text('\n'.join(lines))
print('Report, complete receipt, compressed frame stream and raw evidence packaged',flush=True)
