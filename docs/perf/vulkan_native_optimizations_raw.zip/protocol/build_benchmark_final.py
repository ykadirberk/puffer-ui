from pathlib import Path
import sys, subprocess, os
root=Path(__file__).resolve().parents[1]
work=root/'build-vulkan-native-opt3'
sys.path.insert(0,str(root/'tools'))
from run_tests import import_msvc_env
import_msvc_env()
with (work/'build-benchmark-final.log').open('w') as log:
    for config in ['release','debug']:
        subprocess.run(['cmake','--build',str(root/'out/build'/('x64-'+config)),
                        '--target','pui_vulkan_native_opt3_bench','-j','3'],
                        cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run([sys.executable,str(work/'build_probes.py'),'--spiral-wrapper'],cwd=root,check=True)
subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_*tools.py'],cwd=root,check=True)
print('Matched benchmark wrappers ready; production libraries unchanged',flush=True)
