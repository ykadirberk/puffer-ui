from pathlib import Path
import os, sys, subprocess
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from run_tests import import_msvc_env
import_msvc_env()
os.environ['VULKAN_SDK']='E:/VulkanSDK/1.4.335.0'
os.environ['PATH']=str(ROOT/'build-perf-review/format-tool/clang_format/data/bin')+os.pathsep+os.environ['PATH']
config=sys.argv[1] if len(sys.argv)>1 else 'Release'
preset='x64-release' if config=='Release' else 'x64-debug'
work=ROOT/'build-vulkan-native'
commands=[['cmake','--preset',preset,'-DPUFFERUI_WITH_VULKAN=ON','-DPUFFERUI_WITH_HARFBUZZ=ON',
           '-DCMAKE_MSVC_DEBUG_INFORMATION_FORMAT=Embedded',
           '-DFETCHCONTENT_SOURCE_DIR_PUFFERUI_HARFBUZZ='+str(ROOT/'build-vulkan-compute/harfbuzz-src')],
          ['cmake','--build',str(ROOT/'out/build'/preset),'--target','pui_showcase_vulkan','pui_tut_vulkan_manual','pui_demo','pui_core_bench','-j','3']]
with (work/('full-'+config.lower()+'.log')).open('w') as log:
    for command in commands:
        log.write('COMMAND '+repr(command)+'\n');log.flush()
        subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
    if config=='Release':
        subprocess.run(['pwsh','-NoProfile','-File','tools/tutorial_shots.ps1','-Only','vulkan-manual'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
    command=[sys.executable,str(ROOT/'tools/run_tests.py'),'--vulkan','--format']+(['--release'] if config=='Release' else [])
    result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
print(config,'full gate exit',result.returncode,flush=True)
sys.exit(result.returncode)
