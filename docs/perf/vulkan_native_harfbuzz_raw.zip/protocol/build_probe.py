from pathlib import Path
import os, sys, subprocess, zipfile
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from run_tests import import_msvc_env
import_msvc_env()
os.environ['VULKAN_SDK']='E:/VulkanSDK/1.4.335.0'
base=ROOT/'build-vulkan-native/base-build'
source=ROOT/'build-vulkan-native/base-source'
if not source.exists():
    with zipfile.ZipFile(ROOT/'build-vulkan-native/base-source.zip') as archive:
        archive.extractall(source)
out=ROOT/'build-vulkan-native/base-probe.exe'
libs=['kernel32','user32','gdi32','winmm','imm32','version','uuid','advapi32','setupapi',
      'shell32','hid','dinput8','uiautomationcore','comctl32','ole32','oleaut32','winspool','comdlg32']
cmd=['cl','/nologo','/std:c++20','/EHsc','/O2','/Ob2','/GL','/MD','/DNDEBUG','/DPUFFERUI_ENABLE_VULKAN',
     '/DPUFFERUI_ENABLE_SDL3','/DPUFFERUI_ASSET_DIR="'+(ROOT/'assets').as_posix()+'"',
     '/I'+str(source/'include'),'/I'+str(ROOT/'vendored/SDL/include'),
     '/I'+str(Path(os.environ['VULKAN_SDK'])/'Include'),
     str(ROOT/'tests/test_vulkan_native_spiral.cpp'),
     '/Fo'+str(ROOT/'build-vulkan-native/base-probe.obj'),'/Fe'+str(out),'/link','/LTCG',
     '/MANIFEST:EMBED','/MANIFESTINPUT:'+str(Path(os.environ['VSINSTALLDIR'])/'VC/Tools/MSVC'/os.environ['VCToolsVersion']/'include/manifest/segmentheap.manifest'),
     str(ROOT/'build-vulkan-native/base-libs/pufferui_vulkan.lib'),str(base/'vendored/SDL/SDL3-static.lib'),
     str(Path(os.environ['VULKAN_SDK'])/'Lib/vulkan-1.lib')]+[x+'.lib' for x in libs]
subprocess.run(cmd,cwd=ROOT,check=True)
print('Baseline capture probe ready',flush=True)
