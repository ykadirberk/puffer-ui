from pathlib import Path
import os, sys, subprocess, zipfile, shutil
ROOT=Path(__file__).resolve().parents[1]
work=ROOT/'build-vulkan-native'
sys.path.insert(0,str(ROOT/'tools'))
from run_tests import import_msvc_env
import_msvc_env()
source=work/'old-main-headers'
if not source.exists():
    with zipfile.ZipFile(work/'old-main-headers.zip') as archive: archive.extractall(source)
old=ROOT/'out/build/x64-release'
snapshot=work/'old-main-libs'
snapshot.mkdir(exist_ok=True)
libs=['pufferui_vulkan.lib','vendored/SDL/SDL3-static.lib',
      '_deps/pufferui_harfbuzz-build/harfbuzz.lib','_deps/pufferui_harfbuzz-build/harfbuzz-gpu.lib']
for lib in libs:
    target=snapshot/Path(lib).name
    if not target.exists(): shutil.copy2(old/lib,target)
systemlibs=['kernel32','user32','gdi32','winmm','imm32','version','uuid','advapi32',
            'setupapi','shell32','hid','dinput8','uiautomationcore','comctl32','ole32','oleaut32','winspool','comdlg32']
cmd=['cl','/nologo','/std:c++20','/EHsc','/O2','/MD','/DNDEBUG',
     '/DPUFFERUI_ENABLE_VULKAN','/DPUFFERUI_ENABLE_SDL3','/DPUFFERUI_ENABLE_HARFBUZZ','/DPUFFERUI_OLD_SLUG_ORACLE',
     '/DPUFFERUI_ASSET_DIR="'+(ROOT/'assets').as_posix()+'"',
     '/I'+str(source/'include'),'/I'+str(ROOT/'vendored/SDL/include'),'/IE:/VulkanSDK/1.4.335.0/Include',
     str(ROOT/'tests/test_vulkan_native_text.cpp'),'/Fo'+str(work/'old-slug.obj'),
     '/Fe'+str(work/'old-slug.exe'),'/link','/LTCG',
     *[str(snapshot/Path(lib).name) for lib in libs],
     'E:/VulkanSDK/1.4.335.0/Lib/vulkan-1.lib',*[lib+'.lib' for lib in systemlibs]]
subprocess.run(cmd,cwd=ROOT,check=True)
print('Old native SDF/Slug oracle built against frozen b30a7be headers and libraries',flush=True)
