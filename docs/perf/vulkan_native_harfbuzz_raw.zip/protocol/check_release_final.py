from pathlib import Path
import subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
bin=ROOT/'out/build/x64-release/Release'
cases=[('pui_harfbuzz_interaction_tests',[]),('pui_harfbuzz_interaction_tests',['--staged']),
       ('pui_harfbuzz_tests',[]),('pui_vulkan_native_text_tests',[]),('pui_vulkan_native_text_tests',['--staged'])]
with (ROOT/'build-vulkan-native/final-release-extra.log').open('w') as log:
    for name,args in cases:
        log.write(name+' '+' '.join(args)+'\n');log.flush()
        p=subprocess.run([str(bin/(name+'.exe')),*args],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        if p.returncode:print('FAILED',name,args,flush=True);sys.exit(p.returncode)
print('Release final default, scalar and 360 interactive frames passed',flush=True)
