from pathlib import Path
import os, sys, json, subprocess
ROOT=Path(__file__).resolve().parents[1]
work=ROOT/'build-vulkan-native'
env=dict(os.environ)
manifest=json.loads((work/'driver.json').read_text())['VK_DRIVER_FILES']
if manifest: env['VK_DRIVER_FILES']=manifest
exe=work/'base-build/Release'/sys.argv[1]
subprocess.run([str(exe),*sys.argv[2:]],env=env,cwd=ROOT,check=True)
