from pathlib import Path
import os,sys,subprocess
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from run_tests import import_msvc_env
import_msvc_env()
os.environ['VULKAN_SDK']='E:/VulkanSDK/1.4.335.0'
build=ROOT/'build-vulkan-native/off-build'
commands=[['cmake','-S',str(ROOT),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
    '-DCMAKE_MSVC_DEBUG_INFORMATION_FORMAT=Embedded','-DPUFFERUI_WITH_VULKAN=ON',
    '-DPUFFERUI_WITH_HARFBUZZ=OFF','-DPUFFERUI_WITH_SDL3=OFF','-DPUFFERUI_BUILD_EXAMPLES=OFF'],
    ['cmake','--build',str(build),'--target','pui_vulkan_tests','pui_vulkan_interaction_tests','-j','2'],
    [str(build/'Release/pui_vulkan_tests.exe')],
    [str(build/'Release/pui_vulkan_interaction_tests.exe')]]
with (ROOT/'build-vulkan-native/harfbuzz-off.log').open('w') as log:
    for command in commands: subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Native HarfBuzz OFF + SDL OFF passed',flush=True)
