from pathlib import Path
import subprocess, csv, io
ROOT=Path(__file__).resolve().parents[1]
work=ROOT/'build-vulkan-native'
for label,args in [('native-vector',[]),('native-bitmap',['--bitmap'])]:
    r=subprocess.run([str(work/'native-text-before.exe'),'--bench',*args],cwd=ROOT,capture_output=True,text=True,check=True)
    (work/(label+'-before-initial.csv')).write_text(r.stdout)
    rows=list(csv.DictReader(io.StringIO(r.stdout)))
    print(label,'wall mean',sum(float(r['total_ms']) for r in rows)/len(rows),
          'upload peak',max(int(r['resident_bytes']) for r in rows),
          'bytes/frame',sum(int(r['upload_bytes']) for r in rows)//len(rows),flush=True)
with (work/'native-text-before-capture.log').open('w') as log:
    subprocess.run([str(work/'native-text-before.exe'),'--capture',str(work/'native-text-before-rgba')],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Native mesh/Slug: all 180 pre-optimization RGBA frames frozen',flush=True)
