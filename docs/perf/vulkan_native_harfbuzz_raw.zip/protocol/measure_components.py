from pathlib import Path
import sys,subprocess,csv,json,re,time,hashlib,os
ROOT=Path(__file__).resolve().parents[1];work=ROOT/'build-vulkan-native'
out=work/('component-qualified'+os.environ.get('PUI_RUN_SUFFIX',''));out.mkdir(exist_ok=False)
before=work/'overview-before.exe';after=work/'overview-after.exe'
capture=work/'first-native-overview-rgba'
with (out/'overview-first-capture.log').open('w') as log:
 subprocess.run([str(before),'--bitmap','--reference' if capture.exists() else '--capture',str(capture)],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
for staged in [False,True]:
 with (out/f'overview-bitmap-exact-{int(staged)}.log').open('w') as log:
  subprocess.run([str(after),'--bitmap','--reference',str(capture),*(['--staged'] if staged else [])],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
runs=[]
for repeat in range(6):
 for staged in [False,True]:
  cases=[('baseline-bitmap',before,['--bitmap']),('candidate-bitmap',after,['--bitmap']),('candidate-slug',after,[])]
  for label,exe,flags in (cases if repeat%2==0 else list(reversed(cases))):
   stem=out/f'overview-{label}-{int(staged)}-{repeat}'
   command=[str(exe),*flags,*(['--staged'] if staged else [])]
   start=time.perf_counter()
   with stem.with_suffix('.csv').open('w') as stdout,stem.with_suffix('.log').open('w') as stderr:
    subprocess.run(command,cwd=ROOT,stdout=stdout,stderr=stderr,check=True)
   rows=list(csv.DictReader(stem.with_suffix('.csv').read_text().splitlines()))
   if len(rows)!=180:raise ValueError('incomplete overview')
   gpu=re.search(r'gpu_total_ms=([\d.]+) gpu_samples=(\d+)',stem.with_suffix('.log').read_text())
   runs.append(dict(label=label,staged=staged,repeat=repeat,command=command,process_ms=(time.perf_counter()-start)*1000,
     mean_ms=sum(float(r['total_ms']) for r in rows)/180,max_ms=max(float(r['total_ms']) for r in rows),
     cold_ms=float(rows[0]['total_ms']),gpu_ms=float(gpu[1])/180,gpu_samples=int(gpu[2]),
     peak_upload_bytes=max(int(r['resident_bytes']) for r in rows),
     max_glyphs=max(int(r['glyph_instances']) for r in rows)))
for repeat in range(6):
 for label,exe in ([('core-before',work/'base-core.exe'),('core-after',ROOT/'out/build/x64-release/Release/pui_core_bench.exe')] if repeat%2==0 else [('core-after',ROOT/'out/build/x64-release/Release/pui_core_bench.exe'),('core-before',work/'base-core.exe')]):
  p=subprocess.run([str(exe)],cwd=ROOT,capture_output=True,text=True,check=True)
  (out/f'{label}-{repeat}.csv').write_text(p.stdout)
 for repeat_probe in [0]:
  p=subprocess.run([str(work/'hb-cpu.exe')],cwd=ROOT,capture_output=True,text=True,check=True)
  (out/f'hb-cpu-{repeat}.csv').write_text(p.stdout)
receipt=dict(overview=runs,exact_bitmap_overview_frames=360,
 binaries={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [before,after,work/'base-core.exe',ROOT/'out/build/x64-release/Release/pui_core_bench.exe',work/'hb-cpu.exe']})
(out/'receipt.json').write_text(json.dumps(receipt,indent=2))
print('Overview: 6480 timed frames + 360 exact frames; six core/HarfBuzz CPU repeats complete',flush=True)
