from pathlib import Path
import sys,os,subprocess
ROOT=Path(__file__).resolve().parents[1];work=ROOT/'build-vulkan-native'
sys.path.insert(0,str(ROOT/'tools'))
from run_tests import import_msvc_env
import_msvc_env()
prefix=(ROOT/'tests/test_vulkan_native_spiral.cpp').read_text().split('int main(')[0]
main=r'''
int main(int argc,char**argv) {
 bool bitmap=false,staged=false,windowed=false;int hz=0;
 const char *capture=nullptr,*reference=nullptr;
 for(int i=1;i<argc;++i) {
  if(!std::strcmp(argv[i],"--bitmap")) bitmap=true;
  else if(!std::strcmp(argv[i],"--staged")) staged=true;
  else if(!std::strcmp(argv[i],"--windowed")) windowed=true;
  else if(!std::strcmp(argv[i],"--hz")&&i+1<argc) hz=std::atoi(argv[++i]);
  else if(!std::strcmp(argv[i],"--capture")&&i+1<argc) capture=argv[++i];
  else if(!std::strcmp(argv[i],"--reference")&&i+1<argc) reference=argv[++i];
  else return 2;
 }
 if(capture&&!std::filesystem::create_directory(capture)) return 2;
 vulkan_device_opts opts;
 opts.validation=capture||reference;
 opts.error_callback=diagnostic;
 opts.upload_mode=staged?vulkan_upload_mode::STAGED:vulkan_upload_mode::DIRECT;
#if defined(PUFFERUI_ENABLE_HARFBUZZ)
 opts.vector_text=!bitmap;
#endif
 example_app app;render_device*device=nullptr;
 g_start_page=PAGE_OVERVIEW;g_no_hud=true;
 if(windowed) {
  app.boot.vulkan=opts;
  char program[]="Overview probe",selftest[]="--selftest",no_script[]="--no-script";
  char*arguments[]={program,selftest,no_script};
  if(!example_init(app,"Overview probe",1360,860,3,arguments))return 1;
  device=app.device;device->set_vsync(false);seed_scene(app,0);
 } else {
  device=create_vulkan_device(opts);
  if(!device||!initialize(app,device,0)) return 1;
 }
 if(!vulkan_wait_idle(device))return 1;
 const auto initial=vulkan_statistics(device);
 std::vector<u8>pixels(1360*860*4),expected(pixels.size());
 std::puts("frame,total_ms,upload_bytes,resident_bytes,gpu_samples,gpu_ms,glyph_instances");
 const auto epoch=std::chrono::steady_clock::now();
 for(int f=0;f<180;++f) {
  const auto before=vulkan_statistics(device);
  const auto start=std::chrono::steady_clock::now();
  app.frame_index=f;app.now=f/60.0;app.dt=1.0/60.0;
  begin_frame(app.ctx,*app.win,app.now,app.dt);
  {ui u(app.ctx);showcase_frame(u,app);}
  end_frame(app.ctx);
  const double elapsed=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
  const auto after=vulkan_statistics(device);
  unsigned long long glyphs=0;
#if defined(PUFFERUI_ENABLE_HARFBUZZ)
  glyphs=after.glyph_instances-before.glyph_instances;
#endif
  std::printf("%d,%.9f,%llu,%llu,%llu,%.9f,%llu\n",f,elapsed,
   static_cast<unsigned long long>(after.upload_bytes-before.upload_bytes),
   static_cast<unsigned long long>(after.upload_allocated_bytes),
   static_cast<unsigned long long>(after.gpu_samples-before.gpu_samples),
   after.completed_gpu_ms-before.completed_gpu_ms,glyphs);
  if(vulkan_last_result(device)!=VK_SUCCESS||violation_count(app.ctx)||failures)return 1;
  if(capture||reference) {
   if(!device->read_pixels(app.surface->scene_target(),0,0,1360,860,pixels.data()))return 1;
   char name[32];std::snprintf(name,sizeof(name),"frame-%03d.rgba",f);
   if(capture) {std::ofstream out(std::filesystem::path(capture)/name,std::ios::binary);out.write(reinterpret_cast<const char*>(pixels.data()),pixels.size());if(!out)return 1;}
   if(reference) {std::ifstream in(std::filesystem::path(reference)/name,std::ios::binary);in.read(reinterpret_cast<char*>(expected.data()),expected.size());if(!in||pixels!=expected){std::fprintf(stderr,"Overview mismatch %d\n",f);return 1;}}
  }
  if(hz)std::this_thread::sleep_until(epoch+std::chrono::duration_cast<std::chrono::steady_clock::duration>(std::chrono::duration<double>(double(f+1)/hz)));
 }
 if(!vulkan_wait_idle(device))return 1;
 const auto after=vulkan_statistics(device);
 std::fprintf(stderr,"gpu_total_ms=%.9f gpu_samples=%llu frames=180\n",after.completed_gpu_ms-initial.completed_gpu_ms,
  static_cast<unsigned long long>(after.gpu_samples-initial.gpu_samples));
 if(after.validation_errors||failures)return 1;
 if(windowed){app.selftest=false;example_shutdown(app);}
 else{destroy_context(app.ctx);device->destroy_surface(app.surface);destroy_vulkan_device(device);}
 return 0;
}
'''
cpp=work/'overview_probe.cpp'
if cpp.exists() and '--after-only' not in sys.argv:raise SystemExit('Preserve existing overview source')
if not cpp.exists():cpp.write_text(prefix+main)
libs=ROOT/'out/build/x64-release'
manifest=Path(os.environ['VSINSTALLDIR'])/'VC/Tools/MSVC'/os.environ['VCToolsVersion']/'include/manifest/segmentheap.manifest'
systemlibs=['kernel32','user32','gdi32','winmm','imm32','version','uuid','advapi32','setupapi','shell32','hid','dinput8','uiautomationcore','comctl32','ole32','oleaut32','winspool','comdlg32']
with (work/'overview-build.log').open('w') as log:
 for side in (['after'] if '--after-only' in sys.argv else ['before','after']):
  include=work/'base-source/include' if side=='before' else ROOT/'include'
  lib=work/'base-libs/pufferui_vulkan.lib' if side=='before' else libs/'pufferui_vulkan.lib'
  command=['cl','/nologo','/std:c++20','/EHsc','/O2','/Ob2','/GL','/MD','/DNDEBUG',
   '/DPUFFERUI_ENABLE_VULKAN','/DPUFFERUI_ENABLE_SDL3','/DPUFFERUI_ASSET_DIR="'+(ROOT/'assets').as_posix()+'"',
   '/I'+str(include),'/I'+str(ROOT/'vendored/SDL/include'),'/IE:/VulkanSDK/1.4.335.0/Include']
  if side=='after':command+=['/DPUFFERUI_ENABLE_HARFBUZZ']
  command+=[str(cpp),'/Fo'+str(work/f'overview-{side}.obj'),'/Fe'+str(work/f'overview-{side}.exe'),
   '/link','/LTCG','/MANIFEST:EMBED','/MANIFESTINPUT:'+str(manifest),str(lib),str(libs/'vendored/SDL/SDL3-static.lib')]
  if side=='after':command += [str(libs/'_deps/pufferui_harfbuzz-build/harfbuzz.lib'),str(libs/'_deps/pufferui_harfbuzz-build/harfbuzz-gpu.lib')]
  command+=['E:/VulkanSDK/1.4.335.0/Lib/vulkan-1.lib',*[lib+'.lib' for lib in systemlibs]]
  log.write(repr(command)+'\n');log.flush()
  subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Matched actual Overview probes built against first/final native libraries',flush=True)
