from pathlib import Path
import sys,os,subprocess
ROOT=Path(__file__).resolve().parents[1]
work=ROOT/'build-vulkan-native'
sys.path.insert(0,str(ROOT/'tools'))
from run_tests import import_msvc_env
import_msvc_env()
manifest=Path(os.environ['VSINSTALLDIR'])/'VC/Tools/MSVC'/os.environ['VCToolsVersion']/'include/manifest/segmentheap.manifest'
libs=ROOT/'out/build/x64-release'
systemlibs=['kernel32','user32','gdi32','winmm','imm32','version','uuid','advapi32','setupapi','shell32','hid','dinput8','uiautomationcore','comctl32','ole32','oleaut32','winspool','comdlg32']
command=['cl','/nologo','/std:c++20','/EHsc','/O2','/Ob2','/GL','/MD','/DNDEBUG',
    '/DPUFFERUI_ENABLE_VULKAN','/DPUFFERUI_ENABLE_SDL3','/DPUFFERUI_ENABLE_HARFBUZZ',
    '/DPUFFERUI_ASSET_DIR="'+(ROOT/'assets').as_posix()+'"',
    '/I'+str(ROOT/'include'),'/I'+str(ROOT/'vendored/stb'),'/I'+str(ROOT/'vendored/SDL/include'),
    '/I'+str(ROOT/'build-vulkan-compute/harfbuzz-src/src'),'/IE:/VulkanSDK/1.4.335.0/Include',
    str(work/'bench_hb_cpu.cpp'),'/Fo'+str(work/'hb-cpu.obj'),'/Fe'+str(work/'hb-cpu.exe'),
    '/link','/LTCG','/MANIFEST:EMBED','/MANIFESTINPUT:'+str(manifest),
    str(libs/'vendored/SDL/SDL3-static.lib'),str(libs/'_deps/pufferui_harfbuzz-build/harfbuzz.lib'),
    str(libs/'_deps/pufferui_harfbuzz-build/harfbuzz-gpu.lib'),'E:/VulkanSDK/1.4.335.0/Lib/vulkan-1.lib',
    *[lib+'.lib' for lib in systemlibs]]
with (work/'hb-cpu-build.log').open('w') as log:
    subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
print('CPU-only HarfBuzz probe built; no Vulkan device or window is created',flush=True)
