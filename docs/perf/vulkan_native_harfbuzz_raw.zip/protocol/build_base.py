from pathlib import Path
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "build-vulkan-native"
WORK.mkdir(exist_ok=True)
sys.path.insert(0, str(ROOT / "tools"))
from run_tests import import_msvc_env
import_msvc_env()
os.environ["VULKAN_SDK"] = "E:/VulkanSDK/1.4.335.0"
build = WORK / "base-build"
segment_heap = Path(os.environ["VSINSTALLDIR"]) / "Common7/IDE/CommonExtensions/Microsoft/CMake/cmake/Microsoft/SegmentHeap.cmake"
commands = []
if not (WORK / "base-source.zip").exists():
    commands.append(["git", "archive", "--format=zip", "8c62fc4", "-o", str(WORK / "base-source.zip")])
commands += [
    ["cmake", "-S", str(ROOT), "-B", str(build), "-G", "Ninja", "-DCMAKE_BUILD_TYPE=Release",
     "-DPUFFERUI_WITH_VULKAN=ON", "-DCMAKE_C_COMPILER=cl.exe", "-DCMAKE_CXX_COMPILER=cl.exe",
     "-DCMAKE_MSVC_DEBUG_INFORMATION_FORMAT=Embedded",
     "-DCMAKE_PROJECT_TOP_LEVEL_INCLUDES=" + str(segment_heap)],
    ["cmake", "--build", str(build), "--target", "pui_showcase_vulkan", "pui_vulkan_spiral_tests", "-j", "3"],
]
with (WORK / "base-build.log").open("w", encoding="utf8") as log:
    for command in commands:
        print("Base stage:", command[:4], flush=True)
        child = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        if child.returncode:
            print("Base build failed; inspect base-build.log", flush=True)
            raise SystemExit(child.returncode)
print("First Vulkan baseline built", flush=True)
