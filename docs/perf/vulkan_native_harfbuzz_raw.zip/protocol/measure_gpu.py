from pathlib import Path
import subprocess,os,sys,time,json,statistics,hashlib,importlib.util,csv
ROOT=Path(__file__).resolve().parents[1]
work=ROOT/'build-vulkan-native'
source=work/'pdh_reference.py'
if not source.exists(): source.write_bytes(subprocess.check_output(['git','show','b30a7be:tools/measure_vulkan_gpu.py'],cwd=ROOT))
spec=importlib.util.spec_from_file_location('native_pdh',source)
pdh=importlib.util.module_from_spec(spec);spec.loader.exec_module(pdh)
out=work/'gpu-qualified';out.mkdir(exist_ok=False)
base=work/'base-probe.exe';after=ROOT/'out/build/x64-release/Release/pui_vulkan_native_spiral_tests.exe'
cases=[('spiral-first-native-bitmap',base,['--bench','--bitmap']),('spiral-native-bitmap',after,['--bench','--bitmap']),('spiral-native-Slug',after,['--bench']),
       ('overview-first-native-bitmap',work/'overview-before.exe',['--bitmap']),
       ('overview-native-bitmap',work/'overview-after.exe',['--bitmap']),
       ('overview-native-Slug',work/'overview-after.exe',[])]
runs=[]
for repeat in range(3):
    for staged in [False,True]:
        for label,exe,flags in (cases if repeat%2==0 else list(reversed(cases))):
            stem=out/f'{label}-{"staged" if staged else "direct"}-{repeat}'
            command=[str(exe),'--windowed','--hz','60',*flags,*(['--staged'] if staged else [])]
            query=pdh.Query();samples=[];start=time.perf_counter()
            with stem.with_suffix('.csv').open('w') as stdout,stem.with_suffix('.log').open('w') as stderr:
                p=subprocess.Popen(command,cwd=ROOT,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
                try:
                    query.sample(p.pid)
                    while p.poll() is None:
                        if time.perf_counter()-start>45: p.kill();raise TimeoutError(command)
                        time.sleep(.25)
                        for sample in query.sample(p.pid):samples.append(dict(elapsed=time.perf_counter()-start,pid=p.pid,**sample))
                finally:query.close(query.handle)
                if p.wait():raise RuntimeError(stem)
            rows=[r for r in csv.DictReader(stem.with_suffix('.csv').read_text().splitlines()) if r.get('frame','').isdecimal()]
            if [int(r['frame']) for r in rows]!=list(range(180)):raise RuntimeError('incomplete frames')
            stem.with_suffix('.pdh.json').write_text(json.dumps(samples,indent=2))
            summary=pdh.summarize(samples)
            runs.append(dict(label=label,staged=staged,repeat=repeat,command=command,frames=180,elapsed=time.perf_counter()-start,summary=summary))
            (out/'receipt.json').write_text(json.dumps(dict(protocol='Per-PID PDH; hidden native WSI; VSync off; fixed 60 Hz harness cap; all physical engines and invalid samples retained; no foreground FPS certification',
                binaries={str(e):hashlib.sha256(e.read_bytes()).hexdigest() for e in [base,after]},runs=runs),indent=2))
            print(label,staged,repeat,summary,flush=True)
