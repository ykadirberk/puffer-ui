from pathlib import Path
import os,sys,subprocess
ROOT=Path(__file__).resolve().parents[1]
work=ROOT/'build-vulkan-native'
sys.path.insert(0,str(ROOT/'tools'))
from run_tests import import_msvc_env
import_msvc_env()
manifest=Path(os.environ['VSINSTALLDIR'])/'VC/Tools/MSVC'/os.environ['VCToolsVersion']/'include/manifest/segmentheap.manifest'
subprocess.run(['cl','/nologo','/std:c++20','/EHsc','/O2','/Ob2','/GL','/MD','/DNDEBUG',
    '/DPUFFERUI_CORE_PERF_BENCH','/DPUFFERUI_ASSET_DIR="'+(ROOT/'assets').as_posix()+'"',
    '/I'+str(work/'base-source/include'),'/I'+str(ROOT/'vendored/stb'),
    str(work/'base-source/src/pufferui_impl.cpp'),'/Fo'+str(work/'base-core.obj'),
    '/Fe'+str(work/'base-core.exe'),'/link','/LTCG','/MANIFEST:EMBED','/MANIFESTINPUT:'+str(manifest)],
    cwd=ROOT,check=True)
