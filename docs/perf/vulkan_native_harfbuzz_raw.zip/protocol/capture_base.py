from pathlib import Path
import os, sys, subprocess, json, shutil
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from run_vulkan_showcase import select_driver
work=ROOT/'build-vulkan-native'
env, info=select_driver(work/'base-build/Release/pui_showcase_vulkan.exe',os.environ,'AMD Radeon RX 9070 XT')
(work/'driver.json').write_text(json.dumps({'info':info,'VK_DRIVER_FILES':env.get('VK_DRIVER_FILES')},indent=2))
print(info,flush=True)
for name in ['pui_showcase_vulkan.exe','pui_vulkan_spiral_tests.exe']:
    shutil.copy2(work/'base-build/Release'/name,work/('base-'+name))
with (work/'base-capture.log').open('w') as log:
    subprocess.run([str(work/'base-probe.exe'),'--bitmap','--reference',str(work/'first-native-rgba')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
print('First native: 180 immutable RGBA frames captured',flush=True)
