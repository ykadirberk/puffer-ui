from pathlib import Path
import sys,os,subprocess
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from run_tests import import_msvc_env
import_msvc_env()
os.environ['VULKAN_SDK']='E:/VulkanSDK/1.4.335.0'
commands=[['cmake','--preset','x64-debug','-DPUFFERUI_WITH_VULKAN=ON','-DPUFFERUI_WITH_HARFBUZZ=ON',
    '-DCMAKE_MSVC_DEBUG_INFORMATION_FORMAT=Embedded',
    '-DFETCHCONTENT_SOURCE_DIR_PUFFERUI_HARFBUZZ='+str(ROOT/'build-vulkan-compute/harfbuzz-src')],
    ['cmake','--build',str(ROOT/'out/build/x64-debug'),'-j','3']]
with (ROOT/'build-vulkan-native/debug-build.log').open('w') as log:
    for command in commands:
        subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Debug complete build passed',flush=True)
