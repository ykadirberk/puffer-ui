from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
fmt=ROOT/'build-perf-review/format-tool/clang_format/data/bin/clang-format.exe'
tracked=subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines()
files=[p for p in tracked+untracked if Path(p).suffix in ['.h','.cpp','.inl'] and not p.startswith('vendored/')]
subprocess.run([str(fmt),'-i',*files],cwd=ROOT,check=True)
print('Formatted',len(files),'scoped source files',flush=True)
