from pathlib import Path
import os, sys, subprocess, shutil
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from run_tests import import_msvc_env
import_msvc_env()
os.environ['VULKAN_SDK']='E:/VulkanSDK/1.4.335.0'
build=ROOT/'build-vulkan-native/base-build'
frozen=ROOT/'build-vulkan-native/base-libs'
if not frozen.exists():
    frozen.mkdir()
    for lib in ['pufferui_vulkan.lib']:
        shutil.copy2(build/lib,frozen/lib)
with (ROOT/'build-vulkan-native/stage-build.log').open('w') as log:
    subprocess.run(['cmake','-S',str(ROOT),'-B',str(build),
        '-DFETCHCONTENT_SOURCE_DIR_PUFFERUI_HARFBUZZ='+str(ROOT/'build-vulkan-compute/harfbuzz-src')],
        cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
    result=subprocess.run(['cmake','--build',str(build),'--target',*sys.argv[1:],'-j','3'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
    print('Stage build exit',result.returncode,flush=True)
sys.exit(result.returncode)
