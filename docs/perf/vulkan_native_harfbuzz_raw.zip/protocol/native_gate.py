from pathlib import Path
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
config=sys.argv[1]
build=ROOT/'out/build'/('x64-release' if config=='Release' else 'x64-debug')
cases=json.loads((build/f'pufferui-vulkan-tests-{config}.json').read_text())
cases += [dict(target=n,args=['--selftest']) for n in ['pui_showcase_vulkan','pui_ex_vulkan','pui_tut_vulkan_manual']]
with (ROOT/f'build-vulkan-native/final-native-{config.lower()}.log').open('w') as log:
 for case in cases:
  command=[str(build/config/(case['target']+'.exe')),*case['args']]
  log.write('CASE '+repr(command)+'\n');log.flush()
  p=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  if p.returncode:print('FAIL',config,case,flush=True);sys.exit(p.returncode)
 print(config,len(cases),'native cases passed',flush=True)
