// Freeze/compare every actual Spiral frame; never updates an existing capture.
#define main native_spiral_original_main
#include "../examples/pui_showcase.cpp"
#undef main
#include <filesystem>
#include <fstream>
#include <chrono>
#include <thread>

namespace
{
i32 failures = 0;
void diagnostic(i32 code, const char *text, void *)
{
    std::fprintf(stderr, "Vulkan %d: %s\n", code, text);
    ++failures;
}
void seed_scene(example_app &app, i32 count)
{
    app.selftest = true;
    focus_window(app.ctx, *app.win);
    mouse_move(*app.win, 800, 220);
    g_app = showcase{};
    seed(g_app);
    g_app.lab_mode = 4;
    g_app.lab_size = 64;
    while (g_app.tiles.size() < static_cast<usize>(count)) add_tile(g_app);
}
bool initialize(example_app &app, render_device *device, i32 count)
{
    app.device = device;
    app.surface = create_vulkan_surface(device, {.width = 1360, .height = 860});
    if (!app.surface) return false;
    app.ctx = create_context(device, app.surface);
    app.win = add_window(app.ctx, nullptr, app.surface, rect::make(0, 0, 1360, 860));
    app.font = load_font(app.ctx, PUFFERUI_ASSET_DIR "/fonts/DejaVuSans.ttf");
    app.font_bold = load_font(app.ctx, PUFFERUI_ASSET_DIR "/fonts/DejaVuSans-Bold.ttf");
    app.font_oblique = load_font(app.ctx, PUFFERUI_ASSET_DIR "/fonts/DejaVuSans-Oblique.ttf");
    app.width = 1360;
    app.height = 860;
    seed_scene(app, count);
    return app.font != FONT_INVALID && app.font_bold != FONT_INVALID;
}
void frame(example_app &app, i32 f)
{
    app.frame_index = f;
    app.now = f / 60.0;
    app.dt = 1.0 / 60.0;
    if (f >= 90 && (f - 90) % 30 == 0)
    {
        app.win->focus = "lab_add"_id;
        key_event(*app.win, key::ENTER, true);
    }
    if (f >= 91 && (f - 91) % 30 == 0) key_event(*app.win, key::ENTER, false);
    begin_frame(app.ctx, *app.win, app.now, app.dt);
    {
        ui u(app.ctx);
        showcase_frame(u, app);
    }
    end_frame(app.ctx);
}
} // namespace


int main(int argc,char**argv) {
 bool bitmap=false,staged=false,windowed=false;int hz=0;
 const char *capture=nullptr,*reference=nullptr;
 for(int i=1;i<argc;++i) {
  if(!std::strcmp(argv[i],"--bitmap")) bitmap=true;
  else if(!std::strcmp(argv[i],"--staged")) staged=true;
  else if(!std::strcmp(argv[i],"--windowed")) windowed=true;
  else if(!std::strcmp(argv[i],"--hz")&&i+1<argc) hz=std::atoi(argv[++i]);
  else if(!std::strcmp(argv[i],"--capture")&&i+1<argc) capture=argv[++i];
  else if(!std::strcmp(argv[i],"--reference")&&i+1<argc) reference=argv[++i];
  else return 2;
 }
 if(capture&&!std::filesystem::create_directory(capture)) return 2;
 vulkan_device_opts opts;
 opts.validation=capture||reference;
 opts.error_callback=diagnostic;
 opts.upload_mode=staged?vulkan_upload_mode::STAGED:vulkan_upload_mode::DIRECT;
#if defined(PUFFERUI_ENABLE_HARFBUZZ)
 opts.vector_text=!bitmap;
#endif
 example_app app;render_device*device=nullptr;
 g_start_page=PAGE_OVERVIEW;g_no_hud=true;
 if(windowed) {
  app.boot.vulkan=opts;
  char program[]="Overview probe",selftest[]="--selftest",no_script[]="--no-script";
  char*arguments[]={program,selftest,no_script};
  if(!example_init(app,"Overview probe",1360,860,3,arguments))return 1;
  device=app.device;device->set_vsync(false);seed_scene(app,0);
 } else {
  device=create_vulkan_device(opts);
  if(!device||!initialize(app,device,0)) return 1;
 }
 if(!vulkan_wait_idle(device))return 1;
 const auto initial=vulkan_statistics(device);
 std::vector<u8>pixels(1360*860*4),expected(pixels.size());
 std::puts("frame,total_ms,upload_bytes,resident_bytes,gpu_samples,gpu_ms,glyph_instances");
 const auto epoch=std::chrono::steady_clock::now();
 for(int f=0;f<180;++f) {
  const auto before=vulkan_statistics(device);
  const auto start=std::chrono::steady_clock::now();
  app.frame_index=f;app.now=f/60.0;app.dt=1.0/60.0;
  begin_frame(app.ctx,*app.win,app.now,app.dt);
  {ui u(app.ctx);showcase_frame(u,app);}
  end_frame(app.ctx);
  const double elapsed=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
  const auto after=vulkan_statistics(device);
  unsigned long long glyphs=0;
#if defined(PUFFERUI_ENABLE_HARFBUZZ)
  glyphs=after.glyph_instances-before.glyph_instances;
#endif
  std::printf("%d,%.9f,%llu,%llu,%llu,%.9f,%llu\n",f,elapsed,
   static_cast<unsigned long long>(after.upload_bytes-before.upload_bytes),
   static_cast<unsigned long long>(after.upload_allocated_bytes),
   static_cast<unsigned long long>(after.gpu_samples-before.gpu_samples),
   after.completed_gpu_ms-before.completed_gpu_ms,glyphs);
  if(vulkan_last_result(device)!=VK_SUCCESS||violation_count(app.ctx)||failures)return 1;
  if(capture||reference) {
   if(!device->read_pixels(app.surface->scene_target(),0,0,1360,860,pixels.data()))return 1;
   char name[32];std::snprintf(name,sizeof(name),"frame-%03d.rgba",f);
   if(capture) {std::ofstream out(std::filesystem::path(capture)/name,std::ios::binary);out.write(reinterpret_cast<const char*>(pixels.data()),pixels.size());if(!out)return 1;}
   if(reference) {std::ifstream in(std::filesystem::path(reference)/name,std::ios::binary);in.read(reinterpret_cast<char*>(expected.data()),expected.size());if(!in||pixels!=expected){std::fprintf(stderr,"Overview mismatch %d\n",f);return 1;}}
  }
  if(hz)std::this_thread::sleep_until(epoch+std::chrono::duration_cast<std::chrono::steady_clock::duration>(std::chrono::duration<double>(double(f+1)/hz)));
 }
 if(!vulkan_wait_idle(device))return 1;
 const auto after=vulkan_statistics(device);
 std::fprintf(stderr,"gpu_total_ms=%.9f gpu_samples=%llu frames=180\n",after.completed_gpu_ms-initial.completed_gpu_ms,
  static_cast<unsigned long long>(after.gpu_samples-initial.gpu_samples));
 if(after.validation_errors||failures)return 1;
 if(windowed){app.selftest=false;example_shutdown(app);}
 else{destroy_context(app.ctx);device->destroy_surface(app.surface);destroy_vulkan_device(device);}
 return 0;
}
