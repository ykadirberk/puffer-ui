from pathlib import Path
import collections, csv, gzip, hashlib, io, json, statistics, subprocess, zipfile

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / 'build-vulkan-native'
DEST = ROOT / 'docs/perf'
DEST.mkdir(exist_ok=True)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def grouped(rows, fields):
    groups = collections.defaultdict(list)
    for row in rows:
        groups[(row['label'], row['staged'])].append(row)
    result = []
    for (label, staged), group in groups.items():
        entry = dict(label=label, staged=staged, repetitions=len(group))
        for field, getter in fields.items():
            values = [getter(row) for row in group]
            entry[field] = dict(mean=statistics.mean(values), minimum=min(values), maximum=max(values))
        result.append(entry)
    return result

spiral = json.loads((WORK/'qualified-final/receipt.json').read_text())
components = json.loads((WORK/'component-qualified-final/receipt.json').read_text())
gpu = json.loads((WORK/'gpu-qualified/receipt.json').read_text())
assert len(spiral['runs']) == len(components['overview']) == len(gpu['runs']) == 36
assert spiral['exact_frames'] == 1440
assert all(sha(ROOT/name) == value for name,value in spiral['source_hashes'].items())
preserved = json.loads(subprocess.check_output(['git','show','b30a7be:docs/perf/vulkan_default_runtime_final.json'],cwd=ROOT))['preserved_unrelated']
assert all(sha(ROOT/name) == value for name,value in preserved.items())

cpu = collections.defaultdict(list)
for name in ['core-before','core-after','hb-cpu']:
    for path in sorted((WORK/'component-qualified-final').glob(name+'-*.csv')):
        for row in csv.DictReader(path.read_text().splitlines()):
            cpu[(name,row.get('case'),row.get('mode'),row.get('workload'))].append(row)
cpu_summary=[]
for (name,case,mode,workload), rows in cpu.items():
    field='total_ms' if name=='hb-cpu' else 'ms_per_iteration'
    values=[float(row[field]) for row in rows]
    cpu_summary.append(dict(probe=name,case=case,mode=mode,workload=workload,
        mean_ms=statistics.mean(values),minimum_ms=min(values),maximum_ms=max(values),
        repetitions=len(rows),rows=rows))

gpu_groups=collections.defaultdict(list)
for row in gpu['runs']:
    for counter,value in row['summary'].items():
        gpu_groups[row['label'],row['staged'],counter].append(value)
gpu_summary=[dict(label=label,staged=staged,counter=counter,
    mean=statistics.mean(row['mean'] for row in rows),sampled_maximum=max(row['max'] for row in rows),
    repetitions=len(rows),samples=sum(row['samples'] for row in rows))
    for (label,staged,counter),rows in gpu_groups.items()]

all_frames=[]
for phase in ['qualified','qualified-final']:
    for row in csv.DictReader((WORK/phase/'frames.csv').read_text().splitlines()):
        all_frames.append(dict(phase=phase,scenario='Spiral',**row))
for phase in ['component-qualified','component-qualified-final']:
    for path in sorted((WORK/phase).glob('overview-*.csv')):
        parts=path.stem.rsplit('-',2)
        for row in csv.DictReader(path.read_text().splitlines()):
            all_frames.append(dict(phase=phase,scenario='Overview',label=parts[0][9:],staged=parts[1],repeat=parts[2],**row))
fields=list(dict.fromkeys(key for row in all_frames for key in row))
data=io.StringIO(newline='');writer=csv.DictWriter(data,fieldnames=fields);writer.writeheader();writer.writerows(all_frames)
frames_path=DEST/'vulkan_native_harfbuzz_frames.csv.gz'
with frames_path.open('wb') as stream:
    with gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as zipped:
        zipped.write(data.getvalue().encode())

raw_path=DEST/'vulkan_native_harfbuzz_raw.zip'
with zipfile.ZipFile(raw_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for phase in ['qualified','qualified-final','component-qualified','component-qualified-final','gpu-qualified']:
        for path in sorted((WORK/phase).iterdir()):
            if path.suffix in ['.json','.csv','.log']:
                archive.write(path,path.relative_to(WORK).as_posix())
    for path in sorted(WORK.iterdir()):
        if path.is_file() and path.suffix in ['.py','.cpp','.log','.csv','.json']:
            archive.write(path,'protocol/'+path.name)

baseline_commit=subprocess.check_output(['git','rev-parse','8c62fc4'],cwd=ROOT,text=True).strip()
live=json.loads((WORK/'live-check.json').read_text())
receipt=dict(
    objective='First native Vulkan base; renderer-owned triangle shapes, HarfBuzz + upstream Slug graphics text; no compute/SDF shape painter',
    base_commit=baseline_commit,preserved_main='b30a7be5b08d13b7e3c1c535fb3dbd0d615bea12',
    branch='codex/vulkan-native-harfbuzz',platform='Windows x64, MSVC Release, AMD Radeon RX 9070 XT',
    date='2026-10-29',foreground_fps_certified=False,
    spiral=spiral,overview=components,windows_pdh=gpu,
    spiral_summary=grouped(spiral['runs'],{
        'wall_ms':lambda row:row['wall']['mean'],'p99_ms':lambda row:row['wall']['p99'],
        'maximum_ms':lambda row:row['wall']['maximum'],'cold_ms':lambda row:row['cold_ms'],
        'gpu_ms':lambda row:row['gpu_ms'],'peak_upload_bytes':lambda row:row['peak_upload_bytes']}),
    overview_summary=grouped(components['overview'],{key:lambda row,key=key:row[key]
        for key in ['mean_ms','max_ms','cold_ms','gpu_ms','peak_upload_bytes','gpu_samples']}),
    cpu_summary=cpu_summary,gpu_summary=gpu_summary,
    checkout_byte_policy_sha256=sha(ROOT/'.gitattributes'),
    timed_frames=dict(final_spiral=6480,final_overview=6480,pdh_paced=6480,initial_diagnostic_spiral=6480,initial_diagnostic_overview=6480),
    validation=dict(full_release='full-release.log: all steps passed',full_debug='full-debug.log: all steps passed',
        final_vulkan_only_fix='30 native cases per configuration after automatic geometry high-water preparation',
        final_native_case_counts={config:(WORK/f'final-native-{config}.log').read_text().count('CASE ') for config in ['release','debug']},
        harfbuzz_off='harfbuzz-off.log: core/SDL-free native build and offscreen interactions passed',
        existing_bitmap_goldens_changed=False,existing_assertions_weakened=False,
        old_vulkan_bitmap_fixtures_explicitly_select_bitmap=True,
        exact_spiral_frames=1440,exact_overview_bitmap_frames=360,
        native_text_scalar_frames=192,old_native_Slug_text_only_frames=192),
    live=live,preserved_unrelated=preserved,
    artifact_hashes={p.name:sha(p) for p in [frames_path,raw_path]},
    local_reference_directories=['build-vulkan-native/first-native-rgba','build-vulkan-native/native-text-before-rgba','build-vulkan-native/old-slug-rgba','build-vulkan-native/first-native-overview-rgba'],
    limits=['Offscreen timing excludes device creation and presentation; PDH uses hidden WSI with a fixed 60 Hz harness cap.',
        'PDH memory maximum is sampled; upload allocation capacity is not total GPU VRAM.',
        'Native Slug is a distinct text representation; its pixels are not asserted equal to bitmap text.',
        'All cold frames and outliers are retained. Direct wall time and some peak/percentile results regress.',
        'Linux runtime was not executed on this Windows host.',
        'Initial diagnostic cohort is retained; absolute timings across cohorts are not controlled frequency comparisons.'])
(DEST/'vulkan_native_harfbuzz_final.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Packaged',len(all_frames),'all-frame rows;',len(spiral['source_hashes']),'measured source hashes;',len(preserved),'untouched drafts')
print('Archive bytes',raw_path.stat().st_size,'frames bytes',frames_path.stat().st_size)
