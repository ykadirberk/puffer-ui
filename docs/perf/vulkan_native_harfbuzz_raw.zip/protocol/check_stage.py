from pathlib import Path
import subprocess, shutil
ROOT=Path(__file__).resolve().parents[1]
work=ROOT/'build-vulkan-native'
bin=work/'base-build/Release'
cases=[('pui_vulkan_native_text_tests',['--reference',str(work/'old-slug-rgba')]),
       ('pui_vulkan_native_text_tests',['--staged','--reference',str(work/'old-slug-rgba')]),
       ('pui_vulkan_native_text_tests',[]),('pui_vulkan_native_text_tests',['--staged']),
       ('pui_harfbuzz_tests',[]),('pui_vulkan_native_spiral_tests',[]),
       ('pui_vulkan_native_spiral_tests',['--bitmap','--reference',str(work/'first-native-rgba')])]
with (work/'stage-checks.log').open('w') as log:
    for exe,args in cases:
        print(exe,args,flush=True)
        log.write(exe+' '+' '.join(args)+'\n'); log.flush()
        result=subprocess.run([str(bin/(exe+'.exe')),*args],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        if result.returncode: raise SystemExit(result.returncode)
shutil.copy2(bin/'pui_vulkan_native_spiral_tests.exe',work/'native-text-before.exe')
print('All native text and baseline oracles passed; pre-optimization executable frozen',flush=True)
