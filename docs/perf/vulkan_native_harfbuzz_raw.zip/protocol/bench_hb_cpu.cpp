#include <hb.h>
#include <hb-gpu.h>
#include <cstdint>
static uint64_t shape_calls = 0, outline_encodes = 0;
static void profile_shape(hb_font_t *font, hb_buffer_t *buffer, const hb_feature_t *features, unsigned count)
{
    ++shape_calls;
    hb_shape(font, buffer, features, count);
}
static hb_blob_t *profile_encode(hb_gpu_draw_t *draw, hb_glyph_extents_t *extents)
{
    ++outline_encodes;
    return hb_gpu_draw_encode(draw, extents);
}
#define hb_shape profile_shape
#define hb_gpu_draw_encode profile_encode
#define PUFFERUI_IMPLEMENTATION
#include <pufferui/vulkan.h>
#undef hb_shape
#undef hb_gpu_draw_encode
#include <chrono>
#include <string>
#include <vector>
using namespace pui;
struct text_device : null_device
{
    bool vectors = false;
    render_painter *create_painter(context &c) override
    {
        auto *p = new renderer_detail::mesh_painter(c);
        p->vectors = vectors;
        return p;
    }
};
volatile double sink = 0;
int main()
{
    std::puts("mode,workload,calls,total_ms,shape_calls,outline_encodes");
    std::vector<std::string> labels;
    for (int i = 0; i < 5000; ++i) labels.push_back("#" + std::to_string(i));
    for (bool vectors : {false, true})
    {
        text_device d;
        d.vectors = vectors;
        auto *c = create_context(&d, d.create_surface());
        auto font = load_font(c, PUFFERUI_ASSET_DIR "/fonts/DejaVuSans.ttf");
        auto th = default_dark();
        th.font = font;
        th.text_size = 15;
        set_theme(c, th);
        ui u(c);
        const auto measure = [&](const char *name, int count, auto &&call)
        {
            auto shapes = shape_calls, outlines = outline_encodes;
            const auto start = std::chrono::steady_clock::now();
            for (int i = 0; i < count; ++i) call(i);
            const double elapsed = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now()-start).count();
            std::printf("%s,%s,%d,%.9f,%llu,%llu\n",vectors?"HarfBuzz":"bitmap",name,count,elapsed,
                static_cast<unsigned long long>(shape_calls-shapes),static_cast<unsigned long long>(outline_encodes-outlines));
        };
        measure("cold_5000",5000,[&](int i){sink=u.text_width(labels[i]);});
        for(int i=0;i<64;++i) sink=u.text_width(labels[i]);
        measure("warm_64",64000,[&](int i){sink=u.text_width(labels[i%64]);});
        measure("churn_5000",50000,[&](int i){sink=u.text_width(labels[i%5000]);});
        measure("size_churn_64",6400,[&](int i){auto style=u.text_style(13.0f+static_cast<float>(i%17)*.13f,font);sink=u.text_width(labels[i%64]);});
        if(vectors)
        {
            auto *native=detail::harfbuzz_font(c,font);
            auto *buffer=hb_buffer_create();
            measure("hb_shape_only_ascii",50000,[&](int i){
                hb_buffer_reset(buffer);
                const auto &s=labels[i%5000];
                hb_buffer_add_utf8(buffer,s.data(),static_cast<int>(s.size()),0,static_cast<int>(s.size()));
                hb_buffer_guess_segment_properties(buffer);
                profile_shape(native,buffer,nullptr,0);
                sink=hb_buffer_get_length(buffer);
            });
            hb_buffer_destroy(buffer);
        }
        if(violation_count(c)) return 1;
        destroy_context(c);
    }
}
