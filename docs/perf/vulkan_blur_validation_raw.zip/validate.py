from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
work = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'tools'))
from run_tests import import_msvc_env

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

mode = sys.argv[1]
if mode == 'freeze':
    tracked = subprocess.check_output(['git', 'ls-files', 'tests'], cwd=root, text=True).splitlines()
    unrelated = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', 'docs'],
                                        cwd=root, text=True).splitlines()
    assert not (work / 'original.json').exists()
    original = {str(p): digest(root / p) for p in tracked + unrelated}
    (work / 'original.json').write_text(json.dumps(original, indent=2))
    before = work / 'before'
    before.mkdir(exist_ok=True)
    for name in ['pui_showcase_vulkan.exe', 'SDL3.dll', 'harfbuzz.dll']:
        source = root / 'out/build/x64-release/Release' / name
        if source.exists():
            shutil.copy2(source, before / name)
    print(f'Preserved {len(tracked)} test/oracle files and {len(unrelated)} unrelated docs')
    sys.exit(0)

original = json.loads((work / 'original.json').read_text())
assert all(digest(root / p) == expected for p, expected in original.items())
import_msvc_env()
os.environ['VULKAN_SDK'] = 'E:/VulkanSDK/1.4.335.0'
formatter = root / 'build-perf-review/format-tool/clang_format/data/bin/clang-format.exe'
os.environ['PATH'] = str(formatter.parent) + os.pathsep + os.environ['PATH']
os.environ['CMAKE_BUILD_PARALLEL_LEVEL'] = '3'
if mode == 'build':
    changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=root, text=True).splitlines()
    changed += ['include/pufferui/impl/vulkan_blur.inl', 'tests/test_vulkan_blur.cpp']
    sources = [p for p in changed if Path(p).suffix in ['.cpp', '.h', '.inl']]
    commands = [[sys.executable, 'tools/compile_vulkan_shaders.py'],
                [str(formatter), '-i', *sources],
                ['cmake', '-S', '.', '-B', 'out/build/x64-release', '-DPUFFERUI_WITH_VULKAN=ON'],
                ['cmake', '--build', 'out/build/x64-release', '--target', 'pui_vulkan_blur_tests',
                 'pui_showcase_vulkan', 'pui_demo', '-j', '3']]
elif mode in ['release', 'debug']:
    commands = [[sys.executable, 'tools/run_tests.py', '--vulkan', '--format',
                 *(['--release'] if mode == 'release' else [])]]
elif mode == 'test-build':
    commands = [[str(formatter), '-i', 'tests/test_vulkan_blur.cpp'],
                ['cmake', '--build', 'out/build/x64-release', '--target',
                 'pui_vulkan_blur_tests', '-j', '3']]
elif mode == 'debug-build':
    commands = [['cmake', '-S', '.', '-B', 'out/build/x64-debug', '-DPUFFERUI_WITH_VULKAN=ON'],
                ['cmake', '--build', 'out/build/x64-debug', '--target', 'vulkan_tests',
                 'pui_core_tests', 'pui_pump_tests', 'pui_perf_tests', 'pui_memory_tests',
                 'pui_preparation_tests', 'pui_showcase_tests', 'pui_golden_tests',
                 'pui_perf_pixels', 'pui_core_perf_pixels', '-j', '3']]
elif mode == 'off':
    build = work / 'off-build'
    exe = str(build / 'Release/pui_vulkan_blur_tests.exe')
    commands = [['cmake', '-S', '.', '-B', str(build), '-G', 'Ninja',
                 '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_MSVC_DEBUG_INFORMATION_FORMAT=Embedded',
                 '-DPUFFERUI_WITH_VULKAN=ON', '-DPUFFERUI_WITH_HARFBUZZ=OFF',
                 '-DPUFFERUI_WITH_SDL3=OFF', '-DPUFFERUI_BUILD_EXAMPLES=OFF'],
                ['cmake', '--build', str(build), '--target', 'pui_vulkan_blur_tests', '-j', '3'],
                [exe], [exe, '--staged']]
elif mode == 'focused':
    exe = str(root / 'out/build/x64-release/Release/pui_vulkan_blur_tests.exe')
    commands = [[exe], [exe, '--staged']]
else:
    raise ValueError(mode)

with (work / f'{mode}.log').open('w', encoding='utf-8') as log:
    for command in commands:
        log.write('COMMAND ' + repr(command) + '\n')
        log.flush()
        subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT, check=True)
assert all(digest(root / p) == expected for p, expected in original.items())
print(f'{mode} passed; original files unchanged', flush=True)
