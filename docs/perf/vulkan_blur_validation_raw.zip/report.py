from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

root = Path(__file__).resolve().parents[1]
work = Path(__file__).resolve().parent
original = json.loads((work / 'original.json').read_text())
def digest(data):
    return hashlib.sha256(data).hexdigest()

assert all(digest((root / p).read_bytes()) == value for p, value in original.items())
gates = {}
for mode in ['release', 'debug']:
    content = (work / f'{mode}.log').read_text(encoding='utf-8', errors='replace')
    summary = content.rsplit('================ summary', 1)[-1]
    assert 'all steps passed' in summary and not re.search(r'^(FAIL|skip)\s', summary, re.M)
    assert re.search(r'^ok\s+clang-format', summary, re.M)
    gates[mode] = {
        'command': 'python tools/run_tests.py --vulkan --format' + (' --release' if mode == 'release' else ''),
        'all_steps_passed': True,
        'vulkan_cases_passed': len(re.findall(r'^ok\s+Vulkan ', summary, re.M)),
        'log_sha256': digest((work / f'{mode}.log').read_bytes()),
    }
for mode in ['focused', 'off']:
    content = (work / f'{mode}.log').read_text(encoding='utf-8', errors='replace')
    assert content.count('108 exact cached/reference frames') == 2

changes = subprocess.check_output(['git', 'diff', '--name-only'], cwd=root, text=True).splitlines()
changes += ['include/pufferui/impl/vulkan_blur.inl', 'tests/test_vulkan_blur.cpp']
sources = {p: digest((root / p).read_bytes()) for p in changes
           if p.startswith(('include/', 'src/')) or p == 'CMakeLists.txt' or p == 'tests/test_vulkan_blur.cpp'}
assert not subprocess.check_output(['git', '-C', 'vendored/SDL', 'status', '--porcelain'], cwd=root).strip()
original_tests = {p: h for p, h in original.items() if p.startswith('tests/')}
unrelated = {p: h for p, h in original.items() if p.startswith('docs/')}
live = {
    'date': '2026-11-01',
    'showcase': {
        'executable': 'out/build/x64-release/Release/pui_showcase_vulkan.exe',
        'arguments': [],
        'observed': ['vulkan showcase label', 'startup VSync ON', 'Overview to Effects',
                     'Blur radius display 3 (Gaussian)', 'Blur radius display 27 (Dual Kawase)',
                     'normal close'],
        'limits': ['A lens drag was requested; displacement was not observed and is not certified.'],
    },
    'demo': {
        'executable': 'out/build/x64-release/Release/pui_demo.exe',
        'observed': ['both windows', 'Click me: 0 to 1', 'normal secondary close',
                     'main window remains visible with Open window 2', 'normal main close'],
        'tool_recovery': 'Indexed click reported element 5 unavailable in cached app state. Fresh window/screenshot selection and a coordinate click succeeded.',
    },
    'task_windows_remaining': 0,
    'scope': 'Functional observations; no matched before/after FPS benchmark.',
}
(work / 'live.json').write_text(json.dumps(live, indent=2) + '\n', encoding='utf-8')
archive = root / 'docs/perf/vulkan_blur_validation_raw.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name in ['release.log', 'debug.log', 'focused.log', 'off.log', 'original.json',
                 'live.json', 'validate.py', 'report.py']:
        output.write(work / name, name)
receipt = {
    'date': '2026-11-01',
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'selection': {'units': 'framebuffer pixels after render_scale', 'gaussian_inclusive_max': 8,
                  'wide_filter': 'Dual Kawase'},
    'scope': 'Vulkan native painter; existing mesh/SDL blur stays independent.',
    'visual_contract': 'Blur output changes from the previous resampling pyramid. Existing test sources and SDL golden bytes are unchanged. Native cache/reference equality is exact.',
    'gates': gates,
    'new_regressions': {
        'target': 'pui_vulkan_blur_tests', 'upload_modes': ['DIRECT', 'STAGED'],
        'exact_full_frame_pairs_per_mode_per_configuration': 108,
        'cpu_convolution_max_channel_error': 2,
        'coverage': ['8px and nextafter(8px) selection', 'Gaussian and Kawase CPU kernels',
                     'public Gaussian output and exact outside-clip preservation',
                     'odd extents and stale scratch padding', 'DPI and rounded alpha clips',
                     'empty/outside clips and zero/NaN/infinite radii', 'retained target reuse',
                     'idle Gaussian/Kawase cache hits without GPU draws',
                     'filter kernel/operand invalidation'],
        'optional_off': {'harfbuzz': False, 'sdl3': False, 'both_upload_modes_passed': True},
    },
    'original_test_oracle_files_unchanged': len(original_tests),
    'unrelated_draft_files_unchanged': len(unrelated),
    'preserved_files_sha256': original,
    'source_sha256': sources,
    'vendored_sdl_clean': True,
    'live': live,
    'reviewed_image': {'path': 'docs/img/readme/vulkan-showcase.png',
                       'sha256': digest((root / 'docs/img/readme/vulkan-showcase.png').read_bytes())},
    'raw': {'path': str(archive.relative_to(root)).replace('\\', '/'),
            'sha256': digest(archive.read_bytes())},
}
(root / 'docs/perf/vulkan_blur_validation.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: receipt[k] for k in ['gates', 'original_test_oracle_files_unchanged',
                                         'unrelated_draft_files_unchanged']}, indent=2))
