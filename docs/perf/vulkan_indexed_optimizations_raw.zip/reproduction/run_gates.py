from pathlib import Path
import json,subprocess,sys,time
work=Path(__file__).resolve().parent;root=work.parent;results=[]
for mode in ['suite-release','suite-debug','off','gaussian-goldens']:
    print('Starting '+mode,flush=True);start=time.perf_counter()
    result=subprocess.run([sys.executable,str(work/'driver.py'),mode],cwd=root)
    results.append(dict(mode=mode,returncode=result.returncode,seconds=time.perf_counter()-start))
    (work/'gate-results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(mode+' exit '+str(result.returncode),flush=True)
    if result.returncode:raise SystemExit(result.returncode)
