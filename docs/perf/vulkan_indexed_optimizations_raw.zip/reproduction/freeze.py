from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path(__file__).resolve().parents[1];work=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
names=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0')
hashes={n:sha(root/n) for n in names if n and (root/n).is_file()}
status=subprocess.check_output(['git','status','--porcelain','-z'],cwd=root).decode().split('\0')
drafts={s[3:]:sha(root/s[3:]) for s in status if s.startswith('?? ') and (root/s[3:]).is_file()}
before=work/'before';before.mkdir(exist_ok=False)
exe=root/'out/build/x64-release/Release/pui_vulkan_native_spiral_tests.exe'
shutil.copy2(exe,before/exe.name)
shutil.copy2(root/'include/pufferui/impl/vulkan_draw.inl',before/'vulkan_draw.inl')
refs=json.loads((root/'build-vulkan-blur-opt4/baseline.json').read_text())['references']
for mode,items in refs.items():
    for name,value in items.items():assert sha(root/f'build-vulkan-gaussian-fix/spiral-{mode}'/name)==value
css={p.name:sha(p) for p in (root/'build-vulkan-blur-opt4/css-goldens').glob('*.bmp')};assert len(css)==36
result=dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    branch=subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip(),
    hashes=hashes,tests={n:v for n,v in hashes.items() if n.startswith('tests/')},drafts=drafts,
    references=refs,css_goldens=css,binary=dict(path=str(before/exe.name),sha256=sha(before/exe.name)))
(work/'baseline.json').write_text(json.dumps(result,indent=2)+'\n')
print('Frozen',result['commit'],len(result['tests']),'test/oracle files,',len(drafts),'drafts, 360 Spiral frames and 36 CSS references')
