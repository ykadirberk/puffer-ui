from pathlib import Path
import os,subprocess,sys
root=Path(__file__).resolve().parents[1];work=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'));from run_tests import import_msvc_env
import_msvc_env();os.environ['VULKAN_SDK']='E:/VulkanSDK/1.4.335.0'
os.environ['CMAKE_BUILD_PARALLEL_LEVEL']='3'
formatter=root/'build-perf-review/format-tool/clang_format/data/bin/clang-format.exe'
os.environ['PATH']=str(formatter.parent)+os.pathsep+os.environ['PATH']
mode=sys.argv[1];release=root/'out/build/x64-release'
def run(command,log):
    log.write(repr(list(map(str,command)))+'\n');log.flush()
    subprocess.run(list(map(str,command)),cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
with (work/(mode+'.log')).open('w') as log:
    if mode=='library':
        run([formatter,'-i','include/pufferui/impl/vulkan_draw.inl'],log)
        run(['cmake','--build',release,'--target','pufferui_vulkan','-j','3'],log)
    elif mode=='targeted':
        run([formatter,'-i','include/pufferui/impl/vulkan_draw.inl','tests/test_vulkan_indexed.cpp'],log)
        targets=['pui_vulkan_indexed_tests','pui_vulkan_blur_optimization_tests','pui_vulkan_native_spiral_tests','pui_showcase_vulkan']
        run(['cmake','--build',release,'--target',*targets,'-j','3'],log)
        for args in [[],['--staged']]:
            run([release/'Release/pui_vulkan_indexed_tests.exe',*args],log)
            run([release/'Release/pui_vulkan_blur_optimization_tests.exe',*args],log)
    elif mode in ['suite-release','suite-debug']:
        run([sys.executable,'tools/run_tests.py','--vulkan','--format',*(['--release'] if mode.endswith('release') else [])],log)
    elif mode=='off':
        off=root/'build-vulkan-blur-opt4/off'
        run(['cmake','-S',root,'-B',off,'-DPUFFERUI_WITH_VULKAN=ON','-DPUFFERUI_WITH_SDL3=OFF','-DPUFFERUI_WITH_HARFBUZZ=OFF'],log)
        run(['cmake','--build',off,'--target','pui_vulkan_tests','pui_vulkan_indexed_tests','-j','3'],log)
        run([off/'Release/pui_vulkan_tests.exe'],log)
        for args in [[],['--staged']]:run([off/'Release/pui_vulkan_indexed_tests.exe',*args],log)
    elif mode=='gaussian-goldens':
        for args in [[],['--staged']]:
            run([release/'Release/pui_vulkan_gaussian_tests.exe',*args,'--goldens',root/'build-vulkan-blur-opt4/css-goldens'],log)
    else:raise ValueError(mode)
print(mode+' completed',flush=True)
