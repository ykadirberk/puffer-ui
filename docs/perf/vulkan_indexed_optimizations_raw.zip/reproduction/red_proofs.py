from pathlib import Path
import json,os,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];work=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'));from run_tests import import_msvc_env
import_msvc_env();results=[]
for variant in ['green','scalar','rebase']:
    out=work/('red-'+variant);out.mkdir(exist_ok=False)
    shutil.copytree(root/'include',out/'include')
    path=out/'include/pufferui/impl/vulkan_draw.inl';source=path.read_bytes()
    if variant=='scalar':
        a=b'if (count - span.end >= 24)';b=b'if (false && count - span.end >= 24)'
        assert source.count(a)==1;path.write_bytes(source.replace(a,b,1))
    elif variant=='rebase':
        a=b'return base > 0 && count > 0 &&';b=b'return false && base > 0 && count > 0 &&'
        assert source.count(a)==1;path.write_bytes(source.replace(a,b,1))
    exe=out/'indexed.exe'
    command=['cl','/nologo','/std:c++20','/EHsc','/O2','/MD','/DNDEBUG',
        '/DPUFFERUI_ENABLE_VULKAN','/DPUFFERUI_VULKAN_INDEXED_TESTS',
        '/I'+str(out/'include'),'/I'+str(root/'vendored/stb'),'/IE:/VulkanSDK/1.4.335.0/Include',
        str(root/'tests/test_vulkan_indexed.cpp'),'/Fo'+str(out/'indexed.obj'),'/Fe'+str(exe),
        '/link','E:/VulkanSDK/1.4.335.0/Lib/vulkan-1.lib','user32.lib']
    with (out/'build.log').open('w') as log:
        log.write(repr(command)+'\n');log.flush()
        subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
    with (out/'test.log').open('w') as log:
        result=subprocess.run([exe,'--cpu'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
    text=(out/'test.log').read_text()
    assert result.returncode==(0 if variant=='green' else 1),(variant,text)
    if variant=='scalar':assert 'span_work.triangles' in text,text
    if variant=='rebase':assert 'geometry_vertex_offset' in text,text
    results.append(dict(variant=variant,returncode=result.returncode,expected_failure=variant!='green',diagnostic=text.strip()))
    print(variant,result.returncode,flush=True)
(work/'red-proofs.json').write_text(json.dumps(results,indent=2)+'\n')
