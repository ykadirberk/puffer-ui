from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time
root=Path(__file__).resolve().parents[1];work=Path(__file__).resolve().parent
print('Waiting for initial sequential gates; no benchmark overlaps builds/tests',flush=True)
while True:
    path=work/'gate-results.json'
    if path.exists():
        results=json.loads(path.read_text())
        if any(x['returncode'] for x in results):raise SystemExit('An initial gate failed')
        if len(results)==4:break
    time.sleep(2)
archive=work/'preliminary';archive.mkdir(exist_ok=False)
shutil.copy2(work/'suite-release.log',archive/'suite-release.log')
shutil.copy2(work/'gate-results.json',archive/'gate-results.json')
final=[r for r in results if r['mode'] in ['suite-debug','off']]
def run(mode,command):
    print('Starting final '+mode,flush=True);start=time.perf_counter()
    result=subprocess.run(list(map(str,command)),cwd=root)
    final.append(dict(mode=mode,returncode=result.returncode,seconds=time.perf_counter()-start))
    (work/'final-gate-results.json').write_text(json.dumps(final,indent=2)+'\n')
    if result.returncode:raise SystemExit(result.returncode)
run('red-proofs',[sys.executable,work/'red_proofs.py'])
run('suite-release',[sys.executable,work/'driver.py','suite-release'])
run('gaussian-goldens',[sys.executable,work/'driver.py','gaussian-goldens'])
formatter=root/'build-perf-review/format-tool/clang_format/data/bin/clang-format.exe'
run('new-file-format',[formatter,'--dry-run','--Werror',root/'tests/test_vulkan_indexed.cpp',root/'include/pufferui/impl/vulkan_draw.inl'])
processes=subprocess.run(['powershell','-NoProfile','-Command',
    "@(Get-Process pui_showcase_vulkan,pui_demo -ErrorAction SilentlyContinue) | Select-Object Id,ProcessName | ConvertTo-Json -Compress"],
    capture_output=True,text=True)
(work/'project-process-check.log').write_text(processes.stdout+processes.stderr)
if processes.stdout.strip():raise SystemExit('Project window/process active; measurement deferred')
run('spiral-comparison',[sys.executable,root/'tools/compare_vulkan_indexed.py',
    work/'before/pui_vulkan_native_spiral_tests.exe',root/'out/build/x64-release/Release/pui_vulkan_native_spiral_tests.exe',
    '--baseline',work/'baseline.json','--reference',root/'build-vulkan-gaussian-fix/spiral-direct',
    '--output',work/'timings','--runs','6'])
receipt=json.loads((work/'timings/receipt.json').read_text())
assert hashlib.sha256((root/'out/build/x64-release/Release/pui_vulkan_native_spiral_tests.exe').read_bytes()).hexdigest()==receipt['binaries']['after']['sha256']
print('Final unchanged suites and all-frame comparison passed',flush=True)
print(json.dumps(receipt['summary'],indent=2),flush=True)
