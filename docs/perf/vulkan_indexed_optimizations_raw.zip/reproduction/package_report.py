from pathlib import Path
import csv,gzip,hashlib,json,os,shutil,statistics,subprocess,sys,zipfile
root=Path(__file__).resolve().parents[1];work=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
baseline=load(work/'baseline.json');timing=load(work/'timings/receipt.json')
gates=load(work/'final-gate-results.json');red=load(work/'red-proofs.json')
assert all(x['returncode']==0 for x in gates)
assert {'suite-release','suite-debug','off','red-proofs','gaussian-goldens','spiral-comparison'}.issubset({x['mode'] for x in gates})
assert [x['returncode'] for x in red]==[0,1,1]
allowed={'AGENTS.md','CMakeLists.txt','docs/vulkan.md','include/pufferui/impl/vulkan_draw.inl'}
for name,value in {**baseline['hashes'],**baseline['drafts']}.items():
    if name not in allowed:assert sha(root/name)==value,name
for name,value in timing['source_hashes'].items():assert sha(root/name)==value,name
after=root/'out/build/x64-release/Release/pui_vulkan_native_spiral_tests.exe'
assert sha(after)==timing['binaries']['after']['sha256']
assert baseline['references']['direct']==baseline['references']['staged']
for mode,items in baseline['references'].items():
    for name,value in items.items():assert sha(root/f'build-vulkan-gaussian-fix/spiral-{mode}'/name)==value
for name,value in baseline['css_goldens'].items():assert sha(root/'build-vulkan-blur-opt4/css-goldens'/name)==value
registry={mode:load(root/f'out/build/x64-{mode}/pufferui-vulkan-tests-{mode.capitalize()}.json') for mode in ['release','debug']}
assert all(len(items)==37 for items in registry.values())
dest=root/'docs/perf';summary=timing['summary']
frames=list(csv.DictReader((work/'timings/frames.csv').open()))
assert len(frames)==4320
same_index={}
for mode in ['direct','staged']:
    same_index[mode]={side:{str(f):statistics.median(float(r['total_ms']) for r in frames
        if r['mode']==mode and r['side']==side and int(r['frame'])==f) for f in [127,128]}
        for side in ['before','after']}
peak_ids={0,1,119,120,126,127,128,129,149,150,151,179}
for run in timing['runs']:
    for f in [run['peak_frame']-1,run['peak_frame'],run['peak_frame']+1]:
        if 0<=f<180:peak_ids.add(f)
sys.path.insert(0,str(root/'build-vulkan-blur-opt4/plot_lib'))
os.environ['MPLCONFIGDIR']=str(work/'plot-cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axes=plt.subplots(1,2,figsize=(13,4.5),layout='constrained',sharey=True)
for ax,mode in zip(axes,['direct','staged']):
    for side,color in [('before','#99a2ac'),('after','#168777')]:
        for i in range(6):
            rows=[r for r in frames if r['mode']==mode and r['side']==side and int(r['repeat'])==i]
            ax.plot([int(r['frame']) for r in rows],[float(r['total_ms']) for r in rows],
                    color=color,alpha=.7,lw=.9,label=side if i==0 else None)
    for f in [90,120,150]:ax.axvline(f,color='#555',ls='--',lw=.6,alpha=.4)
    ax.set_title(mode.upper());ax.set_xlabel('Frame (Add at 90 / 120 / 150)');ax.set_xlim(0,179)
    ax.grid(alpha=.18);ax.legend(frameon=False)
axes[0].set_ylim(0,max(float(r['total_ms']) for r in frames)*1.08)
axes[0].set_ylabel('Production wall time (ms), every run')
fig.suptitle('Native Spiral 5000 -> 5003 | indexed upload optimization | no outlier removal')
plot=dest/'vulkan_indexed_optimizations_spiral.png';fig.savefig(plot,dpi=150)
table=[]
for mode in ['direct','staged']:
    a,b=summary[mode]['before'],summary[mode]['after']
    table.append(f"| {mode.upper()} | {a['mean_ms']:.4f} / {b['mean_ms']:.4f} | {summary[mode]['paired_wall_percent']:+.2f}% | {a['p99_ms']:.4f} / {b['p99_ms']:.4f} | {a['max_ms']:.4f} / {b['max_ms']:.4f} | {a['gpu_ms']:.4f} / {b['gpu_ms']:.4f} |")
report=f'''# Vulkan indexed upload: exact block planning and native vertex offsets

Date: 2026-11-01. Source baseline: `{baseline['commit']}`. Branch:
`{baseline['branch']}`. Windows native execution on AMD Radeon RX 9070 XT;
new regression logs record the actual vendor/device/driver identity.

## Changes

The validated large-draw path accepts eight-triangle blocks, refining a boundary
with the original scalar greedy rule. Block bounds and byte use only grow, so
every accepted prefix also fits. A first triangle that exceeds the arena returns
immediately to sparse fallback, without reading a speculative block. No heap
storage, new arena or increased upload budget is introduced. The complete public
input is still checked before any GPU prefix is recorded.

Dense spans copy original index bytes and pass their negated base through
`vkCmdDrawIndexed`'s signed vertex offset. This retains effective vertex indices,
attributes, primitive order and upload sizes. Only nonnegative source ranges
within the portable 24-bit index limit use the native offset; internal negative,
INT_MIN, larger and signed-boundary cases retain CPU rebasing. Borrowed Vulkan
devices need no additional feature enablement. Shaders, Gaussian strength,
Kawase, fonts, motion and rendering configuration are unchanged.

The actual Add still inserts at a random rank and moves later Spiral targets
through the visible stage. Its visible geometry burst remains real; this change
reduces preparation cost while preserving that animation.

## Matched production measurement

The unchanged showcase harness renders 1360x860, initial 5000 tiles, size 64,
Spiral, 180 fixed 1/60s frames, keyboard Adds at 90/120/150 and final 5003 tiles.
Six alternating before/after runs per upload mode retain **4,320 timed frames**.
No timed readbacks, concurrent builds/tests or other project windows occur.
All cold/outlier frames remain. This is offscreen native execution, not a
foreground presentation/FPS or per-PID GPU-utilization result.

Wall mean and p99 are medians of six run statistics. p99 uses the empirical
lower rank (index 177 of 180 sorted frames). Worst is the absolute maximum of
the entire six-run group. Paired change is the median of matched run-mean changes.
GPU is completed submission interval total / 180 logical frames; CPU/GPU overlap.

| Upload | Wall before / after ms | Paired wall change | p99 before / after ms | Worst before / after ms | GPU before / after ms |
|---|---:|---:|---:|---:|---:|
{chr(10).join(table)}

The DIRECT before absolute maximum is the cold frame 0; it is retained, not
attributed solely to steady geometry preparation. Same-index medians across the
six repetitions isolate the recurring geometry peak without removing any frame:

| Upload | Frame 127 before / after ms | Frame 128 before / after ms |
|---|---:|---:|
| DIRECT | {same_index['direct']['before']['127']:.4f} / {same_index['direct']['after']['127']:.4f} | {same_index['direct']['before']['128']:.4f} / {same_index['direct']['after']['128']:.4f} |
| STAGED | {same_index['staged']['before']['127']:.4f} / {same_index['staged']['after']['127']:.4f} | {same_index['staged']['before']['128']:.4f} / {same_index['staged']['after']['128']:.4f} |

Total GPU intervals are nearly flat: DIRECT
**{(summary['direct']['after']['gpu_ms']/summary['direct']['before']['gpu_ms']-1)*100:+.2f}%**,
STAGED **{(summary['staged']['after']['gpu_ms']/summary['staged']['before']['gpu_ms']-1)*100:+.2f}%**.
This is a CPU preparation/peak-latency improvement, not a general GPU speedup.
Individual frames do not all become faster, and the actual geometry burst and
remaining peaks are retained rather than approximated away.

Every per-frame upload byte count agrees before/after, including the geometry
peak. Every timed draw-buffer allocation count is zero. Allocated upload-page
capacity is reported separately from uploaded bytes and is not total VRAM.
The source and binary hashes are sealed in the receipt. The measured candidate
binary matches the final standard Release native-Spiral executable exactly.

![Every matched timing trace](perf/vulkan_indexed_optimizations_spiral.png)

## Regression and image verification

- New `pui_vulkan_indexed_tests` compares all split tuples to the frozen scalar
  implementation across 1,260 dense/fan/reversed/random/sparse/degenerate/negative
  stream/stride/capacity combinations, including partial blocks and exact edges.
  Stable work counters reject a return to one serial capacity check per triangle;
  an oversized sparse first triangle also avoids speculative block reads.
- Actual Vulkan bind/draw hooks check uploaded index bytes, signed vertex offset
  and effective indices, then compare full overlapping translucent pixels with
  the normalized reference. Eight bases cover zero, ordinary positive, both
  24-bit edges, larger, negative, INT_MIN and near-INT_MAX values. Both strides,
  one/two frame slots and direct/staged paths give 64 exact pixel pairs.
- Isolated CPU builds pass green; disabling block acceptance fails the work
  regression; restoring unconditional CPU rebasing fails the offset regression.
  These expected failures remain in raw evidence and do not alter production.
- Full Release and Debug `--vulkan --format` gates pass with **37 native cases
  each**, original core/pump/performance/allocation suites, SDL goldens, 1150/5000
  Spiral/peaks, all example selftests, installed consumers and API/tutorial checks.
  The final Release gate includes the last sparse-first fast fallback. A prior
  Release pass is archived separately as preliminary, not used as the final gate.
- Vulkan with HarfBuzz OFF / SDL OFF passes the base and new direct/staged target.
  The 36 immutable CSS Gaussian cases also pass in both upload modes: 576 exact
  frames and 144 idle hits; all coefficients and reference bytes remain fixed.
- All 180 actual Spiral frames compare with immutable RGBA captures in both
  upload modes and candidate cache off/on: **720 candidate comparisons**, plus
  360 before-reference identity frames. Every timed peak/cold frame is covered.
  Full RGBA goldens for every observed maximum and its neighbours are archived.
- All **{len(baseline['tests'])} original test/oracle files** and **{len(baseline['drafts'])} pre-existing untracked
  report drafts** retain their starting hashes. No golden update mode is used.
  Existing test bodies and existing report drafts are excluded from the commit.

## Evidence and reproduction

[Receipt and hashes](perf/vulkan_indexed_optimizations.json),
[all timed frames](perf/vulkan_indexed_optimizations_frames.csv.gz),
[complete logs, scalar source, new regressions and peak goldens](perf/vulkan_indexed_optimizations_raw.zip).
All 360 original capture hashes are retained; complete direct/staged references
remain under `build-vulkan-gaussian-fix/spiral-direct` and `spiral-staged`.

```powershell
python tools/compare_vulkan_indexed.py `
  build-vulkan-indexed-opt2/before/pui_vulkan_native_spiral_tests.exe `
  out/build/x64-release/Release/pui_vulkan_native_spiral_tests.exe `
  --baseline build-vulkan-indexed-opt2/baseline.json `
  --reference build-vulkan-gaussian-fix/spiral-direct `
  --output build-vulkan-indexed-repeat --runs 6
```

Use a new output directory. Interactive showcase launch still uses the ordinary
`out/build/x64-release/Release/pui_showcase_vulkan.exe` without Python.
'''
report_path=root/'docs/perf_vulkan_indexed_optimizations.md';report_path.write_text(report)
csv_path=dest/'vulkan_indexed_optimizations_frames.csv.gz'
with gzip.open(csv_path,'wb') as f:f.write((work/'timings/frames.csv').read_bytes())
archive=dest/'vulkan_indexed_optimizations_raw.zip';inventory={}
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    def add(path,name):
        data=path.read_bytes()
        if path.suffix in ['.py','.cpp','.inl','.json','.log','.csv']:
            data=data.replace(b'C:\\Users\\Kadir Berk',b'<USERPROFILE>').replace(b'<USERPROFILE>',b'<USERPROFILE>')
        z.writestr(name,data);inventory[name]=hashlib.sha256(data).hexdigest()
    for name in ['baseline.json','final-gate-results.json','red-proofs.json','library.log','targeted.log','suite-release.log','suite-debug.log','off.log','gaussian-goldens.log','project-process-check.log']:
        add(work/name,name)
    for f in (work/'timings').iterdir():
        if f.is_file() and f.suffix!='.exe':add(f,'timings/'+f.name)
    for folder in ['red-green','red-scalar','red-rebase','preliminary']:
        for f in (work/folder).iterdir():
            if f.is_file() and f.suffix in ['.log','.json']:add(f,folder+'/'+f.name)
    add(work/'before/vulkan_draw.inl','reference/vulkan_draw_before.inl')
    for name in ['include/pufferui/impl/vulkan_draw.inl','tests/test_vulkan_indexed.cpp','tools/compare_vulkan_indexed.py']:
        add(root/name,'source/'+name)
    for f in work.glob('*.py'):add(f,'reproduction/'+f.name)
    for frame in sorted(peak_ids):
        name=f'frame-{frame:03}.rgba';add(root/'build-vulkan-gaussian-fix/spiral-direct'/name,'peaks/'+name)
    for name in baseline['css_goldens']:add(root/'build-vulkan-blur-opt4/css-goldens'/name,'css-goldens/'+name)
    z.writestr('inventory.json',json.dumps(inventory,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
receipt=dict(date='2026-11-01',baseline_commit=baseline['commit'],branch=baseline['branch'],
    measurement=timing,same_index_wall_ms=same_index,gates=gates,red_proofs=red,native_cases={m:len(v) for m,v in registry.items()},
    original_test_hashes=baseline['tests'],protected_draft_hashes=baseline['drafts'],
    reference_hashes=baseline['references'],css_golden_hashes=baseline['css_goldens'],archived_peak_frame_ids=sorted(peak_ids),
    validation=dict(candidate_spiral_exact_frames=720,before_spiral_identity_frames=360,
        css_exact_frames=576,css_idle_hits=144,indexed_pixel_pairs=64,existing_test_bodies_changed=False,
        golden_update_used=False,foreground_certified=False),
    artifacts={str(p.relative_to(root)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in [report_path,csv_path,archive,plot]})
(dest/'vulkan_indexed_optimizations.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(summary=summary,peaks=sorted(peak_ids),archive_bytes=archive.stat().st_size),indent=2))
