from pathlib import Path
import subprocess,json,hashlib
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent;out=w/'controls';out.mkdir(exist_ok=False)
records=[]
for mode in ['direct','staged']:
 for side,binary in [('before',w/'before/pui_vulkan_gaussian_tests.exe'),('after',r/'out/build/x64-release/Release/pui_vulkan_gaussian_tests.exe')]:
  path=out/f'{side}-{mode}'
  cmd=[str(binary),'--capture-controls',str(path),*(['--staged'] if mode=='staged' else [])]
  with (out/f'{side}-{mode}.log').open('w') as log:subprocess.run(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
 for i in range(8):
  before=(out/f'before-{mode}/control-{i:02}.bmp').read_bytes();after=(out/f'after-{mode}/control-{i:02}.bmp').read_bytes()
  assert before[54+112*193*4:]==after[54+112*193*4:],(mode,i,'Unrelated shape/text/footer changed')
  assert (before==after)==bool(i%2),(mode,i,'Kawase must be identical; CSS Gaussian must change')
  records.append(dict(mode=mode,scale=[1,1.5,2,3][i//2],kind='kawase' if i%2 else 'gaussian',whole_image_equal=before==after,footer_equal=True,
   before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(after).hexdigest()))
(out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');print('8 high-DPI Kawase images and 16 unaffected text/footer regions exact; CSS Gaussian changes only its mask')
