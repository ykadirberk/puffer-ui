from pathlib import Path
import subprocess,sys
w=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(w/'prepare_probe.py'),'after-probe-v2'],check=True)
p=w/'after-probe-v2'
f=p/'probe.cpp';s=f.read_text()
s=s.replace('extern bool full_filter;','extern bool full_filter;\nextern bool keep_load;\nvoid attachment(void *, unsigned long long, bool);',1)
s=s.replace('bool full_filter=false;','bool full_filter=false;\nbool keep_load=false;\nvoid *active_painter=nullptr;',1)
s=s.replace('auto *native=static_cast<vk_detail::native_painter *>(painter);','auto *native=static_cast<vk_detail::native_painter *>(painter);\n    active_painter=painter;',1)
s=s.replace('    active=-1;\n}\nvoid image','    active=-1; active_painter=nullptr;\n}\nvoid image',1)
s=s.replace('frames[current].load_pixels+=loads;','',1).replace('blurs[active].loads+=loads;','',1)
needle='void validated(int count,double ms) {'
definition='''void attachment(void *t,u64 pixels,bool load) {
    if(current<0||active<0||!active_painter||!load)return;
    auto *p=static_cast<vk_detail::native_painter *>(active_painter);
    if(p->ctx->blur&&(t==p->ctx->blur->half||t==p->ctx->blur->quarter)) {
        frames[current].load_pixels+=pixels;blurs[active].loads+=pixels;
    }
}
'''
assert s.count(needle)==1;s=s.replace(needle,definition+needle,1)
s=s.replace('else if(!std::strcmp(argv[i],"--full-filter")) review::full_filter=true;',
 'else if(!std::strcmp(argv[i],"--full-filter")) review::full_filter=true;\n        else if(!std::strcmp(argv[i],"--keep-load")) review::keep_load=true;',1)
f.write_text(s)
f=p/'include/pufferui/impl/vulkan_draw.inl';s=f.read_text()
needle='    attachment.storeOp = VK_ATTACHMENT_STORE_OP_STORE;'
assert s.count(needle)==1
s=s.replace(needle,'    if (::review::keep_load) attachment.loadOp = VK_ATTACHMENT_LOAD_OP_LOAD;\n    ::review::attachment(t, static_cast<u64>(t->width) * t->height, attachment.loadOp == VK_ATTACHMENT_LOAD_OP_LOAD);\n'+needle,1)
f.write_text(s)
print('Prepared final probe with actual scratch LOAD scopes and independent clip/load controls')
