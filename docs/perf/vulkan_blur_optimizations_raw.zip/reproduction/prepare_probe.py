from pathlib import Path
import shutil,sys
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent;p=w/(sys.argv[1] if len(sys.argv)>1 else 'after-probe')
p.mkdir(exist_ok=False);shutil.copytree(r/'include',p/'include')
def patch(name,old,new):
 f=p/'include/pufferui/impl'/name;b=f.read_bytes();old=old.replace('\n','\r\n').encode();new=new.replace('\n','\r\n').encode()
 # clang-format preserves each slice's existing newline style.
 if old not in b:old=old.replace(b'\r\n',b'\n');new=new.replace(b'\r\n',b'\n')
 assert b.count(old)==1,(name,old[:100],b.count(old));f.write_bytes(b.replace(old,new,1))
patch('vulkan_draw.inl','    for (i32 i = 0; i < ic; ++i)\n        if (idx[i] < index_base',
 '    const f64 validation_start = wall_ms();\n    for (i32 i = 0; i < ic; ++i)\n        if (idx[i] < index_base')
patch('vulkan_draw.inl','    paint_validated(sample, {v, vc, idx, ic, index_base}, {blend, filter, kernel});',
 '    ::review::validated(ic, wall_ms() - validation_start);\n    paint_validated(sample, {v, vc, idx, ic, index_base}, {blend, filter, kernel});')
patch('vulkan_memory.inl','    frame->serial = next_serial++;','    ::review::submitted(next_serial);\n    frame->serial = next_serial++;')
patch('vulkan_memory.inl','    stats.completed_gpu_ms += static_cast<f64>((values[2] - values[0]) & mask) *\n                              properties.limits.timestampPeriod / 1000000.0;',
 '    const f64 interval_ms = static_cast<f64>((values[2] - values[0]) & mask) *\n                              properties.limits.timestampPeriod / 1000000.0;\n    stats.completed_gpu_ms += interval_ms;\n    ::review::harvested(slot.query_serial, interval_ms);')
patch('vulkan_resources.inl','    t->allocation = req.size;','    ::review::image(w, h, req.size, creation.render_target, creation.internal);\n    t->allocation = req.size;')
patch('vulkan_blur.inl','    void blur(const paint_blur &p) override\n    {',
 '    void blur(const paint_blur &p) override\n    {\n        ::review::blur_begin(this, &p);\n        execute_blur(p);\n        ::review::blur_end(this);\n    }\n    void execute_blur(const paint_blur &p)\n    {')
patch('vulkan_blur.inl','        if (!prepare_blur(width, height, ow, oh, plan.gaussian)) return;',
 '        if (!prepare_blur(width, height, ow, oh, plan.gaussian)) return;\n        ::review::blur_gpu_begin(this);')
patch('vulkan_blur.inl','    set_clip(pass.clipped ? &pass.clip : nullptr);',
 '    set_clip(pass.clipped ? &pass.clip : nullptr);\n    const rect covered = pass.clipped ? rect::intersect(destination_area, pass.clip) : destination_area;\n    ::review::filtered(destination->width, destination->height, covered.w, covered.h, static_cast<u32>(pass.kernel));')
patch('vulkan_blur.inl','    auto &parameters = pass.parameters;',
 '    if (::review::full_filter) pass.clipped = false;\n    auto &parameters = pass.parameters;')
fixture=(r/'tests/test_vulkan_native_spiral.cpp').read_text().replace('int main(int argc, char **argv)','int review_unused_main(int argc, char **argv)',1)
fixture=fixture.replace('"../examples/pui_showcase.cpp"','"'+(r/'examples/pui_showcase.cpp').as_posix()+'"')
(p/'spiral_fixture.inl').write_text(fixture)
shutil.copy2(r/'build-vulkan-blur-review/cohort-v2-probe.cpp',p/'probe.cpp')
b=(p/'probe.cpp').read_text().replace('out.radius<=15','out.radius<=vk_detail::GAUSSIAN_RADIUS_LIMIT')
b=b.replace('namespace review {\n','namespace review {\nextern bool full_filter;\n',1)
b=b.replace('bool gpu_blur=false;','bool gpu_blur=false;\nbool full_filter=false;',1)
b=b.replace('else if(!std::strcmp(argv[i],"--gpu-blur")) review::gpu_blur=true;',
 'else if(!std::strcmp(argv[i],"--gpu-blur")) review::gpu_blur=true;\n        else if(!std::strcmp(argv[i],"--full-filter")) review::full_filter=true;',1)
(p/'probe.cpp').write_text(b)
shutil.copy2(r/'build-vulkan-blur-review/cohort-v2-build.py',p/'build.py')
# The original wrapper's root discovery assumes a direct child directory.
b=(p/'build.py').read_text().replace('parents[1]','parents[2]')
(p/'build.py').write_text(b)
print('Prepared isolated instrumented current headers; production unchanged')
