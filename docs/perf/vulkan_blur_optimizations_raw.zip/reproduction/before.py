from pathlib import Path
import json,subprocess,time
root=Path(__file__).resolve().parents[1];work=Path(__file__).resolve().parent;out=work/'before-timings';out.mkdir(exist_ok=False)
exe=work/'before/pui_vulkan_native_spiral_tests.exe';records=[]
for repeat in range(6):
 for upload in (['direct','staged'] if repeat%2==0 else ['staged','direct']):
  stem=f'{upload}-{repeat}';args=[str(exe),'--bench',*(['--staged'] if upload=='staged' else [])]
  start=time.perf_counter()
  with (out/(stem+'.csv')).open('w') as stdout,(out/(stem+'.log')).open('w') as stderr:
   subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr,check=True)
  records.append(dict(command=args,process_ms=(time.perf_counter()-start)*1000))
  print(stem+' baseline measured',flush=True)
(out/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
