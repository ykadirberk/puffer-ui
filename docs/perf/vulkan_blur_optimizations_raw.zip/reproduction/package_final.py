from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import csv,hashlib,json,subprocess
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent;p=r/'docs/perf'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
d=json.loads((w/'analysis-final.json').read_text())
d['validation']['readme_comparison']=json.loads((w/'readme-comparison.json').read_text())
assert d['validation']['readme_comparison']['outside_hud_changed_pixels']==0
for name,value in d['current']['source_hashes'].items():assert sha(r/name)==value,name
for name,value in {**d['current']['unchanged_tests'],**d['current']['protected_drafts']}.items():assert sha(r/name)==value,name
peak_ids=sorted({n for f in d['validation']['archived_peak_frame_ids'] for n in [f-1,f,f+1] if 0<=n<180})
d['validation']['archived_peak_frame_ids_with_neighbors']=peak_ids
paths={}
def add(path,name):
 assert path.is_file(),path
 assert name not in paths,name
 paths[name]=path
for folder in ['timings','timings-v2','before-timings','profiles','profiles-v2','resources','resources-v1','resources-v2','controls','css-goldens','css-actual-v2-visual-direct','css-actual-v2-visual-staged','v1-gates']:
 for path in sorted((w/folder).rglob('*')):
  if path.is_file() and path.suffix in ['.json','.csv','.log','.bmp']:
   add(path,'runs/'+path.relative_to(w).as_posix())
for path in sorted(w.glob('*.log')):add(path,'validation/'+path.name)
for path in sorted(w.glob('*.py')):add(path,'reproduction/'+path.name)
for name in ['baseline.json','focused.json','final-gate-results.json','readme-comparison.json']:
 add(w/name,'validation/'+name)
for folder in ['before/include','after-probe/include','after-probe-v2/include']:
 for path in sorted((w/folder).rglob('*')):
  if path.is_file():add(path,'reproduction/'+path.relative_to(w).as_posix())
for folder in ['after-probe','after-probe-v2']:
 for name in ['probe.cpp','spiral_fixture.inl','build.py','build.log']:
  add(w/folder/name,'reproduction/'+folder+'/'+name)
for path in sorted((w/'candidate-v1').glob('*')):
 if path.is_file():add(path,'reproduction/candidate-v1/'+path.name)
for name in ['LICENSE','docs/licenses/harfbuzz-slug.txt']:
 add(r/name,'reproduction/'+name)
for frame in peak_ids:
 name=f'frame-{frame:03}.rgba';source=r/'build-vulkan-gaussian-fix/spiral-direct'/name
 assert sha(source)==d['current']['reference_hashes'][name]
 add(source,'goldens/spiral-peaks/'+name)
zip_path=p/'vulkan_blur_optimizations_raw.zip'
replacements=[(rb'<USERPROFILE>',b'<USERPROFILE>'),(rb'<USERPROFILE>',b'<USERPROFILE>'),
 (b'<USERPROFILE>',b'<USERPROFILE>'),(b'<USERPROFILE>',b'<USERPROFILE>'),(rb'<USERPROFILE>',b'<USERPROFILE>'),(rb'<USERPROFILE>',b'<USERPROFILE>')]
text_suffixes={'.log','.json','.csv','.py','.cpp','.inl','.h','.txt','.patch'}
inventory={}
with ZipFile(zip_path,'w',ZIP_DEFLATED,compresslevel=6) as z:
 for name,path in paths.items():
  data=path.read_bytes()
  if path.suffix in text_suffixes:
   for old,new in replacements:data=data.replace(old,new)
  inventory[name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
  z.writestr(name,data)
 z.writestr('inventory.json',json.dumps(inventory,indent=2)+'\n')
 z.writestr('README.txt','All final timed frames and initial candidate evidence are retained. Full RGBA goldens for every observed timing peak and its neighbours are included; the receipt records all 180 original hashes. Complete references remain in the original workspace. Frame size: 1360x860 RGBA8. Text copies redact user-profile path prefixes. No golden update or tolerance relaxation was used.\n')
assert zip_path.stat().st_size<95*1024*1024
with ZipFile(zip_path) as z:
 assert z.testzip() is None
 for name,check in inventory.items():assert hashlib.sha256(z.read(name)).hexdigest()==check['sha256']
d['artifacts']={name:dict(bytes=(p/name).stat().st_size,sha256=sha(p/name)) for name in ['vulkan_blur_optimizations_raw.zip','vulkan_blur_optimizations_frames.csv.gz','vulkan_blur_spiral.png','vulkan_blur_strength.png']}
d['artifacts']['raw_entries']=len(inventory)
(w/'analysis-final.json').write_text(json.dumps(d,indent=2)+'\n')
(p/'vulkan_blur_optimizations.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(dict(archive_bytes=zip_path.stat().st_size,entries=len(inventory),peak_ids=peak_ids,source_hashes_unchanged=True,protected_tests=len(d['current']['unchanged_tests']),protected_drafts=len(d['current']['protected_drafts'])),indent=2))
