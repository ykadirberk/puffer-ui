from pathlib import Path
import subprocess,json,time
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent;b=r/'out/build/x64-release/Release'
jobs=[]
for args in [[],['--staged']]:
 jobs += [(b/'pui_vulkan_blur_tests.exe',*args),(b/'pui_vulkan_gaussian_tests.exe',*args,'--goldens',w/'css-goldens')]
 for cache in [[],['--cache']]:
  jobs.append((b/'pui_vulkan_native_spiral_tests.exe',*args,*cache,'--reference',r/('build-vulkan-gaussian-fix/spiral-staged' if args else 'build-vulkan-gaussian-fix/spiral-direct')))
results=[]
for i,job in enumerate(jobs):
 with (w/f'focused-{i}.log').open('w') as log:
  start=time.perf_counter();p=subprocess.run(list(map(str,job)),cwd=r,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(command=list(map(str,job)),returncode=p.returncode,ms=(time.perf_counter()-start)*1000))
 (w/'focused.json').write_text(json.dumps(results,indent=2))
 print(i,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
