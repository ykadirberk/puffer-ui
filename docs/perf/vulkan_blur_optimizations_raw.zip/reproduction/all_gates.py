from pathlib import Path
import subprocess,sys,shutil,time,json
w=Path(__file__).resolve().parent;r=w.parent
shutil.copy2(w/'suite-release.log',w/'suite-release-initial.log')
results=[]
for mode in ['suite-release','suite-debug']:
 start=time.perf_counter()
 p=subprocess.run([sys.executable,str(w/'driver.py'),mode],cwd=r)
 results.append(dict(mode=mode,returncode=p.returncode,seconds=time.perf_counter()-start))
 (w/'gate-results.json').write_text(json.dumps(results,indent=2)+'\n')
 if p.returncode:raise SystemExit(p.returncode)
