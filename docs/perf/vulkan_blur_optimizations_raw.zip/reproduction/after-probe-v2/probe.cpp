#include <array>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <iomanip>
namespace review {
extern bool full_filter;
extern bool keep_load;
void attachment(void *, unsigned long long, bool);
void submitted(unsigned long long serial);
void harvested(unsigned long long serial, double ms);
void blur_begin(void *, const void *);
void blur_gpu_begin(void *);
void blur_end(void *);
void image(int, int, unsigned long long, bool, bool);
void filtered(int, int, float, float, unsigned);
void validated(int, double);
}
#define PUFFERUI_IMPLEMENTATION
#include <pufferui/vulkan.h>
#undef near
#undef far
#undef small
namespace review {
using namespace pui;
constexpr int MAX_FRAMES=720, MAX_BLURS=20000, MAX_SERIALS=32768;
double now() { return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now().time_since_epoch()).count(); }
double thread_ms() { FILETIME c{},e{},k{},u{}; if(!GetThreadTimes(GetCurrentThread(),&c,&e,&k,&u))return -1;
    return ((static_cast<u64>(k.dwHighDateTime)<<32)+k.dwLowDateTime+(static_cast<u64>(u.dwHighDateTime)<<32)+u.dwLowDateTime)/10000.0; }
struct record {
    double wall=0, begin=0, ui=0, end=0, gpu=0, blur=0, validation=0, thread=0;
    u64 intervals=0, blurs=0, gaussian=0, kawase=0, images=0, image_allocated=0;
    u64 filter_pixels=0, load_pixels=0, filter_passes=0, validated_indices=0;
    vulkan_stats before{}, after{};
};
struct blur_record {
    int frame=-1;
    float radius=0, x=0,y=0,w=0,h=0;
    double cpu=0,gpu=0,start=0;
    u64 images=0,bytes=0,pixels=0,loads=0,passes=0;
    int query=-1;
};
std::array<record,MAX_FRAMES> frames;
std::array<blur_record,MAX_BLURS> blurs;
std::array<int,MAX_SERIALS> serial_frame;
int current=-1, active=-1, blur_count=0, query_count=0;
bool gpu_blur=false;
bool full_filter=false;
bool keep_load=false;
void *active_painter=nullptr;
double ui_start=0;
VkQueryPool pool=VK_NULL_HANDLE;
void submitted(u64 serial) { if(serial>=MAX_SERIALS) std::abort(); serial_frame[serial]=current; }
void harvested(u64 serial,double ms) {
    if(serial>=MAX_SERIALS) std::abort(); const int f=serial_frame[serial];
    if(f>=0) {frames[f].gpu+=ms; ++frames[f].intervals;}
}
void blur_begin(void *painter,const void *paint) {
    if(current<0) return;
    if(blur_count>=MAX_BLURS||active>=0) std::abort(); active=blur_count++;
    auto &out=blurs[active];
    auto &p=*static_cast<const paint_blur *>(paint);
    auto *native=static_cast<vk_detail::native_painter *>(painter);
    active_painter=painter;
    out.frame=current; out.radius=p.radius*native->ctx->render_scale;
    out.x=p.area.x;out.y=p.area.y;out.w=p.area.w;out.h=p.area.h;
    out.start=now(); ++frames[current].blurs;
    if(out.radius<=vk_detail::GAUSSIAN_RADIUS_LIMIT) ++frames[current].gaussian; else ++frames[current].kawase;
}
void blur_gpu_begin(void *painter) {
    if(active<0||!gpu_blur) return;
    auto *d=static_cast<vk_detail::native_painter *>(painter)->dev;
    auto &b=blurs[active]; b.query=query_count; query_count+=2;
    if(query_count>MAX_BLURS*2) std::abort();
    d->vkCmdWriteTimestamp2(d->frame->command,VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT,pool,b.query);
}
void blur_end(void *painter) {
    if(active<0) return;
    auto &b=blurs[active]; b.cpu=now()-b.start; frames[current].blur+=b.cpu;
    if(b.query>=0) {
        auto *d=static_cast<vk_detail::native_painter *>(painter)->dev;
        d->vkCmdWriteTimestamp2(d->frame->command,VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT,pool,b.query+1);
    }
    active=-1; active_painter=nullptr;
}
void image(int,int,u64 bytes,bool,bool) {
    if(current<0) return; ++frames[current].images; frames[current].image_allocated+=bytes;
    if(active>=0) { ++blurs[active].images; blurs[active].bytes+=bytes; }
}
void filtered(int w,int h,float written_w,float written_h,unsigned) {
    if(current<0) return;
    const auto pixels=static_cast<u64>(written_w*written_h),loads=static_cast<u64>(w)*h;
    frames[current].filter_pixels+=pixels;++frames[current].filter_passes;
    if(active>=0) {blurs[active].pixels+=pixels;++blurs[active].passes;}
}
void attachment(void *t,u64 pixels,bool load) {
    if(current<0||active<0||!active_painter||!load)return;
    auto *p=static_cast<vk_detail::native_painter *>(active_painter);
    if(p->ctx->blur&&(t==p->ctx->blur->half||t==p->ctx->blur->quarter)) {
        frames[current].load_pixels+=pixels;blurs[active].loads+=pixels;
    }
}
void validated(int count,double ms) {
    if(current>=0) {frames[current].validation+=ms;frames[current].validated_indices+=count;}
}
}
namespace pui {
template<class... A> void review_begin_frame(A&&... a) {
    const auto start=review::now(); begin_frame(std::forward<A>(a)...);
    if(review::current>=0) review::frames[review::current].begin+=review::now()-start;
    review::ui_start=review::now();
}
template<class... A> void review_end_frame(A&&... a) {
    const auto start=review::now();
    if(review::current>=0) review::frames[review::current].ui+=start-review::ui_start;
    end_frame(std::forward<A>(a)...);
    if(review::current>=0) review::frames[review::current].end+=review::now()-start;
}
}
#define begin_frame review_begin_frame
#define end_frame review_end_frame
#include "spiral_fixture.inl"
#undef begin_frame
#undef end_frame
int main(int argc,char **argv) {
    using namespace pui;
    const char *scenario="spiral",*reference=nullptr,*details=nullptr;
    float radius=15; int count=180,hz=0; bool staged=false,windowed=false,cache=false,validation=false;
    for(int i=1;i<argc;++i) {
        if(!std::strcmp(argv[i],"--scenario")&&i+1<argc) scenario=argv[++i];
        else if(!std::strcmp(argv[i],"--radius")&&i+1<argc) radius=std::strtof(argv[++i],nullptr);
        else if(!std::strcmp(argv[i],"--frames")&&i+1<argc) count=std::atoi(argv[++i]);
        else if(!std::strcmp(argv[i],"--hz")&&i+1<argc) hz=std::atoi(argv[++i]);
        else if(!std::strcmp(argv[i],"--details")&&i+1<argc) details=argv[++i];
        else if(!std::strcmp(argv[i],"--reference")&&i+1<argc) reference=argv[++i];
        else if(!std::strcmp(argv[i],"--staged")) staged=true;
        else if(!std::strcmp(argv[i],"--gpu-blur")) review::gpu_blur=true;
        else if(!std::strcmp(argv[i],"--full-filter")) review::full_filter=true;
        else if(!std::strcmp(argv[i],"--keep-load")) review::keep_load=true;
        else if(!std::strcmp(argv[i],"--windowed")) windowed=true;
        else if(!std::strcmp(argv[i],"--cache")) cache=true;
        else if(!std::strcmp(argv[i],"--validate")) validation=true;
        else return 2;
    }
    if(count<1||count>review::MAX_FRAMES||hz<0||hz>1000) return 2;
    review::serial_frame.fill(-1);
    vulkan_device_opts opts;opts.validation=validation;opts.error_callback=diagnostic;
    opts.tile_cache=cache;opts.upload_mode=staged?vulkan_upload_mode::STAGED:vulkan_upload_mode::DIRECT;
    example_app app; render_device *device=nullptr;
    g_start_page=PAGE_LAYOUT;g_no_hud=true;
    if(windowed) {
        app.boot.vulkan=opts;char program[]="blur-review",selftest[]="--selftest",script[]="--no-script";
        char *arguments[]={program,selftest,script};
        if(!example_init(app,"Vulkan blur review",1360,860,3,arguments)) return 1;
        device=app.device;device->set_vsync(false);seed_scene(app,5000);
    } else { device=create_vulkan_device(opts); if(!device||!initialize(app,device,5000)) return 1; }
    auto *d=static_cast<vk_detail::device *>(device);
    std::fprintf(stderr,"device=%s timestamp_period_ns=%.9f validation=%d\n",d->properties.deviceName,d->properties.limits.timestampPeriod,validation);
    if(review::gpu_blur) {
        VkQueryPoolCreateInfo qc{VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO};qc.queryType=VK_QUERY_TYPE_TIMESTAMP;qc.queryCount=review::MAX_BLURS*2;
        if(d->vkCreateQueryPool(d->native.device,&qc,nullptr,&review::pool)!=VK_SUCCESS||!d->commands()) return 1;
        d->vkCmdResetQueryPool(d->frame->command,review::pool,0,qc.queryCount);
    }
    const bool spiral=!std::strcmp(scenario,"spiral"),edge=!std::strcmp(scenario,"edge");
    std::vector<u8> source(1360*860*4),actual(source.size()),expected(source.size());
    for(int y=0;y<860;++y)for(int x=0;x<1360;++x)for(int c=0;c<4;++c)
        source[(y*1360+x)*4+c]=c==3?255:edge?(x<680?255:0):static_cast<u8>((x/7*31+y/9*17+c*67)%256);
    const auto background=spiral?nullptr:d->create_texture(1360,860,source.data());
    if(!vulkan_wait_idle(d)) return 1;
    const auto initial=vulkan_statistics(d);
    const auto epoch=std::chrono::steady_clock::now();
    for(int f=0;f<count;++f) {
        review::current=f;auto &out=review::frames[f];out.before=vulkan_statistics(d);const auto thread_start=review::thread_ms();const auto start=review::now();
        if(spiral) frame(app,f);
        else {
            app.frame_index=f;app.now=f/60.0;app.dt=1.0/60;
            pui::review_begin_frame(app.ctx,*app.win,app.now,app.dt);
            d->blit(background,nullptr,app.surface->scene_target(),nullptr);
            ui u(app.ctx);
            if(!std::strcmp(scenario,"mixed")) {
                u.blur({0,0,210,750},22,12);u.blur({230,0,1100,64},28,18);
            }
            if(radius>0) {
                rect area{300,220,320,220};
                if(!std::strcmp(scenario,"full")||edge) area={0,0,1360,860};
                if(!std::strcmp(scenario,"growth")) area={40,40,static_cast<f32>(128+f*3),static_cast<f32>(96+f*2)};
                u.blur(area,radius,edge?0:12,1);
            }
            pui::review_end_frame(app.ctx);
        }
        out.wall=review::now()-start;out.thread=review::thread_ms()-thread_start;out.after=vulkan_statistics(d);
        if(vulkan_last_result(d)!=VK_SUCCESS||violation_count(app.ctx)) return 1;
        if(reference) {
            if(!d->read_pixels(app.surface->scene_target(),0,0,1360,860,actual.data()))return 1;
            char name[32];std::snprintf(name,sizeof(name),"frame-%03d.rgba",f);
            std::ifstream file(std::filesystem::path(reference)/name,std::ios::binary);
            file.read(reinterpret_cast<char *>(expected.data()),expected.size());
            if(!file||file.peek()!=std::char_traits<char>::eof()||actual!=expected){std::fprintf(stderr,"pixel mismatch frame %d\n",f);return 1;}
        }
        if(hz) std::this_thread::sleep_until(epoch+std::chrono::duration_cast<std::chrono::steady_clock::duration>(std::chrono::duration<double>(static_cast<double>(f+1)/hz)));
    }
    review::current=-1;if(!vulkan_wait_idle(d)||failures)return 1;
    if(review::query_count) {
        std::vector<u64> values(review::query_count);
        if(d->vkGetQueryPoolResults(d->native.device,review::pool,0,review::query_count,values.size()*8,values.data(),8,VK_QUERY_RESULT_64_BIT|VK_QUERY_RESULT_WAIT_BIT)!=VK_SUCCESS)return 1;
        const u64 mask=d->timestamp_bits>=64?UINT64_MAX:(u64(1)<<d->timestamp_bits)-1;
        for(int i=0;i<review::blur_count;++i) {
            auto &b=review::blurs[i];if(b.query>=0)b.gpu=((values[b.query+1]-values[b.query])&mask)*d->properties.limits.timestampPeriod/1000000.0;
        }
    }
    std::puts("frame,wall_ms,begin_ms,ui_ms,end_ms,gpu_ms,gpu_intervals,blur_ms,blur_calls,gaussian_calls,kawase_calls,image_allocations,image_allocated_bytes,filter_pixels,attachment_pixels,filter_passes,index_validation_ms,validated_indices,slot_wait_ms,submit_ms,cache_ms,cache_prepare_ms,draws,submissions,upload_bytes,resident_bytes,image_bytes,retired_bytes,draw_buffer_allocations,coverage_hits,coverage_misses,coverage_fills,coverage_evictions,thread_ms");
    for(int f=0;f<count;++f) {
        const auto &o=review::frames[f];const auto &a=o.after,&b=o.before;
        std::cout<<std::setprecision(12)<<f<<','<<o.wall<<','<<o.begin<<','<<o.ui<<','<<o.end<<','<<o.gpu<<','<<o.intervals<<','<<o.blur<<','<<o.blurs<<','<<o.gaussian<<','<<o.kawase<<','<<o.images<<','<<o.image_allocated<<','<<o.filter_pixels<<','<<o.load_pixels<<','<<o.filter_passes<<','<<o.validation<<','<<o.validated_indices<<','
          <<a.slot_wait_ms-b.slot_wait_ms<<','<<a.submit_ms-b.submit_ms<<','<<a.cache_ms-b.cache_ms<<','<<a.cache_prepare_ms-b.cache_prepare_ms<<','
          <<a.draws-b.draws<<','<<a.submissions-b.submissions<<','<<a.upload_bytes-b.upload_bytes<<','<<a.upload_allocated_bytes<<','<<a.image_bytes<<','<<a.retired_bytes<<','<<a.draw_buffer_allocations-b.draw_buffer_allocations<<','
          <<a.glyph_coverage_hits-b.glyph_coverage_hits<<','<<a.glyph_coverage_misses-b.glyph_coverage_misses<<','<<a.glyph_coverage_fills-b.glyph_coverage_fills<<','<<a.glyph_coverage_evictions-b.glyph_coverage_evictions<<','<<o.thread<<'\n';
    }
    const auto final=vulkan_statistics(d);
    std::fprintf(stderr,"gpu_total_ms=%.9f samples=%llu frames=%d exact_frames=%d\n",final.completed_gpu_ms-initial.completed_gpu_ms,final.gpu_samples-initial.gpu_samples,count,reference?count:0);
    if(details) {
        std::ofstream file(details);file<<"frame,radius,x,y,w,h,cpu_ms,gpu_ms,images,allocated_bytes,filter_pixels,attachment_pixels,passes\n";
        for(int i=0;i<review::blur_count;++i){const auto &b=review::blurs[i];file<<b.frame<<','<<b.radius<<','<<b.x<<','<<b.y<<','<<b.w<<','<<b.h<<','<<b.cpu<<','<<b.gpu<<','<<b.images<<','<<b.bytes<<','<<b.pixels<<','<<b.loads<<','<<b.passes<<'\n';}
    }
    if(edge) {
        if(!d->read_pixels(app.surface->scene_target(),0,0,1360,860,actual.data())) return 1;
        std::fprintf(stderr,"edge");for(int x=640;x<=720;++x)std::fprintf(stderr,",%u",actual[(430*1360+x)*4]);std::fputc('\n',stderr);
    }
    if(review::pool)d->vkDestroyQueryPool(d->native.device,review::pool,nullptr);
    if(background)d->destroy_texture(background);
    if(windowed)example_shutdown(app);else{destroy_context(app.ctx);d->destroy_surface(app.surface);destroy_vulkan_device(d);}
    return 0;
}
