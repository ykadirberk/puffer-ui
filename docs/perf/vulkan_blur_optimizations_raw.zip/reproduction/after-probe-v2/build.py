from pathlib import Path
import os, subprocess, sys
root=Path(__file__).resolve().parents[2];work=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'));from run_tests import import_msvc_env
import_msvc_env();os.environ['VULKAN_SDK']='E:/VulkanSDK/1.4.335.0'
libs=root/'out/build/x64-release'
manifest=Path(os.environ['VSINSTALLDIR'])/'VC/Tools/MSVC'/os.environ['VCToolsVersion']/'include/manifest/segmentheap.manifest'
systems=['kernel32','user32','gdi32','winmm','imm32','version','uuid','advapi32','setupapi','shell32','hid','dinput8','uiautomationcore','comctl32','ole32','oleaut32','winspool','comdlg32']
binary=work/'probe.exe'
cmd=['cl','/nologo','/std:c++20','/EHsc','/O2','/Ob2','/GL','/MD','/DNDEBUG',
     '/DPUFFERUI_ENABLE_VULKAN','/DPUFFERUI_ENABLE_SDL3','/DPUFFERUI_ENABLE_HARFBUZZ','/DPUFFERUI_NATIVE_TELEMETRY',
     '/DPUFFERUI_ASSET_DIR="'+(root/'assets').as_posix()+'"',
     '/I'+str(work/'include'),'/I'+str(root/'vendored/stb'),'/I'+str(root/'vendored/SDL/include'),
     '/I'+str(libs/'vendored/SDL/include-revision'),'/I'+str(root/'build-vulkan-compute/harfbuzz-src/src'),
     '/IE:/VulkanSDK/1.4.335.0/Include',str(work/'probe.cpp'),
     '/Fo'+str(work/'probe.obj'),'/Fe'+str(binary),'/link','/LTCG','/MANIFEST:EMBED','/MANIFESTINPUT:'+str(manifest),
     str(libs/'vendored/SDL/SDL3-static.lib'),str(libs/'_deps/pufferui_harfbuzz-build/harfbuzz.lib'),
     str(libs/'_deps/pufferui_harfbuzz-build/harfbuzz-gpu.lib'),'E:/VulkanSDK/1.4.335.0/Lib/vulkan-1.lib',*[x+'.lib' for x in systems]]
with (work/'build.log').open('w') as log:
    log.write(repr(cmd)+'\n');log.flush();subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
assert 'C4477' not in (work/'build.log').read_text()
print('Instrumented read-only probe compiled; production binary/source unchanged')
