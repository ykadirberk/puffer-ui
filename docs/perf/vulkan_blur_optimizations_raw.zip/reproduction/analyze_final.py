from pathlib import Path
import csv,json,hashlib,re,statistics as st,math,gzip
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent
timing=json.loads((w/'timings-v2/receipt.json').read_text());baseline=json.loads((w/'baseline.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name,value in timing['source_hashes'].items():assert sha(r/name)==value,name
for name,value in {**timing['unchanged_tests'],**timing['protected_drafts']}.items():assert sha(r/name)==value,name
assert sha(r/'out/build/x64-release/Release/pui_vulkan_native_spiral_tests.exe')==timing['binaries']['after']['sha256']
data={}
def rows(stem,blur=False):
 p=w/'profiles-v2'/(stem+('.blur.csv' if blur else '.csv'))
 return list(csv.DictReader(p.open()))
def profile_summary(stems):
 runs=[]
 for stem in stems:
  a=rows(stem);b=rows(stem,True)
  gpu={f:0.0 for f in range(180)}
  for x in b:gpu[int(x['frame'])]+=float(x['gpu_ms'])
  runs.append(dict(blur_gpu_ms=st.mean(gpu.values()),blur_gpu_max_ms=max(gpu.values()),
   wall_ms=st.mean(float(x['wall_ms']) for x in a),peak=max(a,key=lambda x:float(x['wall_ms'])),
   first={k:float(a[0][k]) for k in ['image_allocations','image_allocated_bytes','image_bytes','retired_bytes','filter_pixels','attachment_pixels']},
   warm={k:st.median(float(x[k]) for x in a[1:]) for k in ['filter_pixels','attachment_pixels','image_allocations','image_bytes']},
   peaks={str(f):{k:float(a[f][k]) for k in ['wall_ms','gpu_ms','slot_wait_ms','index_validation_ms','validated_indices','upload_bytes','submissions','draw_buffer_allocations']} for f in [119,120,127,128,129]}))
 return dict(stems=stems,runs=runs,blur_gpu_ms=st.median(x['blur_gpu_ms'] for x in runs),
             wall_ms=st.median(x['wall_ms'] for x in runs))
for scenario,radius in [('spiral',0),('panel',3),('panel',8),('panel',15),('full',8),('full',15),('mixed',8)]:
 for mode in [0,1]:
  key=f'{scenario}-r{radius}-s{mode}'
  data[key]={side:profile_summary([f'{side}-{key}-{i}' for i in range(3)]) for side in ['before','after']}
controls={}
for scenario,radius in [('spiral',0),('panel',3),('panel',8),('panel',15),('full',8)]:
 for mode in [0,1]:
  key=f'{scenario}-r{radius}-s{mode}'
  controls[key]={name:profile_summary([f'control-{name}-{key}-{i}' for i in range(3)]) for name in ['default','load','full']}
resources=json.loads((w/'resources-v2/receipt.json').read_text());resource_summary={}
for mode in [False,True]:
 for side in ['before','after']:
  runs=[x for x in resources['runs'] if x['staged']==mode and x['side']==side]
  keys=sorted({k for q in runs for k in q['summary']})
  resource_summary[f'{side}-s{int(mode)}']={key:dict(median_mean=st.median(q['summary'][key]['mean'] for q in runs if key in q['summary']),
   maximum=max(q['summary'][key]['max'] for q in runs if key in q['summary'])) for key in keys}
edges={}
for radius in [3,8]:
 for side in ['before','after']:
  text=(w/'profiles-v2'/f'{side}-edge-r{radius}.log').read_text();m=re.search(r'^edge,([^\n]+)',text,re.M);assert m
  a=list(map(int,m[1].strip().split(',')));assert len(a)==81
  def cross(level):
   for i in range(len(a)-1):
    if a[i]>=level>=a[i+1] and a[i]!=a[i+1]:return 640+i+(a[i]-level)/(a[i]-a[i+1])
   raise ValueError('missing crossing')
  edges[f'{side}-r{radius}']=dict(red=a,ten_to_ninety_pixels=cross(25.5)-cross(229.5))
gates=json.loads((w/'final-gate-results.json').read_text());assert all(x['returncode']==0 for x in gates)
registry=json.loads((r/'out/build/x64-release/pufferui-vulkan-tests-Release.json').read_text())
peak_ids=sorted({0,119,120,127,128,129,150,179,*[x['peak_frame'] for x in timing['runs']]})
for f in peak_ids:
 assert sha(r/'build-vulkan-gaussian-fix/spiral-direct'/f'frame-{f:03}.rgba')==timing['reference_hashes'][f'frame-{f:03}.rgba']
for mode in ['direct','staged']:
 for name,value in baseline['references'][mode].items():assert sha(r/f'build-vulkan-gaussian-fix/spiral-{mode}'/name)==value
result=dict(date='2026-11-01',branch='codex/vulkan-native-harfbuzz',baseline_commit=baseline['commit'],
 device='AMD Radeon RX 9070 XT',vendor_id=4098,device_id=30032,driver_raw=8388996,
 current=timing,initial_candidate=json.loads((w/'timings/receipt.json').read_text()),
 profiles=data,f4_controls=controls,resource_runs=resources,resource_summary=resource_summary,
 gaussian_edges=edges,compatibility=json.loads((w/'controls/receipt.json').read_text()),
 validation=dict(gates=gates,native_cases=len(registry),unchanged_existing_tests=len(timing['unchanged_tests']),
 protected_drafts=len(timing['protected_drafts']),spiral_candidate_exact_frames=720,spiral_before_exact_frames=360,
 css_gaussian_cases=36,css_exact_frames=576,css_idle_hits=144,unchanged_kawase_images=8,unchanged_footer_regions=16,
 wsi_validated_frames=360,archived_peak_frame_ids=peak_ids,
 live_capture=dict(open_close='Standard no-argument Vulkan showcase and both SDL demo windows opened and closed normally',
  visual_certified=False,error='Computer Use capture failed twice: Direct3D11CaptureFramePool.CreateFreeThreaded 0x887A0005',
  evidence='Current application framebuffer captures reviewed separately; automated SDL input/selftests passed'),
 golden_update_used=False,foreground_certified=False))
(w/'analysis-final.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(primary=timing['summary'],native_cases=len(registry),protected=len(timing['unchanged_tests']),edge=edges,
 f4={k:{x:y['blur_gpu_ms'] for x,y in v.items()} for k,v in controls.items()}),indent=2))
