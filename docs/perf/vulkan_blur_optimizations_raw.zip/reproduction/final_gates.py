from pathlib import Path
import subprocess,sys,shutil,time,json
w=Path(__file__).resolve().parent;r=w.parent;archive=w/'v1-gates';archive.mkdir(exist_ok=False)
for name in ['suite-release.log','suite-debug.log','gate-results.json','off.log','final-visual.log','prebuild-debug.log']:
 shutil.copy2(w/name,archive/name)
results=[]
for mode in ['suite-release','suite-debug','off','v2-visual']:
 start=time.perf_counter();p=subprocess.run([sys.executable,str(w/'driver.py'),mode],cwd=r)
 results.append(dict(mode=mode,returncode=p.returncode,seconds=time.perf_counter()-start))
 (w/'final-gate-results.json').write_text(json.dumps(results,indent=2)+'\n')
 if p.returncode:raise SystemExit(p.returncode)
