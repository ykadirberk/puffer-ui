from pathlib import Path
import csv,hashlib,json,os,re,subprocess,time
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent;out=w/'profiles-v2';out.mkdir(exist_ok=False)
bins={'before':r/'build-vulkan-blur-review/probe.exe','after':w/'after-probe-v2/probe.exe'}
env=os.environ.copy()
for key in ['PUFFERUI_VULKAN_VALIDATION','VK_INSTANCE_LAYERS']:env.pop(key,None)
records=[]
def run(side,stem,args):
 cmd=[str(bins[side]),*map(str,args),'--details',str(out/(stem+'.blur.csv'))]
 start=time.perf_counter()
 with (out/(stem+'.csv')).open('w') as stdout,(out/(stem+'.log')).open('w') as stderr:
  subprocess.run(cmd,cwd=r,env=env,stdout=stdout,stderr=stderr,check=True,timeout=120)
 lines=(out/(stem+'.csv')).read_text().splitlines();begin=next(i for i,l in enumerate(lines) if l.startswith('frame,'))
 rows=[row for row in csv.DictReader(lines[begin:]) if row.get('frame','').isdigit()];assert [int(row['frame']) for row in rows]==list(range(180)),stem
 total=float(re.search(r'gpu_total_ms=([\d.]+)',(out/(stem+'.log')).read_text())[1]);assert abs(sum(float(row['gpu_ms']) for row in rows)-total)<.0001,stem
 records.append(dict(side=side,stem=stem,command=cmd,process_ms=(time.perf_counter()-start)*1000))
 (out/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(stem,flush=True)
for repeat in range(3):
 cases=[('spiral',0,False),('spiral',0,True)]+[(scenario,radius,staged) for scenario,radius in [('panel',3),('panel',8),('panel',15),('full',8),('full',15),('mixed',8)] for staged in [False,True]]
 if repeat%2:cases.reverse()
 for scenario,radius,staged in cases:
  for side in (['before','after'] if repeat%2==0 else ['after','before']):
   run(side,f'{side}-{scenario}-r{radius}-s{int(staged)}-{repeat}',
       ['--scenario',scenario,'--radius',radius,*(['--staged'] if staged else []),'--gpu-blur'])
for repeat in range(3):
 for scenario,radius in [('spiral',0),('panel',3),('panel',8),('panel',15),('full',8)]:
  for staged in [False,True]:
   variants=[('default',[]),('load',['--keep-load']),('full',['--keep-load','--full-filter'])]
   if repeat%2:variants.reverse()
   for name,flags in variants:
    run('after',f'control-{name}-{scenario}-r{radius}-s{int(staged)}-{repeat}',
        ['--scenario',scenario,'--radius',radius,*flags,'--gpu-blur',*(['--staged'] if staged else [])])
for side in ['before','after']:
 for staged in [False,True]:
  run(side,f'{side}-golden-s{int(staged)}',['--scenario','spiral','--reference',r/'build-vulkan-gaussian-fix/spiral-direct',*(['--staged'] if staged else []),'--validate','--gpu-blur'])
 for radius in [3,8]:
  run(side,f'{side}-edge-r{radius}',['--scenario','edge','--radius',radius,'--gpu-blur'])
for staged in [False,True]:
 run('after',f'control-full-golden-s{int(staged)}',['--scenario','spiral','--full-filter','--keep-load','--reference',r/'build-vulkan-gaussian-fix/spiral-direct','--validate','--gpu-blur',*(['--staged'] if staged else [])])
 run('after',f'validate-wsi-s{int(staged)}',['--scenario','spiral','--windowed','--validate','--gpu-blur',*(['--staged'] if staged else [])])
(out/'binaries.json').write_text(json.dumps({s:dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for s,p in bins.items()},indent=2)+'\n')
