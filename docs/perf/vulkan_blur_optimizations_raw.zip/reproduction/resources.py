from pathlib import Path
import csv,importlib.util,json,os,re,subprocess,time,hashlib,sys
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent;out=w/(sys.argv[2] if len(sys.argv)>2 else 'resources-v1');out.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('pdh',r/'build-vulkan-blur-review/pdh_reference.py');pdh=importlib.util.module_from_spec(spec);spec.loader.exec_module(pdh)
cohort=sys.argv[1] if len(sys.argv)>1 else 'timings'
bins={'before':w/cohort/'before.exe','after':w/cohort/'after.exe'};records=[]
env=os.environ.copy()
for key in ['PUFFERUI_VULKAN_VALIDATION','VK_INSTANCE_LAYERS']:env.pop(key,None)
for repeat in range(3):
 for staged in ([False,True] if not repeat%2 else [True,False]):
  for side in (['before','after'] if not repeat%2 else ['after','before']):
   stem=f'{side}-s{int(staged)}-{repeat}';samples=[];q=pdh.Query()
   command=[str(bins[side]),'--bench','--windowed','--hz','60',*(['--staged'] if staged else [])]
   start=time.perf_counter()
   with (out/(stem+'.csv')).open('w') as stdout,(out/(stem+'.log')).open('w') as stderr:
    p=subprocess.Popen(command,cwd=r,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    try:
     q.sample(p.pid)
     while p.poll() is None:
      if time.perf_counter()-start>40:p.kill();raise TimeoutError(stem)
      time.sleep(.25)
      samples.extend(dict(elapsed=time.perf_counter()-start,pid=p.pid,**s) for s in q.sample(p.pid))
     assert p.wait(timeout=5)==0,stem
    finally:q.close(q.handle)
   lines=(out/(stem+'.csv')).read_text().splitlines();i=next(i for i,l in enumerate(lines) if l.startswith('frame,'));rows=[row for row in csv.DictReader(lines[i:]) if row.get('frame','').isdigit()];assert [int(row['frame']) for row in rows]==list(range(180))
   (out/(stem+'.pdh.json')).write_text(json.dumps(samples,indent=2)+'\n')
   records.append(dict(side=side,staged=staged,repeat=repeat,stem=stem,command=command,process_ms=(time.perf_counter()-start)*1000,summary=pdh.summarize(samples)))
   (out/'receipt.json').write_text(json.dumps(dict(protocol='Hidden native WSI; VSync off; matched 60Hz harness cap; own PID only; every sample and physical/LUID engine retained',foreground_certified=False,runs=records),indent=2)+'\n')
   print(stem,flush=True)
