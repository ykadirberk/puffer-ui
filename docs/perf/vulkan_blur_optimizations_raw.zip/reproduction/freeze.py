from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path(__file__).resolve().parents[1];work=Path(__file__).resolve().parent
assert not (work/'baseline.json').exists()
assert not subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).strip()
paths=subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
drafts=subprocess.check_output(['git','ls-files','--others','--exclude-standard','docs'],cwd=root,text=True).splitlines()
hashes={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in paths+drafts if (root/name).is_file()}
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert commit=='309811fcaed86a420651d872ddf2452f6f48aff1'
before=work/'before';before.mkdir()
shutil.copytree(root/'include',before/'include')
for name in ['pui_vulkan_native_spiral_tests','pui_showcase_vulkan','pui_vulkan_gaussian_tests']:
 shutil.copy2(root/f'out/build/x64-release/Release/{name}.exe',before/(name+'.exe'))
refs={}
for upload in ['direct','staged']:
 folder=root/f'build-vulkan-gaussian-fix/spiral-{upload}'
 files=sorted(folder.glob('frame-*.rgba'));assert len(files)==180
 refs[upload]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(work/'baseline.json').write_text(json.dumps(dict(commit=commit,hashes=hashes,drafts=drafts,references=refs),indent=2)+'\n')
print('Frozen 309811f sources/binaries and 360 immutable Spiral frames; protected12 prior reports')
