from pathlib import Path
import csv,gzip,hashlib,json,os,statistics,sys,zipfile
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
b=load(w/'baseline.json');timing=load(w/'timings/receipt.json');gates=load(w/'final-gate-results.json');red=load(w/'red-proofs.json')
assert all(x['returncode']==0 for x in gates)
assert {'suite-release','suite-debug','off','red-proofs','gaussian-goldens','new-file-format','spiral-comparison'}.issubset({x['mode'] for x in gates})
assert [x['returncode'] for x in red]==[0,1,1,0,0]
allowed={'AGENTS.md','CMakeLists.txt','docs/vulkan.md','include/pufferui/pufferui.h','include/pufferui/impl/vulkan_draw.inl'}
for name,value in {**b['hashes'],**b['drafts']}.items():
 if name not in allowed:assert sha(r/name)==value,name
for name,value in timing['source_hashes'].items():assert sha(r/name)==value,name
assert sha(r/'out/build/x64-release/Release/pui_vulkan_native_spiral_tests.exe')==timing['binaries']['after']['sha256']
for mode,items in b['references'].items():
 for name,value in items.items():assert sha(r/f'build-vulkan-gaussian-fix/spiral-{mode}'/name)==value
for name,value in b['css_goldens'].items():assert sha(r/'build-vulkan-blur-opt4/css-goldens'/name)==value
registry={mode:load(r/f'out/build/x64-{mode}/pufferui-vulkan-tests-{mode.capitalize()}.json') for mode in ['release','debug']}
assert all(len(x)==39 for x in registry.values())
rows=list(csv.DictReader((w/'timings/frames.csv').open()));assert len(rows)==4320
summary=timing['summary'];same={}
for mode in ['direct','staged']:
 same[mode]={side:{str(f):statistics.median(float(x['total_ms']) for x in rows if x['mode']==mode and x['side']==side and int(x['frame'])==f) for f in [0,90,120,126,127,128,129,150]} for side in ['before','after']}
peak_ids={0,1,89,90,91,119,120,125,126,127,128,129,130,149,150,151,179}
for run in timing['runs']:
 for f in [run['peak_frame']-1,run['peak_frame'],run['peak_frame']+1]:
  if 0<=f<180:peak_ids.add(f)
dest=r/'docs/perf';stem='vulkan_integer_optimizations'
sys.path.insert(0,str(r/'build-vulkan-blur-opt4/plot_lib'));os.environ['MPLCONFIGDIR']=str(w/'plot-cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axes=plt.subplots(1,2,figsize=(13,4.5),layout='constrained',sharey=True)
for ax,mode in zip(axes,['direct','staged']):
 for side,color in [('before','#99a2ac'),('after','#168777')]:
  for rep in range(6):
   group=[x for x in rows if x['mode']==mode and x['side']==side and int(x['repeat'])==rep]
   ax.plot([int(x['frame']) for x in group],[float(x['total_ms']) for x in group],color=color,alpha=.7,lw=.9,label=side if rep==0 else None)
 for f in [90,120,150]:ax.axvline(f,color='#555',ls='--',lw=.6,alpha=.4)
 ax.set_title(mode.upper());ax.set_xlabel('Frame (Add at 90 / 120 / 150)');ax.set_xlim(0,179);ax.grid(alpha=.18);ax.legend(frameon=False)
axes[0].set_ylim(0,max(float(x['total_ms']) for x in rows)*1.08);axes[0].set_ylabel('Production wall time (ms), every run')
fig.suptitle('Native Spiral 5000 -> 5003 | integer preparation SIMD | every cold/outlier retained')
plot=dest/(stem+'_spiral.png');fig.savefig(plot,dpi=150);plt.close(fig)
frame_file=dest/(stem+'_frames.csv.gz');frame_file.write_bytes(gzip.compress((w/'timings/frames.csv').read_bytes(),mtime=0))
table=[]
for mode in ['direct','staged']:
 a,c=summary[mode]['before'],summary[mode]['after']
 table.append(f'| {mode.upper()} | {a["mean_ms"]:.4f} / {c["mean_ms"]:.4f} | {summary[mode]["paired_wall_percent"]:+.2f}% | {a["p99_ms"]:.4f} / {c["p99_ms"]:.4f} | {a["max_ms"]:.4f} / {c["max_ms"]:.4f} | {a["gpu_ms"]:.4f} / {c["gpu_ms"]:.4f} |')
report=f'''# Native Vulkan: SIMD index validation and exact span planning

Date: 2026-11-02. Source baseline: `{b['commit']}`. Branch:
`{b['branch']}`. Windows execution on AMD Radeon RX 9070 XT;
actual device logs record vendor/device 4098/30032 and driver 8388996.

## Implementation

Full indexed input validation now compares 16 signed indices at a time with
SSE2. The 64-bit upper interval is calculated once and clamped to INT_MAX;
negative values never wrap into a valid range. Unaligned loads and the original
scalar tail preserve every bound check. Complete validation still precedes any
GPU prefix, upload or draw, with the same sticky rejection message.

Large span planning reduces signed min/max in four lanes over 192 indices,
then refines the boundary with the original greedy triangle rule. The initial
oversized sparse triangle rejects before any block lookahead. Original
conservative negative-range behavior, every split tuple and primitive order
remain fixed. The previous native vertex-offset/fallback policy is retained.

SSE2 is compiled only when the target guarantees it. Other targets retain
scalar validation and the previous 24-index block algorithm. The intrinsic
header is confined to the Vulkan implementation section; public declarations
and core/SDL paths remain independent. Private counters exist only in the new
test build. There is no new heap scratch, per-frame CPU-feature query, shader,
floating-point/architecture compiler flag, arena count or upload-budget change.
Shape construction, fonts, HarfBuzz/Slug, motion and Gaussian/Kawase are unchanged.

## Production 5000-item Spiral

The unchanged actual showcase harness runs 180 fixed 1/60s frames at 1360x860,
Spiral, size 64, 5000 -> 5003 tiles, with real keyboard Adds at 90/120/150.
Six alternating before/after pairs per upload mode retain **4,320 timed
frames**. Runs have no readbacks, concurrent builds/tests or other project
windows. Every cold and outlier frame is retained. These are production
executables, separately qualified from the earlier instrumented review probes.
The candidate exactly matches the final standard Release native-Spiral binary.

Mean and p99 are medians of six run statistics. p99 uses sorted index 177 of
180. Worst is the absolute maximum of all six runs. Paired change is the median
matched run-mean percentage, which can differ from the ratio of medians. GPU
is completed submission interval total / 180 logical frames; delayed per-row
GPU samples are not assigned to the current CPU frame. CPU/GPU intervals overlap.

| Upload | Wall before / after ms | Paired wall change | p99 before / after ms | Worst before / after ms | GPU before / after ms |
|---|---:|---:|---:|---:|---:|
{chr(10).join(table)}

Same-index medians preserve the recurring geometry peak:

| Upload | Frame 127 before / after ms | Frame 128 before / after ms |
|---|---:|---:|
| DIRECT | {same['direct']['before']['127']:.4f} / {same['direct']['after']['127']:.4f} | {same['direct']['before']['128']:.4f} / {same['direct']['after']['128']:.4f} |
| STAGED | {same['staged']['before']['127']:.4f} / {same['staged']['after']['127']:.4f} | {same['staged']['before']['128']:.4f} / {same['staged']['after']['128']:.4f} |

Cold medians: DIRECT {summary['direct']['before']['cold_ms']:.4f} -> {summary['direct']['after']['cold_ms']:.4f}ms;
STAGED {summary['staged']['before']['cold_ms']:.4f} -> {summary['staged']['after']['cold_ms']:.4f}ms.
The absolute maximum increases: DIRECT {summary['direct']['before']['max_ms']:.4f} -> {summary['direct']['after']['max_ms']:.4f}ms,
STAGED {summary['staged']['before']['max_ms']:.4f} -> {summary['staged']['after']['max_ms']:.4f}ms.
Both candidate maxima occur at cold frame 0 in repetition 5. The median cold
frame and recurring geometry peaks improve, but this is not a universal
worst-frame improvement. No run or frame is excluded. These uninstrumented
timings do not identify the subphase responsible for the isolated startup
stalls, so they are not attributed to a particular allocator, driver or OS cause.
Completed GPU totals change
{(summary['direct']['after']['gpu_ms']/summary['direct']['before']['gpu_ms']-1)*100:+.2f}% DIRECT /
{(summary['staged']['after']['gpu_ms']/summary['staged']['before']['gpu_ms']-1)*100:+.2f}% STAGED.
These measurements do not certify foreground FPS, per-PID GPU utilization,
physical VRAM peaks or a universal per-frame speedup. All individual results
and maxima remain in the receipt and trace.

Every per-frame upload byte count agrees before/after, including the
72,675,408-byte peak. All timed Vulkan draw-buffer allocation counts are zero.
Peak upload-page capacities remain 68,681,728 bytes DIRECT / 135,790,592 bytes
STAGED; these capacities are not total VRAM. The actual Add still inserts at
a random rank and sends many animated Spiral targets through the visible
center. Its geometry burst remains; no shadows, shapes or animation are dropped.

![Every timed production trace](perf/{stem}_spiral.png)

## Regression and image qualification

- New `pui_vulkan_integer_tests` checks **538,320 validation cases** and
  **418,647 exact split tuples** against frozen scalar oracles. Each matrix
  also checks the explicit portable implementation. Four pointer alignments,
  vector/block boundaries, empty/tail lengths, negative/INT_MIN/INT_MAX bases,
  intervals extending past INT_MAX, dense/sparse/reversed/random/degenerate
  streams, two strides and tiny/large capacities are covered.
- Protected-page tails at 21 lengths detect reads beyond the final input.
  Integer work counters verify use of vector comparisons/reductions instead
  of noisy timing thresholds. Sparse first-triangle rejection performs no
  vector block work.
- Real GPU guards reject invalid values at positions 0/15/16/the final index
  of a 90,000-index draw before any upload, draw or submission. Direct/staged,
  20/32-byte and one/two-slot combinations provide **64 rejection cases**.
  Dense/sparse translucent streams compare exact full pixels against independent
  small reference batches, with no draw-time buffer allocation: **eight pairs**.
  Existing indexed tests retain their separate native-offset/fallback witnesses.
- Isolated green CPU regressions pass. Disabling just SIMD validation or just
  SIMD planning makes the respective bounded-work regression fail as expected.
  A separate build excludes the intrinsic header and all intrinsic code; the
  new CPU/GPU suite passes both upload modes with `SIMD=0`. This checks the
  portable branch on Windows, not an actual ARM/Linux/macOS execution claim.
- Full Release and Debug `python tools/run_tests.py --vulkan --format` gates
  pass, **39 native cases each**, existing core/pump/performance/allocation
  suites, SDL goldens, 1150/5000 Spiral and peak references, all example
  selftests, installed consumers, API/tutorial drift and formatting. The new
  test's portable printf casts and Windows header guard are refreshed and
  rechecked in both configurations after the full gates; production code
  remains the same qualified version. The initial supplementary SDL-OFF build
  exposed Windows min/max macro pollution in this new test; its failed log is
  retained separately. NOMINMAX fixes the test bootstrap without changing any
  test expectation or production code.
- HarfBuzz OFF / SDL OFF passes the base Vulkan test plus the new direct/staged
  regressions. Immutable Gaussian goldens pass in both upload modes: 36 cases,
  1x through 4x DPI, **576 exact frames and 144 idle hits**.
- Frozen Spiral references compare all 180 complete frames in both upload
  modes with candidate cache off/on: **720 candidate RGBA comparisons**, plus
  **360 before-reference identity frames**. Every timed cold/peak frame is
  included. No golden update, image tolerance or reference bytes are changed.
  Full RGBA references for every observed maximum and its neighbours are archived.
- All **{len(b['tests'])} original test/oracle files** and all **{len(b['drafts'])}
  pre-existing unrelated report drafts** retain their initial hashes. Only
  implementation, the new independent regression, test registration and scoped
  documentation/evidence are included in the commit.

## Evidence and reproduction

[Receipt, full run summaries and source hashes](perf/{stem}.json),
[every timed frame](perf/{stem}_frames.csv.gz),
[raw logs, frozen source, regressions and peak RGBA](perf/{stem}_raw.zip).
All 360 immutable direct/staged frame hashes and 36 Gaussian reference hashes
are retained. Complete Spiral references remain under
`build-vulkan-gaussian-fix/spiral-direct` and `spiral-staged`.

```powershell
python tools/compare_vulkan_indexed.py `
  build-vulkan-simd-opt2/before/pui_vulkan_native_spiral_tests.exe `
  out/build/x64-release/Release/pui_vulkan_native_spiral_tests.exe `
  --baseline build-vulkan-simd-opt2/baseline.json `
  --reference build-vulkan-gaussian-fix/spiral-direct `
  --output build-vulkan-integer-repeat --runs 6
```

Use a fresh output directory. The standard native showcase remains directly
runnable as `out/build/x64-release/Release/pui_showcase_vulkan.exe`.
'''
doc=r/'docs/perf_vulkan_integer_optimizations.md';doc.write_text(report,encoding='utf-8')
archive=dest/(stem+'_raw.zip');inventory={}
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 def put(name,data):z.writestr(name,data);inventory[name]=hashlib.sha256(data).hexdigest()
 for p in sorted(w.rglob('*')):
  if not p.is_file() or 'plot-cache' in p.parts or p.suffix not in ['.py','.log','.json','.csv','.cpp','.inl','.h']:continue
  put('validation/'+p.relative_to(w).as_posix(),p.read_bytes())
 for f in sorted(peak_ids):
  name=f'frame-{f:03d}.rgba';put('immutable-Spiral-peak-rgba/'+name,(r/'build-vulkan-gaussian-fix/spiral-direct'/name).read_bytes())
 for p in sorted((r/'build-vulkan-blur-opt4/css-goldens').glob('*.bmp')):put('immutable-css-goldens/'+p.name,p.read_bytes())
 for p in [r/'tests/test_vulkan_integer.cpp',r/'include/pufferui/pufferui.h',r/'include/pufferui/impl/vulkan_draw.inl',r/'tools/compare_vulkan_indexed.py']:
  put('qualified-source/'+p.relative_to(r).as_posix(),p.read_bytes())
receipt=dict(date='2026-11-02',baseline_commit=b['commit'],branch=b['branch'],measurement=timing,same_index_wall_ms=same,gates=gates,
 red_proofs=red,native_cases=registry,original_test_hashes=b['tests'],protected_draft_hashes=b['drafts'],reference_hashes=b['references'],
 css_golden_hashes=b['css_goldens'],archived_peak_frame_ids=sorted(peak_ids),raw_inventory=inventory,
 validation=dict(validation_cpu_cases=538320,split_tuples=418647,gpu_invalid_prefix_cases=64,dense_sparse_pixel_pairs=8,
  candidate_spiral_exact_frames=720,before_spiral_identity_frames=360,css_exact_frames=576,css_idle_hits=144,
  existing_test_bodies_changed=False,golden_update_used=False,foreground_certified=False),
 artifacts={p.relative_to(r).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p)) for p in [doc,frame_file,archive,plot]})
(dest/(stem+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 for name,value in inventory.items():assert hashlib.sha256(z.read(name)).hexdigest()==value,name
print(json.dumps(dict(summary=summary,all_timed_frames=4320,protected_tests=len(b['tests']),protected_drafts=len(b['drafts']),archive_bytes=archive.stat().st_size),indent=2))
