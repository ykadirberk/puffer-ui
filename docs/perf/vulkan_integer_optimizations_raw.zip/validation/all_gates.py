from pathlib import Path
import json,subprocess,sys,time
w=Path(__file__).resolve().parent;r=w.parent;results=[]
for mode in ['suite-release','suite-debug','off','gaussian-goldens','red-proofs']:
 print('Starting '+mode,flush=True);start=time.perf_counter()
 command=[sys.executable,str(w/'red_proofs.py')] if mode=='red-proofs' else [sys.executable,str(w/'driver.py'),mode]
 run=subprocess.run(command,cwd=r)
 results.append(dict(mode=mode,returncode=run.returncode,seconds=time.perf_counter()-start))
 (w/'gate-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(mode+' exit '+str(run.returncode),flush=True)
 if run.returncode:raise SystemExit(run.returncode)
