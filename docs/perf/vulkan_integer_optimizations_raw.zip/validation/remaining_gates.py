from pathlib import Path
import json,shutil,subprocess,sys,time
w=Path(__file__).resolve().parent;r=w.parent
old=json.loads((w/'gate-results.json').read_text())
shutil.copy2(w/'gate-results.json',w/'initial-gate-results.json')
shutil.copy2(w/'off.log',w/'off-initial.log')
results=[x for x in old if x['returncode']==0]
for mode in ['off','gaussian-goldens','red-proofs']:
 print('Starting '+mode,flush=True);start=time.perf_counter()
 command=[sys.executable,str(w/'red_proofs.py')] if mode=='red-proofs' else [sys.executable,str(w/'driver.py'),mode]
 run=subprocess.run(command,cwd=r)
 results.append(dict(mode=mode,returncode=run.returncode,seconds=time.perf_counter()-start))
 (w/'gate-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(mode+' exit '+str(run.returncode),flush=True)
 if run.returncode:raise SystemExit(run.returncode)
