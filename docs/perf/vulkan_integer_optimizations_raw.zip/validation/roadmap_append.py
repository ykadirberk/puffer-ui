from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent
p=Path(r'C:\Users\Kadir Berk\.opencode\plan\pufferui-roadmap.md')
before=p.read_bytes();commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
receipt=json.loads((r/'docs/perf/vulkan_integer_optimizations.json').read_text());s=receipt['measurement']['summary']
assert commit!=receipt['baseline_commit']
text=f'''

## 2026-11-02 - Native SIMD integer geometry preparation

- [x] Vectorize complete signed index validation and dense span min/max with
  target-guaranteed SSE2; retain portable scalar algorithms, exact split tuples,
  pre-prefix rejection, sparse fallback and original shader/vertex arithmetic.
  No heap scratch, new arena, upload-budget or global compiler-flag changes.
- [x] Add independent 538,320 validation cases / 418,647 split tuples, protected
  tails and work counters; 64 actual pre-prefix GPU rejections and eight exact
  dense/sparse pixel pairs cover direct/staged, 20/32-byte and one/two slots.
  Two isolated performance regressions fail as expected; intrinsic-free CPU/GPU
  direct/staged and HarfBuzz-OFF/SDL-OFF configurations pass.
- [x] Full Release/Debug --vulkan --format gates pass, 39 native cases each,
  original goldens/Spiral/peaks, all example selftests and installed consumers.
  Preserve 84 original test/oracle files and 22 unrelated report drafts.
- [x] Retain six alternating pairs per mode / 4,320 timed frames with every
  cold/outlier. Paired mean changes: {s['direct']['paired_wall_percent']:+.2f}% DIRECT /
  {s['staged']['paired_wall_percent']:+.2f}% STAGED. p99: {s['direct']['before']['p99_ms']:.4f} -> {s['direct']['after']['p99_ms']:.4f}ms /
  {s['staged']['before']['p99_ms']:.4f} -> {s['staged']['after']['p99_ms']:.4f}ms. All per-frame upload bytes and budgets remain fixed.
  Absolute maxima rise to {s['direct']['after']['max_ms']:.4f}/{s['staged']['after']['max_ms']:.4f}ms at cold frame 0;
  retain these outliers and do not claim a universal worst-frame improvement.
- [x] Verify all 180 immutable Spiral frames: 720 candidate exact RGBA
  comparisons plus 360 before identity frames; 576 immutable Gaussian frames
  and 144 idle hits also pass. Preserve all original capture hashes and peaks.
- [x] Evidence: docs/perf_vulkan_integer_optimizations.md and its JSON/full
  frame CSV/raw validation bundle/all-run graph in docs/perf/.
- [x] Published revision: {commit}.
  perf(vulkan): vectorize indexed validation and span planning.
  Pushed to origin/codex/vulkan-native-harfbuzz; main remains unchanged.
'''
assert commit.encode() not in before
addition=text.replace('\n','\r\n').encode()
with p.open('ab') as f:f.write(addition)
after=p.read_bytes();assert after==before+addition
(w/'roadmap-update.json').write_text(json.dumps(dict(path=str(p),commit=commit,before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(after).hexdigest(),original_prefix_preserved=True),indent=2)+'\n')
print('Roadmap appended for',commit,'with all original bytes preserved')
