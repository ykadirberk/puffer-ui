from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
names=subprocess.check_output(['git','ls-files','-z'],cwd=r).decode().split('\0')
status=subprocess.check_output(['git','status','--porcelain','-z'],cwd=r).decode().split('\0')
assert all(not s or s.startswith('?? ') for s in status)
hashes={n:sha(r/n) for n in names if n and (r/n).is_file()}
drafts={s[3:]:sha(r/s[3:]) for s in status if s.startswith('?? ') and (r/s[3:]).is_file()}
before=w/'before';before.mkdir(exist_ok=False)
exe=r/'out/build/x64-release/Release/pui_vulkan_native_spiral_tests.exe'
shutil.copy2(exe,before/exe.name)
shutil.copy2(r/'include/pufferui/impl/vulkan_draw.inl',before/'vulkan_draw.inl')
refs=json.loads((r/'build-vulkan-indexed-opt2/baseline.json').read_text())['references']
for mode,items in refs.items():
 for name,value in items.items():assert sha(r/f'build-vulkan-gaussian-fix/spiral-{mode}'/name)==value
css={p.name:sha(p) for p in (r/'build-vulkan-blur-opt4/css-goldens').glob('*.bmp')};assert len(css)==36
result=dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),
 branch=subprocess.check_output(['git','branch','--show-current'],cwd=r,text=True).strip(),hashes=hashes,
 tests={n:v for n,v in hashes.items() if n.startswith('tests/')},drafts=drafts,references=refs,css_goldens=css,
 binary=dict(path=str(before/exe.name),sha256=sha(before/exe.name)))
(w/'baseline.json').write_text(json.dumps(result,indent=2)+'\n')
print('Frozen',result['commit'],len(result['tests']),'test/oracle files,',len(drafts),'drafts and all immutable references')
