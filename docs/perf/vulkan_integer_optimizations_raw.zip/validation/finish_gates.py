from pathlib import Path
import json,subprocess,sys,time
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent
results=json.loads((w/'gate-results.json').read_text());assert all(x['returncode']==0 for x in results)
start=time.perf_counter()
# Refresh the new regression after its portable printf argument casts.
subprocess.run([sys.executable,str(w/'driver.py'),'targeted'],cwd=r,check=True)
results.append(dict(mode='final-new-regressions',returncode=0,seconds=time.perf_counter()-start))
start=time.perf_counter()
subprocess.run([sys.executable,str(w/'driver.py'),'new-debug-regression'],cwd=r,check=True)
results.append(dict(mode='final-new-debug-regressions',returncode=0,seconds=time.perf_counter()-start))
start=time.perf_counter()
formatter=r/'build-perf-review/format-tool/clang_format/data/bin/clang-format.exe'
with (w/'new-file-format.log').open('w') as log:
 subprocess.run([str(formatter),'--dry-run','--Werror',str(r/'tests/test_vulkan_integer.cpp')],cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
results.append(dict(mode='new-file-format',returncode=0,seconds=time.perf_counter()-start))
start=time.perf_counter()
check=subprocess.run(['powershell','-NoProfile','-Command',"Get-Process -Name 'pui*','cl','ninja' -ErrorAction SilentlyContinue | Select-Object ProcessName,Id,Path"],cwd=r,capture_output=True,text=True)
(w/'project-process-check.log').write_text(check.stdout+check.stderr)
assert not check.stdout.strip(),check.stdout
with (w/'spiral-comparison.log').open('w') as log:
 cmd=[sys.executable,'tools/compare_vulkan_indexed.py',str(w/'before/pui_vulkan_native_spiral_tests.exe'),
 str(r/'out/build/x64-release/Release/pui_vulkan_native_spiral_tests.exe'),'--baseline',str(w/'baseline.json'),
 '--reference',str(r/'build-vulkan-gaussian-fix/spiral-direct'),'--output',str(w/'timings'),'--runs','6']
 log.write(repr(cmd)+'\n');log.flush();subprocess.run(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
results.append(dict(mode='spiral-comparison',returncode=0,seconds=time.perf_counter()-start))
(w/'final-gate-results.json').write_text(json.dumps(results,indent=2)+'\n')
print('Final regressions, formatting and all-frame production measurements passed',flush=True)
