from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((w/'baseline.json').read_text());receipt=json.loads((r/'docs/perf/vulkan_integer_optimizations.json').read_text())
paths=['AGENTS.md','CMakeLists.txt','docs/vulkan.md','include/pufferui/pufferui.h','include/pufferui/impl/vulkan_draw.inl',
 'tests/test_vulkan_integer.cpp','docs/perf_vulkan_integer_optimizations.md','docs/perf/vulkan_integer_optimizations.json',
 'docs/perf/vulkan_integer_optimizations_frames.csv.gz','docs/perf/vulkan_integer_optimizations_raw.zip','docs/perf/vulkan_integer_optimizations_spiral.png']
for group in ['tests','drafts']:
 for name,value in b[group].items():assert sha(r/name)==value,name
for name,value in receipt['measurement']['source_hashes'].items():assert sha(r/name)==value,name
for name,value in receipt['artifacts'].items():assert sha(r/name)==value['sha256'],name
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=r)
subprocess.run(['git','diff','--check'],cwd=r,check=True)
status={s[3:] for s in subprocess.check_output(['git','status','--porcelain','-z'],cwd=r).decode().split('\0') if s}
assert status==set(paths)|set(b['drafts']),(status-set(paths)-set(b['drafts']))
subprocess.run(['git','add','--',*paths],cwd=r,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=r).decode().strip('\0').split('\0'))==set(paths)
subprocess.run(['git','diff','--cached','--check'],cwd=r,check=True)
(w/'staged-paths.json').write_text(json.dumps(paths,indent=2)+'\n')
message='''perf(vulkan): vectorize indexed validation and span planning

Use target-guaranteed SSE2 for complete signed index validation and dense
span reductions, retaining scalar fallback and exact greedy split boundaries.
Keep shaders, geometry, draw order, upload budgets and image output unchanged.

Add scalar-oracle, guarded-tail, bounded-work and native GPU regressions.
Validate unchanged Debug/Release suites and every 5000-item Spiral frame;
retain alternating production timings, cold frames and all outliers.
'''
(w/'commit-message.txt').write_text(message,encoding='utf-8')
print('Staged exactly',len(paths),'scoped files; all',len(b['drafts']),'existing report drafts remain untouched')
