from pathlib import Path
import json,subprocess,sys
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'tools'));from run_tests import import_msvc_env
import_msvc_env();results=[]
for name in ['green','validation-scalar','planner-scalar','portable']:
 import shutil
 out=w/('proof-'+name);out.mkdir(exist_ok=False);shutil.copytree(r/'include',out/'include')
 path=out/'include/pufferui/impl/vulkan_draw.inl';b=path.read_bytes()
 if name in ['validation-scalar','planner-scalar']:
  needle=b'if constexpr (Simd)';assert b.count(needle)==2
  index=b.index(needle) if name=='validation-scalar' else b.rindex(needle)
  b=b[:index]+b[index:].replace(needle,b'if constexpr (false)',1);path.write_bytes(b)
 elif name=='portable':
  path=out/'include/pufferui/pufferui.h';b=path.read_bytes();a=b.index(b'#if defined(__SSE2__)');end=b.index(b'#include <emmintrin.h>',a)
  path.write_bytes(b[:a]+b'#if 0\r\n'+b[end:])
 exe=out/'integer.exe'
 cmd=['cl','/nologo','/std:c++20','/EHsc','/O2','/MD','/DNDEBUG','/DPUFFERUI_ENABLE_VULKAN','/DPUFFERUI_VULKAN_INTEGER_TESTS',
  '/I'+str(out/'include'),'/I'+str(r/'vendored/stb'),'/IE:/VulkanSDK/1.4.335.0/Include',str(r/'tests/test_vulkan_integer.cpp'),
  '/Fo'+str(out/'integer.obj'),'/Fe'+str(exe),'/link','E:/VulkanSDK/1.4.335.0/Lib/vulkan-1.lib','user32.lib']
 with (out/'build.log').open('w') as log:
  log.write(repr(cmd)+'\n');log.flush();subprocess.run(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
 cases=[['--cpu']] if name!='portable' else [[],['--staged']]
 for number,args in enumerate(cases):
  with (out/f'test-{number}.log').open('w') as log:run=subprocess.run([str(exe),*args],cwd=r,stdout=log,stderr=subprocess.STDOUT)
  text=(out/f'test-{number}.log').read_text();expected=1 if name.endswith('-scalar') else 0
  assert run.returncode==expected,(name,run.returncode,text)
  if name=='validation-scalar':assert 'validation_vectors' in text,text
  if name=='planner-scalar':assert 'planning_vectors' in text,text
  if name=='portable':assert 'SIMD=0' in text,text
  results.append(dict(variant=name,arguments=args,returncode=run.returncode,expected_failure=bool(expected),diagnostic=text.strip()))
  print(name,args,run.returncode,flush=True)
(w/'red-proofs.json').write_text(json.dumps(results,indent=2)+'\n')
