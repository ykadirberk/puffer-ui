"""Seal the completed, source-identical full-suite and measurement evidence."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SUITE = ROOT / "build-vulkan-integrated/final-gate/full-20261028-090244-7520"
RECEIPT = ROOT / "docs/perf/vulkan_compute_default_final.json"
ARCHIVE = ROOT / "docs/perf/vulkan_compute_default_raw.zip"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


receipt = json.loads(RECEIPT.read_text())
assert not receipt["complete"], "Already sealed; do not append duplicate archive members"
suite = json.loads((SUITE / "validation.json").read_text())
assert suite["complete"] and not suite["changed_sources"]
assert suite["source_before"] == suite["source_after"]
assert suite["source_before"] == receipt["qualification"]["source_before"]
assert len(suite["source_before"]) == 336
assert all(sha(ROOT / p) == digest for p, digest in suite["source_after"].items())
assert [run["mode"] for run in suite["runs"]] == ["release", "debug"]
for run in suite["runs"]:
    assert run["exit"] == 0
    log_path = SUITE / (run["mode"] + ".log")
    log = log_path.read_text(encoding="utf8", errors="replace")
    assert "all steps passed" in log
    assert not re.search(r"^skip\s+", log, re.MULTILINE | re.IGNORECASE)
    run["native_case_count"] = len(re.findall(r"^==== Vulkan ", log, re.MULTILINE))
    assert run["native_case_count"] == 100
    assert len(re.findall(r"compute default: 180 exact 5000-Spiral frames", log)) == 4
    run["log_sha256"] = sha(log_path)

preserved = json.loads((ROOT / "build-vulkan-integrated/final-gate/preserved-unrelated.json").read_text())
assert len(preserved) == 9
assert all(sha(ROOT / p) == digest for p, digest in preserved.items())
for p, digest in receipt["artifacts"].items():
    assert sha(ROOT / p) == digest

with zipfile.ZipFile(ARCHIVE, "a", zipfile.ZIP_DEFLATED) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist()))
    for name in ("release.log", "debug.log", "validation.json"):
        archive.write(SUITE / name, "full-suite/" + name)
    archive.write(Path(__file__), "finalize.py")
    assert len(archive.namelist()) == len(set(archive.namelist()))
with zipfile.ZipFile(ARCHIVE) as archive:
    assert archive.testzip() is None

receipt["complete"] = True
receipt["suite"] = {
    "path": SUITE.relative_to(ROOT).as_posix(),
    "pending": False,
    "complete": True,
    "source_count": 336,
    "unchanged_sources": True,
    "validation_sha256": sha(SUITE / "validation.json"),
    "runs": suite["runs"],
}
receipt["preserved_unrelated"] = preserved
receipt["limitations"].append(
    "Frame timings exclude device/surface creation, prepared kernels and initial font loading; "
    "they are not cold executable launch timings."
)
receipt["limitations"].append(
    "Qualified deterministic cohorts disable the HUD. The normal changing FPS HUD can "
    "affect whole-program reuse; these are not normal foreground FPS certifications."
)
receipt["artifacts"][ARCHIVE.relative_to(ROOT).as_posix()] = sha(ARCHIVE)
assert all("\\" not in p for p in receipt["artifacts"])
assert all(sha(ROOT / p) == digest for p, digest in receipt["artifacts"].items())
RECEIPT.write_text(json.dumps(receipt, indent=2) + "\n")

report = ROOT / "docs/perf_vulkan_compute_default.md"
body = report.read_text(encoding="utf8")
body = body.replace(
    "Durum: uygulama ve odaklı testler tamam; tam kabul kapısı bekleniyor.",
    "Durum: tam Release/Debug kabul kapıları ve görüntü/ölçüm doğrulaması tamam.",
)
body = body.replace(
    "Tam Release/Debug `--vulkan --format` kapıları çalışıyor; sonuç bekleniyor.",
    "Tam Release ve Debug `--vulkan --format` kapıları geçti: her yapılandırmada\n"
    "100 native Vulkan vakası, dört yeni compute-default vakası, mevcut core/pump/\n"
    "performans testleri, 22 SDL golden sahnesi, 1150/5000 Spiral ve tepe kareleri,\n"
    "iki 3600-kare/60-Add çifti, bütün örnekler, installed core/SDL/Vulkan tüketicileri,\n"
    "format/API/tutorial kontrolleri. Atlanan adım yoktur. Yeni varsayılanın test\n"
    "çıktıları moving direct/staged için active=180, idle için active=14 ve\n"
    "cache_hits=166 değerlerini tekrar doğrular. Her iki kapı boyunca 336 kaynak\n"
    "dosyasının hash'leri, ölçümdeki kaynaklarla aynı ve değişmez kaldı.\n"
    "Dokuz ilgisiz taslağın hash'leri de başlangıçla aynıdır; SDL submodule temizdir.\n"
    f"Kapı süreleri: Release {suite['runs'][0]['seconds']:.1f} s, "
    f"Debug {suite['runs'][1]['seconds']:.1f} s.",
)
assert "sonuç bekleniyor" not in body and "tam kabul kapısı bekleniyor" not in body
report.write_text(body, encoding="utf8")
print(json.dumps({"complete": True, "sources": 336, "native_cases": [100, 100],
                  "preserved_drafts": 9, "archive_sha256": sha(ARCHIVE)}, indent=2))
