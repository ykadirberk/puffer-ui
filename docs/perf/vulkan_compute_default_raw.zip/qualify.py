"""Default-policy before/after timing followed by separate frozen pixel proof."""
from pathlib import Path
import csv,hashlib,json,shutil,subprocess,sys,time,zipfile
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from compare_vulkan_locality import workload_flags
from compare_vulkan_integrated import validate_counts
OUT=ROOT/'build-vulkan-compute-default'/('final-'+time.strftime('%Y%m%d-%H%M%S'))
OUT.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard','--',
 'include','src','tests','examples','tools','cmake','CMakeLists.txt','CMakePresets.json','README.md'],cwd=ROOT).decode().split('\0')
paths=sorted(set(paths)-{''})
def hashes():return {p:sha(ROOT/p) for p in paths}
receipt=dict(complete=False,source_before=hashes(),baseline_commit='1b0c6f25a6e8d51733db16177ecc37798de3dacb',
 before_policy='INTEGRATED native observation',after_policy='INTEGRATED compute SDF/Slug; native_observation=false',
 pixel_cases=[],captures={},peak_neighbors={})
with zipfile.ZipFile(OUT/'candidate-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for path in paths:z.write(ROOT/path,path)
for side,path in [('before',ROOT/'build-vulkan-compute-default/baseline/program.exe'),
                  ('after',ROOT/'out/build/x64-release/Release/pui_vulkan_program_bench.exe')]:shutil.copy2(path,OUT/(side+'.exe'))
receipt['binaries']={side:sha(OUT/(side+'.exe')) for side in ('before','after')}
receipt['source_archive_sha256']=sha(OUT/'candidate-source.zip')
def save():(OUT/'validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
save();print('Qualification:',OUT,flush=True)
command=[sys.executable,'tools/compare_vulkan_locality.py',str(OUT/'before.exe'),str(OUT/'after.exe'),
 '--runs','4','--output',str(OUT/'timing')]
with (OUT/'timing-driver.log').open('w') as log:subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
receipt['timing_command']=command;save()
measurement=json.loads((OUT/'timing/measurement.json').read_text())
old=json.loads((ROOT/'docs/perf/vulkan_compute_locality_final.json').read_text())['full_byte_validation']
old_root=ROOT/'build-vulkan-locality/final-20261027-234723/pixels'
for upload in ('direct','staged'):
 for mode in ('moving','idle','local'):
  label=upload+'-'+mode;golden=old_root/label/'rgba';expected=old['pixels']['captures'][label]
  actual={p.name:sha(p) for p in sorted(golden.glob('*.rgba'))};assert actual==expected
  receipt['captures'][label]=actual
  for case,side,painter in [('baseline','before','production'),('compute-default','after','production'),('fine-control','after','fine')]:
   stem=OUT/(label+'-'+case);flags=workload_flags(painter,mode,upload)
   command=[str(OUT/(side+'.exe')),*flags,'--reference',str(golden)]
   print('Pixels',label,case,flush=True)
   with stem.with_suffix('.csv').open('w') as f,stem.with_suffix('.log').open('w') as log:
    result=subprocess.run(command,cwd=ROOT,stdout=f,stderr=log,timeout=300)
   if result.returncode:raise RuntimeError(str(stem))
   with stem.with_suffix('.csv').open() as f:rows=list(csv.DictReader(f))
   validate_counts(rows,mode)
   assert len(rows)==180 and all(int(row['frame'])==i for i,row in enumerate(rows))
   receipt['pixel_cases'].append(dict(label=label,case=case,frames=180,command=command,exit=0));save()
  assert actual=={p.name:sha(p) for p in sorted(golden.glob('*.rgba'))}
  peaks=set()
  for run in measurement['runs']:
   if run['upload']==upload and run['mode']==mode:
    for peak in run['peak_frames']:peaks.update(f for f in (peak-1,peak,peak+1) if 0<=f<180)
  receipt['peak_neighbors'][label]=sorted(peaks);save()
receipt.update(source_after=hashes(),exact_comparisons=3240,complete=True)
assert receipt['source_before']==receipt['source_after']
save();print('Qualification complete:',OUT,flush=True)
