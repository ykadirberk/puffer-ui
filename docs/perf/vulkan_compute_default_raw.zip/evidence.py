from pathlib import Path
import csv,gzip,hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'build-vulkan-compute-default/final-20261028-085822'
SUITE=ROOT/'build-vulkan-integrated/final-gate/full-20261028-090244-7520'
DEST=ROOT/'docs/perf'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
receipt=dict(complete=False,qualification=json.loads((BASE/'validation.json').read_text()),
 measurement=json.loads((BASE/'timing/measurement.json').read_text()),
 runtime=json.loads((ROOT/'build-vulkan-compute-default/runtime-proof/receipt.json').read_text()),
 suite=dict(path=SUITE.relative_to(ROOT).as_posix(),pending=True),
 limitations=['Hidden/unfocused WSI timing is not foreground FPS certification.',
 'Compute-first is the requested architecture; the old native-first policy can be faster and use less memory.',
 'GPU completion samples are delayed submission totals, not attribution to the current CPU frame.',
 'Native exact pixel replay and RGBA8 alpha scratch remain; a pixel-local alpha accumulator is not implemented.'])
frames=DEST/'vulkan_compute_default_frames.csv.gz'
shutil.copy2(BASE/'timing/frames.csv.gz',frames)
with gzip.open(frames,'rt') as f:rows=list(csv.DictReader(f))
receipt['timed_invariants']={field:sum(int(row[field]) for row in rows)
 for field in ('draw_memory_allocations','draw_resource_creations','readbacks')}
assert not any(receipt['timed_invariants'].values())
archive=DEST/'vulkan_compute_default_raw.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for folder in (BASE/'timing',BASE,ROOT/'build-vulkan-compute-default/runtime-proof'):
  for p in sorted(folder.iterdir()):
   if p.suffix in ('.csv','.log','.json'):z.write(p,p.relative_to(ROOT/'build-vulkan-compute-default').as_posix())
 for name in ('qualify.py','evidence.py','stage1-build.log','stage2-build.log','stage1-focused.log'):
  p=ROOT/'build-vulkan-compute-default'/name;z.write(p,name)
receipt['artifacts']={p.relative_to(ROOT).as_posix():sha(p) for p in (frames,archive)}
(DEST/'vulkan_compute_default_final.json').write_text(json.dumps(receipt,indent=2)+'\n')
report=ROOT/'docs/perf_vulkan_compute_default.md'
body=report.read_text(encoding='utf8');body=body[:body.index('## Son kabul\n')]
body+='''## Önce/sonra ölçümü

AMD Radeon RX 9070 XT / driver 8389024; Release MSVC/LTCG, 1360×860,
5000 başlangıç öğesi/64 boyut Spiral. Her kohortta dört dönüşümlü çift ve
180 kare; moving'de 90/120/150'de gerçek Add, idle/local'de sayı 5000.
Toplam 17.280 zamanlanmış kare saklandı. Readback, profiler ve eşzamanlı
build/test yok; VSync kapalı ve WSI pencereleri gizlidir. GPU sütunu, aralıkta
tamamlanan submission sürelerinin kare sayısına bölümüdür.

`production` iki revision'ın gerçek farklı varsayılanlarını karşılaştırır:
önce native-first, sonra compute-first. CLI bayrakları aynıdır; politika farkı
bilinçlidir. `fine` kontrolünde her iki tarafta da whole-program cache kapalıdır.
Bu tablo hızlanma iddiası değildir; kullanıcı tarafından istenen seçimin maliyeti
de korunur. Süreler ms; bütün başlangıç ve aykırı kareler hesaplara dahildir.

| Yol/upload/sahne | Ortalama önce → sonra | GPU toplam/kare | p99 önce → sonra | Maks. önce → sonra |
| --- | ---: | ---: | ---: | ---: |
'''
cohorts=receipt['measurement']['cohorts']
for i in range(0,len(cohorts),2):
 b,a=cohorts[i:i+2]
 body+=f"| {b['painter']}/{b['upload']}/{b['mode']} | {b['mean_ms']:.4f} → {a['mean_ms']:.4f} | {b['gpu_ms_per_frame']:.4f} → {a['gpu_ms_per_frame']:.4f} | {b['p99_ms']:.2f} → {a['p99_ms']:.2f} | {b['max_ms']:.2f} → {a['max_ms']:.2f} |\n"
body+='''
Native-first bu sahnede daha hızlıdır. Compute-first'in maliyetini azaltmak için
varsayılan sessizce native'e geri çevrilmedi. Whole-program cache açık yeni
varsayılanın idle GPU işi, sürekli fine boyamadan belirgin düşüktür.
Source/binary kimlikleri, process/thread CPU/cycle ve bütün ham kareler JSON'dadır.

## Frozen görüntüler ve tepe kareler

Önceki doğrulanmış 1080 frozen RGBA dosyası tekrar kullanılmadan önce ve sonra
SHA-256 ile denetlendi; üzerlerine yazılmadı. Baseline native-first, yeni default
ve yeni fine kontrolü direct/staged × moving/idle/local için bu dosyalara karşı
3×1080 = **3240 tam-byte karşılaştırma** yaptı: bütün kareler eşit. Zamanlama
serilerindeki bütün top-10 tepe ve ±1 komşusu bu kapsamda; indeksleri JSON'da
saklıdır. Native SDF bağımsız oraklı ayrıca yeni 180-kare default testinde vardır.
Ortak opacity/Slug/blur ve opacity değişiklikleri de cache açık/kapalı 32 tam
RGBA kareyle karşılaştırılır; draw tahsis ve validation sayaçları sıfırdır.

## Son kabul

Tam Release/Debug `--vulkan --format` kapıları çalışıyor; sonuç bekleniyor.
[Makine kaydı](perf/vulkan_compute_default_final.json),
[bütün zamanlanmış kareler](perf/vulkan_compute_default_frames.csv.gz),
[ham CSV/log ve harness'ler](perf/vulkan_compute_default_raw.zip).
Yerel immutable kaynak/binary arşivi `build-vulkan-compute-default/` altındadır.
İlgisiz dokuz rapor taslağı bu değişikliğe dahil değildir.
'''
report.write_text(body,encoding='utf8')
print('Compute-default evidence assembled; full suite pending')
