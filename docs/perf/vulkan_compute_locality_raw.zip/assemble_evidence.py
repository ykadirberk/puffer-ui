from pathlib import Path
import csv,gzip,hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'build-vulkan-locality/final-20261027-234723'
DEST=ROOT/'docs/perf'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
measurement=json.loads((BASE/'timing/measurement.json').read_text())
controls=json.loads((BASE/'controls/measurement.json').read_text())
validation=json.loads((BASE/'validation.json').read_text())
profile=json.loads((ROOT/'build-vulkan-locality/accepted-profile-summary.json').read_text())
for source,name in [(BASE/'timing/frames.csv.gz','vulkan_compute_locality_frames.csv.gz'),
                    (BASE/'controls/frames.csv.gz','vulkan_compute_locality_controls.csv.gz')]:
 shutil.copy2(source,DEST/name)
archive=DEST/'vulkan_compute_locality_raw.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for folder in [BASE/'timing',BASE/'controls',ROOT/'build-vulkan-locality/stage2/measure',ROOT/'build-vulkan-locality/stage3/pruning-measure']:
  for p in sorted(folder.iterdir()):
   if p.suffix in ('.csv','.log','.json'):z.write(p,str(p.relative_to(ROOT/'build-vulkan-locality')))
 for folder in ['baseline/heap-production-v2/integrated','baseline/heap-tiles','baseline/heap-tiles_staged','baseline/heap-production_staged',
                'accepted-heap/integrated','accepted-heap/tiles','accepted-heap/tiles_staged','accepted-heap/production_staged',
                'baseline/gpu-functions/integrated_tiles','accepted-gpu/integrated_tiles']:
  for p in sorted((ROOT/'build-vulkan-locality'/folder).iterdir()):
   if p.suffix in ('.csv','.log','.json'):z.write(p,str(p.relative_to(ROOT/'build-vulkan-locality')))
 for p in [Path(__file__),ROOT/'build-vulkan-locality/final_validation.py',ROOT/'build-vulkan-locality/secondary_controls.py',ROOT/'build-vulkan-locality/accepted-focused.log']:
  z.write(p,str(p.relative_to(ROOT/'build-vulkan-locality')))
receipt=dict(complete=False,baseline_commit=validation['baseline_commit'],normal_measurement=measurement,
 controls=controls,full_byte_validation=validation,diagnostics=profile,
 suite=dict(path='build-vulkan-integrated/final-gate/full-20261027-235509-27736',pending=True),
 limitations=['Hidden/unfocused WSI: no foreground FPS certification.',
 'Completed GPU submissions are delayed; sample counts and raw timestamps remain available, not per-frame GPU attribution.',
 'Module C/C++ heap capture excludes DLL/driver heap, aligned C heap, pre-main, frees and live residency.',
 'Production has increased means/p99/max in some cohorts. Identical-binary controls also differ; no universal speedup claim.',
 'Alpha uses prepared native scratch; forward per-operation RGBA8 quantization is retained.'],
 artifacts={str(p.relative_to(ROOT)):sha(p) for p in [archive,DEST/'vulkan_compute_locality_frames.csv.gz',DEST/'vulkan_compute_locality_controls.csv.gz']},
 local_artifact_root=str(BASE.relative_to(ROOT)))
(DEST/'vulkan_compute_locality_final.json').write_text(json.dumps(receipt,indent=2)+'\n')
report=ROOT/'docs/perf_vulkan_compute_locality.md'
body=report.read_text(encoding='utf-8')
marker='## Son doğrulama\n'
body=body[:body.index(marker)]
body+='''## Son olağan executable ölçümü

AMD Radeon RX 9070 XT, driver `8389024`; Release MSVC/LTCG; 1360×860,
başlangıç 5000 öğe/64 boyut Spiral; 180 kare, hareketlide 90/120/150'de gerçek
Add, sabit ve yerel-değişimde sayı 5000. Her kohortta altı dönüşümlü önce/sonra
çift. Zamanlamada readback, profiler, eşzamanlı build/test yok. Pencereler gizli
ve odaksızdır; kullanıcıdaki foreground FPS olayının çözüldüğü iddia edilmez.

`production` whole-program/native observation; `fine` aynı INTEGRATED'in
yalnız whole-program cache'i kapatılmış halidir. İki tarafta aynı bayraklar
kullanılır. 25.920 karenin hiçbiri, açılış veya aykırı olduğu için çıkarılmadı.
GPU sütunu, CSV aralığında tamamlanan submission süreleri toplamının kare
sayısına bölümüdür; aynı CPU karesine ait GPU süresi anlamına gelmez. Her fine
kohortunda 1080 GPU örneği, production'da 1080–1083 örnek tutuldu.

| Yol/upload/sahne | Kare ort. önce → sonra ms | GPU toplam/kare ms | p99 önce → sonra ms | Maks. önce → sonra ms |
| --- | ---: | ---: | ---: | ---: |
'''
for i in range(0,len(measurement['cohorts']),2):
 b,a=measurement['cohorts'][i:i+2]
 body+=f"| {b['painter']}/{b['upload']}/{b['mode']} | {b['mean_ms']:.4f} → {a['mean_ms']:.4f} | {b['gpu_ms_per_frame']:.4f} → {a['gpu_ms_per_frame']:.4f} | {b['p99_ms']:.2f} → {a['p99_ms']:.2f} | {b['max_ms']:.2f} → {a['max_ms']:.2f} |\n"
body+='''
Fine ortalama kare süresi altı kohortta azalır; GPU toplam/kare düşüşü yaklaşık
%21–38 aralığındadır. Main-thread cycle altı fine kohortta %8,6–13,8 azalır.
Fine staged idle p99 ve bazı tekil en kötü kareler yükselir; tablo bunları korur.
Production direct moving ve staged idle ortalamaları yükselir. Aynı adayın
ilk ve son serideki `.text` SHA-256 değeri aynı olduğu halde zamanlar ayrışır:
`a003e467cf96ff0fbc3011bf3a32eac6049ab2d7131dc80299568c943ebf1453`.
Bu gözlem tek başına artışların nedenini kanıtlamaz.

Bu nedenle 8640 karelik iki ek kontrol tutuldu:

| Kontrol/kohort | Ortalama önce → sonra ms | p99 ms | Maks. ms | Main-thread cycle değişimi |
| --- | ---: | ---: | ---: | ---: |
'''
for i in range(0,len(controls['cohorts']),2):
 b,a=controls['cohorts'][i:i+2]
 change=(a['frame_window_main_cycles']/b['frame_window_main_cycles']-1)*100
 body+=f"| {b['control']}/{b['upload']}/{b['mode']} | {b['mean_ms']:.4f} → {a['mean_ms']:.4f} | {b['p99_ms']:.2f} → {a['p99_ms']:.2f} | {b['max_ms']:.2f} → {a['max_ms']:.2f} | {change:+.2f}% |\n"
body+='''
`identical_binary` iki tarafta aynı executable/komut kullanır; yaklaşık %6
ortalama ayrışması bu ortamın gürültüsünü gösterir. `paced`, bu iki kohortta
gerçek önce/sonrayı 60 Hz'de karşılaştırır: ortalama ve main-thread cycle azalır,
staged idle p99 artar. Bunlardan bütün üretim sahnelerinde hızlanma veya bütün
spike'ların giderildiği sonucu çıkarılmaz. Diğer uygulamalara müdahale edilmedi.

## Görsel ve regresyon doğrulaması

Orijinal `58ed3ab` executable'ı altı direct/staged × moving/idle/local sahnesi
için 1080 değişmez tam RGBA kare üretti. Aynı eski kaynağın bağımsız native SDF
ve forced-fine yolları, aday production ve aday fine bu dosyalara karşı
4×1080 = **4320 tam-byte karşılaştırma** yaptı: fark sıfır. 1080 dosyanın
önce/sonra SHA-256 değerleri aynı. Zamanlamadaki her top-10 tepe ve ±1 komşusu
bu bütün-kare kapsamındadır; liste JSON'da ayrıca saklanır. Testler arasında
golden dosyası güncellenmedi. Pixel koşularının süreleri benchmark'e karıştırılmaz.

Yeni `pui_vulkan_locality_tests` Release/Debug direct/staged'da geçer:
constructor/native gözlemde boş tape, sonraki fine hazırlığı, job adres/ömür ve
rebuild kararlılığı, düşük bütçede tam çıktı/boş job havuzu. Gerçek GPU admission
testi 0/1/31/32/33/63/64/65/127/128/255/256/257 request, üç row kapasitesi ve
13 epoch için bütün row/request/list/indirect alanlarını eski scalar algoritmayla
karşılaştırır. Portable yeni dört test, yanlış iş yükü/readback/eksik frame'i
reddetmeyi, bütün aykırıları korumayı ve discard edilebilen programlarda güvenli
profiler sınırını doğrular. Eski test assertion'ları ve golden referansları sabit.

## Son test kapısı

Tam `--vulkan --format` Release/Debug kapısı çalışıyor; sonucu henüz tamamlandı
diye işaretlenmedi. Makine kaydı ve bütün ham zamanlama/profile CSV/log arşivi:
[final JSON](perf/vulkan_compute_locality_final.json),
[ana kareler](perf/vulkan_compute_locality_frames.csv.gz),
[ek kontroller](perf/vulkan_compute_locality_controls.csv.gz),
[ham kayıtlar ve çalıştırma harness'leri](perf/vulkan_compute_locality_raw.zip).
Yerel immutable binary/source/RGBA arşivi `build-vulkan-locality/` altında.
Önceden var olan dokuz ilgisiz taslak korunur.
'''
report.write_text(body,encoding='utf-8')
print('Evidence assembled; full suite pending')
