"""Frozen normal timing, then independent full-byte proof. Never concurrent."""
from pathlib import Path
import csv
import hashlib
import json
import shutil
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from compare_vulkan_locality import workload_flags
from compare_vulkan_integrated import validate_counts

OUT = ROOT / "build-vulkan-locality" / ("final-" + time.strftime("%Y%m%d-%H%M%S"))
OUT.mkdir()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
sources = subprocess.check_output(["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard", "--",
    "include", "src", "tests", "examples", "tools", "cmake", "CMakeLists.txt", "CMakePresets.json", "README.md"], cwd=ROOT).decode().split("\0")
sources = sorted(set(sources) - {""})
def source_hashes(): return {p: sha(ROOT / p) for p in sources}
receipt = dict(source_before=source_hashes(), complete=False, phases=[], baseline_commit="58ed3ab074cc0d6fc9b5f3b9d0019862d9c9adbc")
with zipfile.ZipFile(OUT / "candidate-source.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for path in sources: archive.write(ROOT / path, path)
for label, source in (("before", ROOT / "build-vulkan-locality/baseline/program.exe"),
                      ("after", ROOT / "out/build/x64-release/Release/pui_vulkan_program_bench.exe")):
    shutil.copy2(source, OUT / (label + ".exe"))
receipt["binary_hashes"] = {label: sha(OUT / (label + ".exe")) for label in ("before", "after")}
receipt["archive_sha256"] = sha(OUT / "candidate-source.zip")
receipt["harness_sha256"] = sha(Path(__file__))
def save(): (OUT / "validation.json").write_text(json.dumps(receipt, indent=2) + "\n")
save()
print(f"Final validation: {OUT}", flush=True)
command = [sys.executable, "tools/compare_vulkan_locality.py", str(OUT / "before.exe"), str(OUT / "after.exe"),
           "--runs", "6", "--output", str(OUT / "timing")]
with (OUT / "timing-driver.log").open("w") as log:
    subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
receipt["phases"].append(dict(name="normal-timing", command=command, exit=0))
save()
print("25920 normal timed frames complete; starting separate pixel proof", flush=True)
measurement = json.loads((OUT / "timing/measurement.json").read_text())
receipt["pixels"] = dict(protocol="Original integrated baseline RGBA files; original native SDF and forced fine, candidate production/fine; 180 whole RGBA frames per case; no tolerance", cases=[], captures={}, peaks={})
for upload in ("direct", "staged"):
    for mode in ("moving", "idle", "local"):
        label = f"{upload}-{mode}"
        directory = OUT / "pixels" / label
        directory.mkdir(parents=True)
        golden = directory / "rgba"
        def proof(stem, binary, flags, operation):
            command = [str(binary), *flags, operation, str(golden)]
            print(f"pixel {label} {stem}", flush=True)
            with (directory / (stem + ".csv")).open("w") as output, (directory / (stem + ".log")).open("w") as log:
                result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=log, timeout=300)
            if result.returncode: raise RuntimeError(f"Pixel proof failed: {label} {stem}")
            rows = list(csv.DictReader((directory / (stem + ".csv")).open()))
            validate_counts(rows, mode)
            if len(rows) != 180 or any(int(row["frame"]) != i for i, row in enumerate(rows)):
                raise RuntimeError("Incomplete pixel workload")
            receipt["pixels"]["cases"].append(dict(case=label, mode=stem, command=command, frames=180, exit=0))
            save()
        proof("capture-before", OUT / "before.exe", workload_flags("production", mode, upload), "--capture")
        files = sorted(golden.glob("*.rgba"))
        if len(files) != 180 or any(p.stat().st_size != 1360 * 860 * 4 for p in files):
            raise RuntimeError("Incomplete/wrong-size golden domain")
        hashes = {p.name: sha(p) for p in files}
        receipt["pixels"]["captures"][label] = hashes
        native_flags = ["--sdf", "--vector-text", "--no-program-cache"]
        if mode != "moving": native_flags += ["--idle" if mode == "idle" else "--local-change"]
        if upload == "staged": native_flags += ["--staged"]
        proof("original-native", OUT / "before.exe", native_flags, "--reference")
        proof("original-fine", OUT / "before.exe", workload_flags("fine", mode, upload), "--reference")
        for painter in ("production", "fine"):
            proof("candidate-" + painter, OUT / "after.exe", workload_flags(painter, mode, upload), "--reference")
        if hashes != {p.name: sha(p) for p in files}: raise RuntimeError("Frozen goldens changed")
        peaks = set()
        for run in measurement["runs"]:
            if run["upload"] == upload and run["mode"] == mode:
                for frame in run["peak_frames"]:
                    peaks.update(f for f in (frame - 1, frame, frame + 1) if 0 <= f < 180)
        receipt["pixels"]["peaks"][label] = sorted(peaks)
        save()
receipt["pixels"].update(captured_frames=1080, exact_comparisons=4320, complete=True)
receipt["source_after"] = source_hashes()
receipt["changed_sources"] = [p for p in sources if receipt["source_before"][p] != receipt["source_after"][p]]
if receipt["changed_sources"]: raise RuntimeError("Sources changed during qualification")
receipt["complete"] = True
save()
print(f"Final timing and all-byte/peak proof complete: {OUT}", flush=True)
