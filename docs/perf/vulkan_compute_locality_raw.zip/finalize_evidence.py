from pathlib import Path
import csv,gzip,hashlib,json,re,zipfile
ROOT=Path(__file__).resolve().parents[1]
SUITE=ROOT/'build-vulkan-integrated/final-gate/full-20261027-235509-27736'
DEST=ROOT/'docs/perf'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
suite=json.loads((SUITE/'validation.json').read_text())
assert suite['complete'] and not suite['changed_sources']
assert len(suite['runs'])==2 and all(r['exit']==0 for r in suite['runs'])
receipt=json.loads((DEST/'vulkan_compute_locality_final.json').read_text())
with gzip.open(DEST/'vulkan_compute_locality_frames.csv.gz','rt') as stream:
 rows=list(csv.DictReader(stream))
assert len(rows)==25920
receipt['timed_invariants']={field:sum(int(row[field]) for row in rows)
 for field in ('draw_memory_allocations','draw_resource_creations','readbacks')}
assert not any(receipt['timed_invariants'].values())
receipt['gpu_allocation_totals']={}
for painter in ('production','fine'):
 for side in ('before','after'):
  selected=[row for row in rows if row['painter']==painter and row['side']==side]
  receipt['gpu_allocation_totals'][painter+'_'+side]={field:sorted({int(row[field]) for row in selected})
   for field in ('image_bytes','metadata_bytes','upload_resident_bytes')}
receipt['warm_module_heap']={}
for mode in ('integrated','tiles','tiles_staged','production_staged'):
 with (ROOT/'build-vulkan-locality/accepted-heap'/mode/'heap.csv').open() as stream:
  warm={row['allocation'] for row in csv.DictReader(stream) if int(row['frame'])>=8}
 assert not warm
 receipt['warm_module_heap'][mode]=len(warm)
assert receipt['full_byte_validation']['source_before']==suite['source_before']
preserved=json.loads((ROOT/'build-vulkan-integrated/final-gate/preserved-unrelated.json').read_text())
assert all(sha(ROOT/p)==expected for p,expected in preserved.items())
suite['path']=str(SUITE.relative_to(ROOT))
suite['logs']={}
with zipfile.ZipFile(DEST/'vulkan_compute_locality_raw.zip','a',zipfile.ZIP_DEFLATED) as archive:
 for mode in ('release','debug'):
  log=SUITE/(mode+'.log')
  text=log.read_text(encoding='utf8',errors='replace')
  cases=len(re.findall(r'^==== Vulkan ',text,re.MULTILINE))
  assert cases==96,(mode,cases)
  assert 'FAIL  ' not in text and 'all steps passed' in text
  suite['skipped_'+mode]=re.findall(r'^skip\s+.*$',text,re.MULTILINE|re.IGNORECASE)
  assert not suite['skipped_'+mode],suite['skipped_'+mode]
  suite['logs'][mode]=dict(path=str(log.relative_to(ROOT)),sha256=sha(log),native_cases=cases)
  archive.write(log,'full-suite/'+log.name)
 archive.write(SUITE/'validation.json','full-suite/validation.json')
 archive.write(Path(__file__),'finalize_evidence.py')
receipt.update(complete=True,suite=suite,preserved_unrelated=preserved)
receipt['artifacts']['docs/perf/vulkan_compute_locality_raw.zip']=sha(DEST/'vulkan_compute_locality_raw.zip')
(DEST/'vulkan_compute_locality_final.json').write_text(json.dumps(receipt,indent=2)+'\n')
report=ROOT/'docs/perf_vulkan_compute_locality.md'
body=report.read_text(encoding='utf8')
body=body.replace('Durum: inceleme ve uygulama sürüyor; tamamlanma iddiası değildir.',
 'Durum: inceleme, üç performans düzeltmesi ve doğrulama tamamlandı.\nMakale ile mimari farklar ve sahneye bağlı ölçüm sonuçları aşağıda belirtilir.')
body=body.replace('Ölçülmüş bulgular, uygulama kararları, reddedilen deneyler, regresyonlar,\nham frame/hash kayıtları ve son test kapısı çalışma ilerledikçe buraya eklenir.',
 'Ölçülmüş bulgular, alınan/alınmayan kararlar, regresyonlar, ham frame/hash\nkayıtları ve son test kapısı aşağıdadır.')
old='Tam `--vulkan --format` Release/Debug kapısı çalışıyor; sonucu henüz tamamlandı\ndiye işaretlenmedi.'
assert old in body
description='Tam `python tools/run_tests.py --vulkan --format --release` ve ardından\n`python tools/run_tests.py --vulkan --format` kapıları geçti. Her yapılandırmada\n96 native kayıt vakası, core/pump/performance/memory/preparation/showcase,\neski SDL/performance/Spiral ve tepe golden\'ları, 1150/5000 tüm-kare native\noraklları, iki 3600-kare/60-Add uzun koşu, tüm örnek selftest\'leri, installed\ncore/SDL/Vulkan tüketicileri ve API/tutorial/clang-format denetimleri geçer.\n334 kaynak dosyasının test öncesi/sonrası SHA-256 değerleri aynı.\n'
for run in suite['runs']:
 description+=f"{run['mode'].capitalize()} kapısı {run['seconds']:.1f} saniye sürdü.\n"
body=body.replace(old,description)
report.write_text(body,encoding='utf8')
print('Final evidence sealed; all suites and preserved files checked')
