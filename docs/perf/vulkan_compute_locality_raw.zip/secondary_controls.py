"""Retain A/A and matched-rate controls for the two noisy production cohorts."""
from pathlib import Path
import csv, gzip, io, json, sys, statistics
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from compare_vulkan_locality import workload_flags,checked_summary,cohort_summary
from compare_vulkan_integrated import retain_native
from compare_vulkan_program import native_command,window_cpu
BASE=ROOT/'build-vulkan-locality/final-20261027-234723'
OUT=BASE/'controls';OUT.mkdir()
receipt=dict(complete=False,runs=[],protocol='Same baseline executable on both A/A sides; then matched 60Hz baseline/candidate. Identical flags, alternating orders, every frame retained. Hidden/unfocused WSI.')
allrows=[]
for control,hz in [('identical_binary',0),('paced',60)]:
 for upload,mode in [('direct','moving'),('staged','idle')]:
  for repeat in range(6):
   for side in (('before','after') if repeat%2==0 else ('after','before')):
    exe=BASE/('before.exe' if side=='before' or control=='identical_binary' else 'after.exe')
    command=native_command(exe,workload_flags('production',mode,upload),hz)
    stem=OUT/f'{control}-{upload}-{mode}-{repeat:02}-{side}'
    print(stem.name,flush=True)
    stdout,stderr,wall,cpu=retain_native(command,stem)
    rows=list(csv.DictReader(io.StringIO(stdout)))
    summary=checked_summary(rows,mode,control=control,side=side,upload=upload,repeat=repeat)
    summary.update(cpu);summary.update(window_cpu(stderr));summary.update(command=command,wall_ms=wall)
    receipt['runs'].append(summary)
    allrows.extend(dict(control=control,side=side,upload=upload,mode=mode,repeat=repeat,**row) for row in rows)
    (OUT/'measurement.json').write_text(json.dumps(receipt,indent=2)+'\n')
cohorts=[]
for control in ('identical_binary','paced'):
 for upload,mode in [('direct','moving'),('staged','idle')]:
  for side in ('before','after'):
   rows=[r for r in allrows if (r['control'],r['upload'],r['mode'],r['side'])==(control,upload,mode,side)]
   runs=[r for r in receipt['runs'] if (r['control'],r['upload'],r['mode'],r['side'])==(control,upload,mode,side)]
   data=dict(control=control,upload=upload,mode=mode,side=side,**cohort_summary(rows))
   for field in ('frame_window_main_cycles','frame_window_main_cpu_ms','frame_window_cycles','frame_window_cpu_ms','process_cycles','process_cpu_ms'):
    data[field]=statistics.mean(r[field] for r in runs)
   data['gpu_ms_per_frame']=sum(r['gpu_ms'] for r in runs)/len(rows)
   data['gpu_samples']=sum(r['gpu_samples'] for r in runs)
   cohorts.append(data)
with gzip.open(OUT/'frames.csv.gz','wt',newline='',encoding='utf8') as f:
 w=csv.DictWriter(f,fieldnames=list(allrows[0]));w.writeheader();w.writerows(allrows)
receipt.update(complete=True,cohorts=cohorts,frames=len(allrows))
(OUT/'measurement.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('All controls complete',flush=True)
