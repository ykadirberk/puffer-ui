from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parents[1];w=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=[p for p in subprocess.check_output(['git','ls-files','-z'],cwd=r).decode().split('\0') if p and (r/p).is_file()]
status=[p for p in subprocess.check_output(['git','status','--porcelain','-z'],cwd=r).decode().split('\0') if p];assert all(p.startswith('?? ') for p in status)
b=dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),tracked={p:sha(r/p) for p in names},drafts={p[3:]:sha(r/p[3:]) for p in status},references={mode:{p.name:sha(p) for p in (r/'build-vulkan-gaussian-fix'/('spiral-'+mode)).glob('*.rgba')} for mode in ['direct','staged']},binaries={})
f=w/'before';f.mkdir(exist_ok=False)
for name in ['pui_vulkan_startup_spiral_tests','pui_vulkan_native_spiral_tests','pui_showcase_vulkan','pui_showcase_tests']:
 p=r/'out/build/x64-release/Release'/(name+'.exe');shutil.copy2(p,f/p.name);b['binaries'][name]=sha(p)
(w/'baseline.json').write_text(json.dumps(b,indent=2)+'\n');print('Frozen',len(names),'tracked files and',len(status),'unrelated drafts')
