from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).resolve().parent.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((root/'build-vector-paths/baseline.json').read_text())
changed=[p for p,h in b['tracked'].items() if p.startswith('tests/') and sha(root/p)!=h]
assert changed==['tests/test_renderer_boundary.cpp'],changed
delta=subprocess.check_output(['git','diff','--numstat','--','tests/test_renderer_boundary.cpp'],cwd=root,text=True).strip()
assert delta.startswith('5\t0\t'),delta
assert all(sha(root/p)==h for p,h in b['drafts'].items())
for p in ['include/pufferui/impl/vulkan_shaders.inl','src/shaders/vulkan/manifest.json','src/shaders/vulkan/harfbuzz_slug.glsl']:
    assert sha(root/p)==b['tracked'][p],p
assert not subprocess.check_output(['git','-C','vendored/SDL','status','--porcelain'],cwd=root,text=True).strip()
references={}
for mode,frames in b['references'].items():
    directory=root/'build-vulkan-gaussian-fix'/('spiral-'+mode)
    assert all(sha(directory/name)==h for name,h in frames.items())
    references[mode]=len(frames)
receipt={'base':b['commit'],'historical_test_oracle_files_unchanged':sum(p.startswith('tests/') for p in b['tracked'])-1,
    'required_interface_stub_additions':5,'old_test_body_or_assertion_changes':0,'unrelated_drafts_unchanged':len(b['drafts']),
    'immutable_spiral_reference_hashes':references,'base_shader_header_and_manifest_byte_exact':True,'slug_include_byte_exact':True,'SDL_submodule_clean':True,
    'new_vector_goldens':{p.name:sha(p) for p in sorted((root/'tests/golden/vector').glob('*.rgba'))}}
(root/'build-vector-paths/protected-audit.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps({k:v for k,v in receipt.items() if k!='new_vector_goldens'},indent=2))
