from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path(__file__).resolve().parent.parent;task=root/'build-vector-paths'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
report=json.loads((root/'docs/perf/vector_paths.json').read_text())
fixture={'format':'RGBA8,64x64,21 frames','verification_adapter':report['adapter'],'driver':report['driver'],
    'base_revision':report['base_commit'],'verified_release_binary_sha256':sha(root/'out/build/x64-release/Release/pui_vulkan_vector_data_tests.exe'),
    'path_shader_manifest':json.loads((root/'src/shaders/vulkan/path_manifest.json').read_text()),
    'images':report['protected']['new_vector_goldens']}
(root/'tests/golden/vector/receipt.json').write_text(json.dumps(fixture,indent=2)+'\n')
bundle=root/'docs/perf/vector_paths_raw.zip'
with zipfile.ZipFile(bundle,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for directory in [task,task/'measure-20261103-01',task/'measure-20261103-aa',task/'vector-memory-supplement']:
        for p in sorted(directory.iterdir()):
            if p.is_file() and p.suffix in ['.log','.csv','.json','.md','.py','.cpp']:
                archive.write(p,p.relative_to(task).as_posix())
    for name in ['showcase-vectors-final-portable.bmp','showcase-vectors-final-fixed.bmp','showcase-spiral-final.bmp']:
        archive.write(task/name,name)
    for p in sorted((root/'tests/golden/vector').iterdir()):archive.write(p,'new-goldens/'+p.name)
    for name in ['CMakeLists.txt','AGENTS.md','docs/perf_vector_paths.md','tools/amalgamate.ps1','tests/bench_vector.inl']:
        archive.write(root/name,'final-source/'+name)
receipt={'raw_bundle_sha256':sha(bundle),'raw_bundle_bytes':bundle.stat().st_size,
    'frames_sha256':sha(root/'docs/perf/vector_paths_frames.csv.gz'),'report_json_sha256':sha(root/'docs/perf/vector_paths.json')}
(root/'docs/perf/vector_paths_bundle.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
