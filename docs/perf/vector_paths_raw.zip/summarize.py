from pathlib import Path
import csv,gzip,hashlib,io,json,re,statistics
root=Path(__file__).resolve().parent.parent
folder=root/'build-vector-paths/measure-20261103-01'
receipt=json.loads((folder/'receipt.json').read_text())
def dist(values):
    values=sorted(values)
    return dict(mean=statistics.mean(values),p50=values[(len(values)-1)//2],p95=values[int((len(values)-1)*.95)],p99=values[int((len(values)-1)*.99)],maximum=values[-1])
all_rows=[]
groups=[]
for workload,case in sorted(set((r['workload'],r['case']) for r in receipt['runs'])):
    group={'workload':workload,'case':case,'variants':{}}
    variants=['portable','native'] if workload=='vector' else ['before','after']
    for variant in variants:
        runs=[r for r in receipt['runs'] if (r['workload'],r['case'],r['revision'])==(workload,case,variant)]
        times=[];peak=None
        for r in runs:
            rows=list(csv.DictReader((folder/(r['name']+'.csv')).open()))
            for row in rows:
                t=float(row['total_ms']);times.append(t)
                if peak is None or t>peak['ms']:peak={'run':r['name'],'frame':int(row['frame']),'ms':t}
                all_rows.append(dict(workload=workload,case=case,revision=variant,iteration=r['iteration'],**row))
        result={'runs':len(runs),'frames':len(times),'cpu_ms':dist(times),'cold_ms':dist([r['summary']['cold_ms'] for r in runs]),'peak':peak}
        for field in ['gpu_ms','setup_ms','setup_plus_cold_ms','path_residency_bytes','image_bytes']:
            if field in runs[0]['summary']:result[field]=dist([r['summary'][field] for r in runs])
        for field in ['draws','draw_cpp_allocations','draw_buffer_allocations','upload_bytes','resident_bytes','resident_upload_bytes']:
            if field in runs[0]['summary']:
                result[field]={'sum':sum(r['summary'][field]['sum'] for r in runs),'maximum':max(r['summary'][field]['maximum'] for r in runs)}
        group['variants'][variant]=result
    first,second=[group['variants'][v] for v in variants]
    group['cpu_mean_change_pct']=(second['cpu_ms']['mean']/first['cpu_ms']['mean']-1)*100
    if 'gpu_ms' in first:group['gpu_mean_change_pct']=(second['gpu_ms']['mean']/first['gpu_ms']['mean']-1)*100
    groups.append(group)
aa=[];aa_folder=root/'build-vector-paths/measure-20261103-aa'
for case in ['staged-plain','staged-cache']:
    result={'case':case,'variants':{}}
    for variant in ['a','b']:
        values=[];gpus=[]
        for iteration in range(8):
            stem=f'{case}-{iteration:02}-{variant}'
            rows=list(csv.DictReader((aa_folder/(stem+'.csv')).open()))
            assert [int(x['frame']) for x in rows]==list(range(180))
            values.extend(float(x['total_ms']) for x in rows)
            for row in rows:all_rows.append(dict(workload='same-binary-aa',case=case,revision=variant,iteration=iteration,**row))
            m=re.search(r'gpu_total_ms=([\d.]+)',(aa_folder/(stem+'.log')).read_text());gpus.append(float(m[1])/180)
        result['variants'][variant]={'cpu_ms':dist(values),'gpu_ms':dist(gpus)}
    a,b=[result['variants'][v] for v in ['a','b']]
    result.update(cpu_mean_change_pct=(b['cpu_ms']['mean']/a['cpu_ms']['mean']-1)*100,gpu_mean_change_pct=(b['gpu_ms']['mean']/a['gpu_ms']['mean']-1)*100)
    aa.append(result)
audit=json.loads((root/'build-vector-paths/protected-audit.json').read_text())
memory_root=root/'build-vector-paths/vector-memory-supplement'
memory_raw=json.loads((memory_root/'receipt.json').read_text())
memory=[]
for item in memory_raw['runs']:
    total=item['mapped_upload_bytes'] # Historical instrumentation label; counter is total.
    memory.append({'name':item['name'],'total_upload_bytes':total,'device_local_upload_bytes':item['device_local_upload_bytes'],
        'host_mapped_upload_bytes':total-item['device_local_upload_bytes']})
    for row in csv.DictReader((memory_root/(item['name']+'.csv')).open()):
        row['total_upload_bytes']=row.pop('mapped_upload_bytes')
        all_rows.append(dict(workload='memory-supplement',case=item['name'],revision='final-telemetry',iteration=0,**row))
final_hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in receipt['sources']}
changed=[p for p,h in receipt['sources'].items() if final_hashes[p]!=h]
assert not any(p.startswith(('include/','src/','examples/')) for p in changed),changed
report={'base_commit':receipt['commit'],'adapter':'AMD Radeon RX 9070 XT','vendor_id':4098,'device_id':30032,'driver':8388996,
    'protocol':{'old_scene':'actual showcase 5000 ->5003 Spiral, 180 frames, three keyboard Add activations','old_pairs_per_case':8,'vector_pairs_per_case':6,
        'svg_scenes':{'simple_instances':5000,'complex_instances':96},'reference_frames':sum(r['frames'] for r in receipt['references']),
        'main_timed_runs':len(receipt['runs']),'aa_timed_runs':32,'all_timed_frames':len(all_rows),'mode':'offscreen, unpaced, no readback in timed frames','discarded_frames':0},
    'tests':{'debug_full':'all steps passed','release_full':'all steps passed','native_registry_cases_per_config':53,'python_tools_after_packaging_and_gallery_fixes':19,
        'portable_private_tests':23,'native_private_tests':28,'new_painter_mode_images':84,'new_pipeline_images':12,'new_overlay_images':16,'new_affine_images':24,
        'new_immutable_vector_images':21,'source_snippets':65,'dependency_off_and_single_header':'passed','final_actual_showcase_frames':{'native_svg':180,'portable_svg_resized':180,'spiral':180},
        'live':'actual native Slug gallery, standard Vulkan showcase and two-window SDL demo reviewed; desktop input interfered with some CUA actions',
        'optional_visible_pacing':'inconclusive: separate --visible helper returned 0 with no required output; not used to certify foreground pacing'},
    'protected':audit,'groups':groups,'same_binary_aa':aa,'memory_supplement':memory,
    'memory_binary_hash':memory_raw['binary_sha256'],
    'telemetry_schema':{'primary_vector_resident_upload_bytes':'device-local subset only',
        'memory_supplement_mapped_upload_bytes':'historical label for total upload counter; host-mapped = total - device-local'},
    'production_source_changed_after_primary':False,'test_source_changed_after_primary':changed,'final_source_hashes':final_hashes,
    'source_hashes':receipt['sources'],'binary_hashes':receipt['binaries'],
    'shader_receipts':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ['src/shaders/vulkan/manifest.json','src/shaders/vulkan/path_manifest.json']}}
(root/'docs/perf').mkdir(exist_ok=True)
(root/'docs/perf/vector_paths.json').write_text(json.dumps(report,indent=2)+'\n')
fields=['workload','case','revision','iteration','frame','total_ms']+sorted(set().union(*(r.keys() for r in all_rows))-{'workload','case','revision','iteration','frame','total_ms'})
with gzip.open(root/'docs/perf/vector_paths_frames.csv.gz','wt',newline='') as file:
    writer=csv.DictWriter(file,fields);writer.writeheader();writer.writerows(all_rows)
for g in groups:
    print(g['workload'],g['case'],'CPU%',round(g['cpu_mean_change_pct'],3),'GPU%',round(g.get('gpu_mean_change_pct',0),3))
    for v,s in g['variants'].items():print(' ',v,'mean',round(s['cpu_ms']['mean'],6),'p95',round(s['cpu_ms']['p95'],6),'p99',round(s['cpu_ms']['p99'],6),'max',round(s['cpu_ms']['maximum'],6),'coldP50',round(s['cold_ms']['p50'],6),'setupP50',round(s.get('setup_ms',{}).get('p50',0),6),'residency',s.get('path_residency_bytes',{}).get('maximum',0),'image',s.get('image_bytes',{}).get('maximum',0),'uploadResident',s.get('resident_upload_bytes',{}).get('maximum',s.get('resident_bytes',{}).get('maximum',0)) )
for a in aa:print('AA',a['case'],a['cpu_mean_change_pct'],a['gpu_mean_change_pct'])
print('Rows',len(all_rows))
