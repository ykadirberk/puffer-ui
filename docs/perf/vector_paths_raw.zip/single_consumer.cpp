#define PUFFERUI_IMPLEMENTATION
#include "pufferui_single.h"
#include <cstdio>
int main()
{
    pui::null_device device;
    auto *ctx=pui::create_context(&device,&device.my_surface);
    auto *win=pui::add_window(ctx,nullptr,&device.my_surface,{0,0,64,64});
    auto image=pui::load_svg("<svg viewBox='0 0 32 32'><path d='M2 2H30V30H2Z' fill='red'/></svg>");
    pui::ui u(ctx);bool okay=image&&u.prepare_vector(image.image,{.max_pixel_size={32,32}});
    pui::begin_frame(ctx,*win,0,1.0/60);
    okay=u.draw_vector({0,0,32,32},image.image)&&okay;pui::end_frame(ctx);
    okay=!pui::violation_count(ctx)&&device.vertices>0&&okay;
    (void)u.release_vector(image.image);pui::destroy_vector(image.image);pui::destroy_context(ctx);
    std::puts(okay?"amalgamated SVG/path consumer passed":"amalgamated SVG/path consumer failed");return okay?0:1;
}
