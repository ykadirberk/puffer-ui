from pathlib import Path
import json,subprocess
root=Path(__file__).resolve().parent.parent
out=root/'build-vector-paths/measure-20261103-aa';out.mkdir(exist_ok=False)
exe=root/'build-vector-paths/measure-20261103-01/after/pui_vulkan_startup_spiral_tests.exe'
for case,args in [('staged-plain',['--staged']),('staged-cache',['--staged','--cache'])]:
    for iteration in range(8):
        for label in (['a','b'] if iteration%2==0 else ['b','a']):
            name=f'{case}-{iteration:02}-{label}';print(name,flush=True)
            r=subprocess.run([str(exe),'--bench',*args],cwd=root,capture_output=True,text=True,timeout=180)
            (out/(name+'.csv')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
            if r.returncode:raise RuntimeError(name)
print('32 same-binary A/A control runs completed',flush=True)
