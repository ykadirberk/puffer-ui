"""Frozen, sequential SVG/path qualification; retain cold and every outlier."""
from pathlib import Path
import csv,hashlib,io,json,math,os,re,shutil,statistics,subprocess,sys,time

root=Path(__file__).resolve().parent.parent
out=Path(sys.argv[1]).resolve();out.mkdir(parents=True,exist_ok=False)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
baseline=json.loads((root/'build-vector-paths/baseline.json').read_text())
before=root/'build-vector-paths/before'
after=root/'out/build/x64-release/Release'
bins={}
for revision,folder in [('before',before),('after',after)]:
    target=out/revision;target.mkdir()
    for name in ['pui_vulkan_startup_spiral_tests','pui_vulkan_native_spiral_tests','pui_showcase_tests']+(['pui_vulkan_vector_data_tests'] if revision=='after' else []):
        source=folder/(name+'.exe')
        if revision=='before' and digest(source)!=baseline['binaries'][name]:raise RuntimeError('Baseline binary changed')
        shutil.copy2(source,target/source.name);bins[revision,name]=target/source.name
env=os.environ.copy()
for key in ['PUFFERUI_VULKAN_VALIDATION','VK_INSTANCE_LAYERS']:env.pop(key,None)
receipt={'time':time.time(),'commit':baseline['commit'],'binaries':{f'{r}/{n}':digest(p) for (r,n),p in bins.items()},'runs':[],'references':[]}
def run(name,exe,args):
    print(name,flush=True)
    result=subprocess.run([str(exe),*args],cwd=root,env=env,capture_output=True,text=True,timeout=240)
    (out/(name+'.csv')).write_text(result.stdout)
    (out/(name+'.log')).write_text(result.stderr)
    if result.returncode:raise RuntimeError(f'{name} failed: {result.returncode}')
    return result
def distribution(values):
    a=sorted(values)
    return dict(mean=statistics.mean(a),p50=a[(len(a)-1)//2],p95=a[int((len(a)-1)*.95)],p99=a[int((len(a)-1)*.99)],maximum=a[-1])
def parse(result):
    rows=list(csv.DictReader(io.StringIO(result.stdout)))
    if [int(x['frame']) for x in rows]!=list(range(180)):raise RuntimeError('Incomplete frame sequence')
    times=[float(x['total_ms']) for x in rows]
    if any(not math.isfinite(x) or x<0 for x in times):raise RuntimeError('Invalid time')
    gpu=re.search(r'gpu_total_ms=([\d.]+) gpu_samples=(\d+)',result.stderr)
    setup=re.search(r'\bsetup_ms=([\d.]+)',result.stderr)
    summary={'wall':distribution(times),'steady':distribution(times[1:]),'cold_ms':times[0],
        'top10':sorted([{'frame':i,'ms':t} for i,t in enumerate(times)],key=lambda x:x['ms'],reverse=True)[:10]}
    if gpu:summary.update(gpu_ms=float(gpu[1])/180,gpu_samples=int(gpu[2]))
    if setup:summary.update(setup_ms=float(setup[1]),setup_plus_cold_ms=float(setup[1])+times[0])
    for key in ['draw_cpp_allocations','draw_buffer_allocations','draws','upload_bytes','resident_bytes','resident_upload_bytes']:
        if key in rows[0]:summary[key]={'sum':sum(int(x[key]) for x in rows),'maximum':max(int(x[key]) for x in rows)}
    footer=re.search(r'path_residency_bytes=(\d+) image_bytes=(\d+) readbacks=(\d+)',result.stderr)
    if footer:summary.update(path_residency_bytes=int(footer[1]),image_bytes=int(footer[2]),readbacks=int(footer[3]))
    return rows,summary
for staged in [False,True]:
    flags=['--staged'] if staged else [];mode='staged' if staged else 'direct'
    reference=root/'build-vulkan-gaussian-fix'/('spiral-'+mode)
    for cached in [False,True]:
        args=flags+(['--cache'] if cached else [])
        case=f'{mode}-'+('cache' if cached else 'plain')
        for revision in ['before','after']:
            name=f'golden-{revision}-{case}'
            run(name,bins[revision,'pui_vulkan_startup_spiral_tests'],[*args,'--reference',str(reference)])
            receipt['references'].append(dict(name=name,frames=180))
        for iteration in range(8):
            paired=[]
            for revision in (['before','after'] if iteration%2==0 else ['after','before']):
                name=f'spiral-{case}-{iteration:02}-{revision}'
                rows,summary=parse(run(name,bins[revision,'pui_vulkan_startup_spiral_tests'],['--bench',*args]))
                receipt['runs'].append(dict(name=name,workload='spiral',case=case,iteration=iteration,revision=revision,summary=summary))
                paired.append(rows)
            fields=['vertices','indices','draws','upload_bytes','glyph_upload_bytes']
            if [[tuple(r[f] for f in fields) for r in rows] for rows in paired][0]!=[[tuple(r[f] for f in fields) for r in rows] for rows in paired][1]:raise RuntimeError('Spiral stream counters changed')
    for revision in ['before','after']:
        name=f'golden-late-{revision}-{mode}'
        run(name,bins[revision,'pui_vulkan_native_spiral_tests'],[*flags,'--reference',str(reference)])
        receipt['references'].append(dict(name=name,frames=180))
for iteration in range(8):
    paired=[]
    for revision in (['before','after'] if iteration%2==0 else ['after','before']):
        name=f'null-{iteration:02}-{revision}'
        rows,summary=parse(run(name,bins[revision,'pui_showcase_tests'],['--bench','null','--tiles','5000']))
        receipt['runs'].append(dict(name=name,workload='null',case='null',iteration=iteration,revision=revision,summary=summary));paired.append(rows)
    fields=['count','draws','vertices','indices']
    if [tuple(r[f] for f in fields) for r in paired[0]]!=[tuple(r[f] for f in fields) for r in paired[1]]:raise RuntimeError('Null stream counters changed')
for staged in [False,True]:
    for complex_scene in [False,True]:
        mode='staged' if staged else 'direct';case=mode+'-'+('complex' if complex_scene else 'simple')
        flags=(['--staged'] if staged else [])+(['--complex'] if complex_scene else [])
        for iteration in range(6):
            for revision in (['portable','native'] if iteration%2==0 else ['native','portable']):
                name=f'vector-{case}-{iteration:02}-{revision}'
                rows,summary=parse(run(name,bins['after','pui_vulkan_vector_data_tests'],['--bench',*flags,*(['--portable'] if revision=='portable' else [])]))
                receipt['runs'].append(dict(name=name,workload='vector',case=case,iteration=iteration,revision=revision,summary=summary))
                if summary['draw_cpp_allocations']['sum'] or summary['draw_buffer_allocations']['sum'] or summary['readbacks']:raise RuntimeError('Drawing allocated or measurement read back')
    (out/'receipt-progress.json').write_text(json.dumps(receipt,indent=2))
receipt['sources']={p.relative_to(root).as_posix():digest(p) for folder in ['include','src','examples','tests','tools'] for p in (root/folder).rglob('*') if p.is_file() and p.suffix in ['.h','.inl','.cpp','.vert','.frag','.glsl','.py','.ps1','.cmake'] and '__pycache__' not in p.parts}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2))
print(f'All {len(receipt["runs"])} timed runs and {sum(x["frames"] for x in receipt["references"])} golden frames passed',flush=True)
