from pathlib import Path

source_path = Path('include/pufferui/impl/renderer_vector_geometry.inl')
source = source_path.read_text(encoding='utf-8')
ranges = []
start = source.index('    bool join(')
end = source.index('\n};\ninline bool stroke_ribbon', start)
ranges.append((start, end))
start = source.index('inline bool stroke_ribbon(')
end = source.index('inline bool dash_contour(', start)
ranges.append((start, end))
assert all(0 < end - start < 16000 for start, end in ranges)
patch = ['*** Begin Patch', '*** Update File: D:/myimgui/' + source_path.as_posix()]
for start, end in ranges:
    patch.append('@@')
    patch.extend('-' + line for line in source[start:end].splitlines())
    if source[end] == '\n':
        end += 1
    patch.append(' ' + source[end:source.index('\n', end)])
patch.append('*** End Patch')
Path('build-vector-paths/remove-ribbon.patch').write_text('\n'.join(patch) + '\n', encoding='utf-8')
