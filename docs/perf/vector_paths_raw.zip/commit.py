from pathlib import Path
import json,subprocess
root=Path(__file__).resolve().parent.parent
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git('branch','--show-current')=='codex/vulkan-native-harfbuzz'
assert git('rev-parse','HEAD')=='06d1d669cb3af188291ffc76ff68296115e7c5ae'
assert not git('diff','--cached','--name-only'),'Pre-existing staged files require review'
paths=json.loads((root/'build-vector-paths/stage-paths.json').read_text())
drafts=json.loads((root/'build-vector-paths/baseline.json').read_text())['drafts']
assert not set(paths)&set(drafts)
for p in paths:assert (root/p).resolve().is_relative_to(root.resolve()) and (root/p).is_file(),p
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
body=root/'build-vector-paths/commit-message.txt'
body.write_text('feat(render): add immutable SVG paths and native Slug vector painting\n\n'
    'Add bounded SVG/path resources and required renderer preparation, drawing and\n'
    'lifetime operations. Native Vulkan/HarfBuzz uses font-free Slug coverage;\n'
    'portable painters retain prepared RGBA textures. Preserve existing pixels.\n\n'
    'Add independent geometry, allocation, native lifetime/fault and immutable\n'
    'image regressions, actual showcase coverage, examples and an explicit tutorial.\n'
    'Qualify Debug/Release, dependency-OFF and amalgamated consumers. Retain 2160\n'
    'old-scene golden comparisons and 30240 timed frames, including measured\n'
    'STAGED costs and native SVG versus cached-texture GPU tradeoffs.\n')
subprocess.run(['git','commit','--file',str(body)],cwd=root,check=True)
print('COMMIT='+git('rev-parse','HEAD'),flush=True)
