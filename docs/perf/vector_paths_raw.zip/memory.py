from pathlib import Path
import csv,hashlib,io,json,shutil,subprocess
root=Path(__file__).resolve().parent.parent
out=root/'build-vector-paths/vector-memory-supplement';out.mkdir(exist_ok=False)
exe=out/'vector-bench.exe';shutil.copy2(root/'out/build/x64-release/Release/pui_vulkan_vector_data_tests.exe',exe)
receipt={'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'runs':[]}
for staged in [False,True]:
    for complex_scene in [False,True]:
        for portable in [False,True]:
            name=('staged' if staged else 'direct')+'-'+('complex' if complex_scene else 'simple')+'-'+('portable' if portable else 'native')
            args=['--bench']+(['--staged'] if staged else [])+(['--complex'] if complex_scene else [])+(['--portable'] if portable else [])
            print(name,flush=True);r=subprocess.run([str(exe),*args],cwd=root,capture_output=True,text=True,timeout=120)
            (out/(name+'.csv')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
            if r.returncode:raise RuntimeError(name)
            rows=list(csv.DictReader(io.StringIO(r.stdout)))
            assert [int(row['frame']) for row in rows]==list(range(180))
            assert not any(int(row['draw_cpp_allocations']) or int(row['draw_buffer_allocations']) for row in rows)
            receipt['runs'].append({'name':name,'total_upload_bytes':max(int(row['total_upload_bytes']) for row in rows),
                'device_local_upload_bytes':max(int(row['device_local_upload_bytes']) for row in rows)})
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(receipt,flush=True)
