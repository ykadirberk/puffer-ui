from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parent.parent
for mode,flags in [('debug',[]),('release',['--release'])]:
    output=root/'build-vector-paths'/f'full-{mode}-final.log'
    print(f'Starting final {mode}: {output}',flush=True)
    with output.open('w') as log:
        subprocess.run([sys.executable,'tools/run_tests.py','--vulkan','--format',*flags],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
    print(f'Final {mode} passed',flush=True)
