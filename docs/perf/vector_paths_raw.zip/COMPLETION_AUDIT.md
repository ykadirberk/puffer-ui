# SVG/path implementation completion audit

User scope: agreed immutable SVG/path renderer architecture; preserve old
images; regressions, all-frame measurements/goldens, examples/tutorial/docs.
Latest user steering additionally authorizes commit without asking; no push.

| Requirement | Authoritative current evidence | Status |
| --- | --- | --- |
| Semantic API / every backend / ownership | pufferui.h, draw_primitives, renderer_vector, native painter overrides; core/public/private and required-interface compile tests | proved |
| Paths, fills, affines, gradient/stroke/dash/clip/groups | vector_data/svg slices, portable geometry/raster, native scene builder; 23 portable/28 HB private regressions and independent stroker/geometry/pixel oracles | proved for documented subset |
| Bounded import and explicit unsupported errors | parser tests, namespace/use/cascade/limit/cycle/nonfinite/allocation cases; vector_paths.md explicit supported subset/limits | proved |
| Portable renderer preparation/cache/overlay | renderer_vector/raster and overlay state; allocation, source lease, palette, rebind and coincident-clip regressions | proved |
| Font-free Slug / graphics / bounded residency / timeline | renderer_vector_slug/gpu, vulkan_vector/pipeline/shaders; --gpu, --painter, --lifecycle (including rebind), --overlay, --bounds, --faults | proved |
| Existing shader/appearance invariants | audit.py: old header/manifest/Slug include byte-exact; 88 historic oracle/test files unchanged; 360 RGBA hashes unchanged;2160 complete immutable comparisons | proved |
| Actual examples/showcase and no-shorthand tutorial | vector_gallery atomics/--vectors; vector_manual public API program; actual showcase 180-frame runs plus 520/640/960 gap regression; Release captures/live windows reviewed | proved |
| Full Debug/Release existing gates | full-debug-final.log and full-release-final.log both all steps passed,53 native cases; 19 final Python tools + all final private/native vector cases after targeted changes | proved |
| SDK/SDL/HarfBuzz OFF and single header | dependency-off-amalgamated.log ends consumer passed; actual isolated SVG draw compiled from recursive amalgamated header | proved |
| Measurements including cold/outliers/null/GPU/alloc/memory |128 main +32 A/A +8 memory runs;30240 frame rows, no filtered frames; accurate total/device-local counter interpretation; all images exact in old workload | proved, tradeoffs documented |
| Default quality gate | vector_paths=true with HB, independent AA/alpha/curve/clip/gamma/DPI proofs and actual native SVG review; texture configuration remains explicit; no general speedup claim | proved for subset |
| Scope protection |32 unrelated drafts unchanged; SDL submodule clean; mandatory old mock adds only5 stubs, no old assertions removed | proved |
| Report / source receipts / raw evidence | docs/perf_vector_paths.md, perf/vector_paths.json, frames.csv.gz, raw.zip; rejected trials retained | assembled |
| User-authorized commit / external roadmap | commit and roadmap must be completed after final source audit | pending publication |

Known measured costs are not hidden: STAGED old-scene means +1.56%/+2.69%,
DIRECT worst increased, and native composed SVG GPU cost exceeds cached texture.
Optional visible pacing helper was inconclusive (exit0/no required output);
it is not a foreground performance certificate. Actual showcase live rendering
and full startup/WSI tests are separate positive evidence.
