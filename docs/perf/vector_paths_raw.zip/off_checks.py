from pathlib import Path
import subprocess
root=Path(__file__).resolve().parent.parent
task=root/'build-vector-paths'
def run(*args):subprocess.run([str(x) for x in args],cwd=root,check=True)
core=task/'core-off'
run('cmake','-S',root,'-B',core,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_MSVC_DEBUG_INFORMATION_FORMAT=Embedded',
    '-DPUFFERUI_WITH_SDL3=OFF','-DPUFFERUI_WITH_VULKAN=OFF','-DPUFFERUI_WITH_HARFBUZZ=OFF','-DPUFFERUI_BUILD_EXAMPLES=OFF')
run('cmake','--build',core,'--target','pui_core_tests','pui_vector_tests')
run(core/'Release/pui_core_tests.exe');run(core/'Release/pui_vector_tests.exe')
prefix=task/'installed-release'
run('cmake','--install',root/'out/build/x64-release','--prefix',prefix,'--config','Release')
native=task/'native-offhb'
run('cmake','-S',root,'-B',native,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_MSVC_DEBUG_INFORMATION_FORMAT=Embedded',
    '-DPUFFERUI_WITH_SDL3=ON','-DPUFFERUI_WITH_VULKAN=ON','-DPUFFERUI_WITH_HARFBUZZ=OFF','-DPUFFERUI_USE_SYSTEM_SDL3=ON',
    '-DSDL3_DIR='+str(prefix/'cmake'))
run('cmake','--build',native,'--target','pui_tut_vector_manual')
run(native/'Release/pui_tut_vector_manual.exe','--selftest','--frames','8','--resize','800x560','--screenshot',task/'tutorial-offhb.bmp')
run('pwsh','-NoProfile','-File','tools/amalgamate.ps1','-Out',task/'pufferui_single.h')
run('cl','/nologo','/std:c++20','/EHsc','/O2','/I'+str(task),'/I'+str(root/'vendored/stb'),task/'single_consumer.cpp',
    '/Fe'+str(task/'single_consumer.exe'),'/Fo'+str(task/'single_consumer.obj'))
run(task/'single_consumer.exe')
print('Core/SDL/Vulkan/HarfBuzz dependency boundaries and amalgamated SVG consumer passed',flush=True)
