#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <dbghelp.h>
#include <cstdio>
#include <string>
int wmain(int argc,wchar_t **argv)
{
    std::wstring command;
    for(int i=1;i<argc;++i){if(i>1)command+=L" ";command+=L"\"";command+=argv[i];command+=L"\"";}
    STARTUPINFOW startup{};startup.cb=sizeof(startup);
    PROCESS_INFORMATION process{};
    if(!CreateProcessW(nullptr,command.data(),nullptr,nullptr,FALSE,DEBUG_ONLY_THIS_PROCESS|CREATE_NO_WINDOW,nullptr,nullptr,&startup,&process))return 2;
    bool running=true;int result=0;const auto start=GetTickCount64();
    while(running)
    {
        DEBUG_EVENT event{};
        if(!WaitForDebugEvent(&event,1000))
        {if(GetTickCount64()-start>60000){TerminateProcess(process.hProcess,3);result=3;}continue;}
        DWORD disposition=DBG_CONTINUE;
        if(event.dwDebugEventCode==CREATE_PROCESS_DEBUG_EVENT&&event.u.CreateProcessInfo.hFile)CloseHandle(event.u.CreateProcessInfo.hFile);
        if(event.dwDebugEventCode==LOAD_DLL_DEBUG_EVENT&&event.u.LoadDll.hFile)CloseHandle(event.u.LoadDll.hFile);
        if(event.dwDebugEventCode==EXCEPTION_DEBUG_EVENT)
        {
            auto &exception=event.u.Exception;
            if(exception.ExceptionRecord.ExceptionCode!=EXCEPTION_BREAKPOINT)disposition=DBG_EXCEPTION_NOT_HANDLED;
            if(!exception.dwFirstChance)
            {
                std::printf("Unhandled exception %08lx at %p thread %lu\n",exception.ExceptionRecord.ExceptionCode,exception.ExceptionRecord.ExceptionAddress,event.dwThreadId);
                SymSetOptions(SYMOPT_LOAD_LINES|SYMOPT_UNDNAME|SYMOPT_DEFERRED_LOADS);
                SymInitialize(process.hProcess,nullptr,TRUE);
                HANDLE thread=OpenThread(THREAD_GET_CONTEXT|THREAD_QUERY_INFORMATION,FALSE,event.dwThreadId);
                CONTEXT context{};context.ContextFlags=CONTEXT_FULL;
                GetThreadContext(thread,&context);
                STACKFRAME64 frame{};frame.AddrPC.Offset=context.Rip;frame.AddrStack.Offset=context.Rsp;frame.AddrFrame.Offset=context.Rbp;
                frame.AddrPC.Mode=frame.AddrStack.Mode=frame.AddrFrame.Mode=AddrModeFlat;
                for(int i=0;i<35;++i)
                {
                    char buffer[sizeof(SYMBOL_INFO)+2048]{};
                    auto *symbol=reinterpret_cast<SYMBOL_INFO *>(buffer);symbol->SizeOfStruct=sizeof(SYMBOL_INFO);symbol->MaxNameLen=2047;
                    DWORD64 offset=0;IMAGEHLP_LINE64 line{};line.SizeOfStruct=sizeof(line);DWORD displacement=0;
                    if(SymFromAddr(process.hProcess,frame.AddrPC.Offset,&offset,symbol))std::printf("%02d %016llx %s+%llu",i,frame.AddrPC.Offset,symbol->Name,offset);
                    else std::printf("%02d %016llx",i,frame.AddrPC.Offset);
                    if(SymGetLineFromAddr64(process.hProcess,frame.AddrPC.Offset,&displacement,&line))std::printf(" %s:%lu",line.FileName,line.LineNumber);
                    std::puts("");
                    if(!StackWalk64(IMAGE_FILE_MACHINE_AMD64,process.hProcess,thread,&frame,&context,nullptr,SymFunctionTableAccess64,SymGetModuleBase64,nullptr))break;
                }
                CloseHandle(thread);SymCleanup(process.hProcess);std::fflush(stdout);
                TerminateProcess(process.hProcess,1);result=1;
            }
        }
        if(event.dwDebugEventCode==EXIT_PROCESS_DEBUG_EVENT){if(!result)result=event.u.ExitProcess.dwExitCode;running=false;}
        ContinueDebugEvent(event.dwProcessId,event.dwThreadId,disposition);
    }
    CloseHandle(process.hThread);CloseHandle(process.hProcess);return result;
}
