Gaussian correction qualification, Windows AMD RX 9070 XT, 2026-11-01.

Reference origins are independent:
1. compatibility-goldens: actual ab060 renderer before the 15px policy or fixes.
2. correct-goldens: full-image Gaussian and ordinary rounded mask composite,
   with a separately prepared straight-alpha blue texture for transparency.
   Captured using the 15px policy before either native ROI/composite fix.
3. Spiral: 15px policy before the two fixes, 180 full 1360x860 RGBA frames per
   upload mode. The 8-15px policy change itself is explicitly intentional.

Run the current pui_vulkan_gaussian_tests with --goldens <correct-goldens>,
then separately --compatibility <compatibility-goldens>, each with and without
--staged. Default invocation computes an independent oracle on the selected GPU.
Use new directories for capture options; do not overwrite or update goldens.
Current full checks: python tools/run_tests.py --vulkan --format [--release].

The policy15 header replacements plus the ab060 include tree reproduce the
intermediate renderer; no shader compiler is needed to use its frozen SPIR-V.
The original test_vulkan_blur helper is provided for recompiling the controls
against ab060 (its newer helper references the new private pair-count constant).
run/driver.py records complete compiler/link/run commands for this host.
policy-reference.log includes an initial transient wrapper compilation error
from Windows near/small macros. The corrected wrapper in policy-spiral.log
successfully captured both 180-frame baselines. Final Release/Debug gates pass.

Raw Spiral captures total 1,684,224,000 bytes and are retained in the ignored
build-vulkan-gaussian-fix/spiral-{direct,staged} workspace folders. Their complete
SHA256 manifest and all four exact comparison logs are archived here. All other
frozen/actual Gaussian BMPs are included. No performance/FPS claim is made.
Exact static captures qualify this device/driver; cross-device parity is not
assumed. Existing committed golden bytes and unrelated report drafts are fixed.
For legacy audit alpha_sample rows, channels_gt2 is a fixed one-sample marker;
use actual/reference or max_error for the error. The JSON uses scalar errors.
