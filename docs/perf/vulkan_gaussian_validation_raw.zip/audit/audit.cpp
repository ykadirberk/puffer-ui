// Read-only audit harness: reuse the committed implementation and independent
// CPU test helpers without changing any tracked source or assertion.
#define main committed_blur_test_main
#include "../tests/test_vulkan_blur.cpp"
#undef main
#include <fstream>
#include <string>

namespace gaussian_audit
{
std::string output_dir;
struct difference
{
    i32 maximum = 0, over_two = 0, x = 0, y = 0, channel = 0, actual = 0, expected = 0;
};
difference compare(const std::vector<u8> &a, const std::vector<u8> &b, i32 width)
{
    difference result;
    for (usize i = 0; i < a.size(); ++i)
    {
        const i32 delta = std::abs(static_cast<i32>(a[i]) - b[i]);
        if (delta > 2) ++result.over_two;
        if (delta > result.maximum)
        {
            result.maximum = delta;
            result.x = static_cast<i32>(i / 4) % width;
            result.y = static_cast<i32>(i / 4) / width;
            result.channel = static_cast<i32>(i % 4);
            result.actual = a[i];
            result.expected = b[i];
        }
    }
    return result;
}
void print(const char *stage, f32 radius, f32 scale, i32 pattern, const difference &d)
{
    std::printf("%s,%.6f,%.6f,%d,%d,%d,%d,%d,%d,%d,%d\n", stage, radius, scale, pattern,
                d.maximum, d.over_two, d.x, d.y, d.channel, d.actual, d.expected);
}
void bmp(const std::string &name, const std::vector<u8> &pixels, i32 width, i32 height)
{
    std::ofstream out(output_dir + "/" + name + ".bmp", std::ios::binary);
    const auto u16le = [&](u32 value)
    {
        out.put(static_cast<char>(value));
        out.put(static_cast<char>(value >> 8));
    };
    const auto u32le = [&](u32 value)
    {
        u16le(value);
        u16le(value >> 16);
    };
    u16le(0x4d42); u32le(54 + width * height * 4); u32le(0); u32le(54);
    u32le(40); u32le(width); u32le(static_cast<u32>(-height)); u16le(1); u16le(32);
    u32le(0); u32le(width * height * 4); u32le(0); u32le(0); u32le(0); u32le(0);
    for (usize i = 0; i < pixels.size(); i += 4)
    {
        out.put(static_cast<char>(pixels[i + 2]));
        out.put(static_cast<char>(pixels[i + 1]));
        out.put(static_cast<char>(pixels[i]));
        out.put(static_cast<char>(pixels[i + 3]));
    }
}
bool full_blur(vk_detail::device &d, vk_detail::texture *source, vk_detail::texture *a,
               vk_detail::texture *b, f32 radius)
{
    const auto plan = vk_detail::plan_blur(radius);
    CHECK(plan.gaussian);
    auto parameters = plan.taps;
    const rect area{0, 0, static_cast<f32>(source->width), static_cast<f32>(source->height)};
    parameters.step[0] = 1.0f / source->width;
    d.filter(source, area, a, area, vk_detail::blur_kernel::GAUSSIAN, parameters, area);
    parameters.step[0] = 0;
    parameters.step[1] = 1.0f / a->height;
    d.filter(a, area, b, area, vk_detail::blur_kernel::GAUSSIAN, parameters, area);
    return true;
}
bool raw_kernels(vk_detail::device &d)
{
    auto *a = static_cast<vk_detail::texture *>(d.create_target(80, 64));
    auto *b = static_cast<vk_detail::texture *>(d.create_target(80, 64));
    CHECK(a && b);
    for (i32 pattern = 0; pattern < 4; ++pattern)
    {
        cpu_image input(65, 49);
        for (i32 y = 0; y < 49; ++y)
            for (i32 x = 0; x < 65; ++x)
                for (i32 c = 0; c < 4; ++c)
                    input.pixels[(y * 65 + x) * 4 + c] = static_cast<u8>(c == 3 ? 255 :
                        pattern == 0 ? 87 : pattern == 1 ? (x == 32 && y == 24 ? 255 : 0) :
                        pattern == 2 ? (x >= 32 ? 255 : 0) : (x * 53 + y * 71 + c * 97) % 256);
        auto *source = static_cast<vk_detail::texture *>(d.create_texture(65, 49, input.pixels.data()));
        CHECK(source);
        for (f32 radius : {0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 2.5f, 3.0f, 4.0f,
                           5.0f, 6.0f, 7.0f, 7.99f, 8.0f})
        {
            CHECK(full_blur(d, source, a, b, radius));
            auto horizontal = convolution(input, 65, 49, vk_detail::blur_kernel::GAUSSIAN, radius, true);
            auto expected = convolution(horizontal, 65, 49, vk_detail::blur_kernel::GAUSSIAN, radius, false);
            std::vector<u8> actual(input.pixels.size());
            CHECK(d.read_pixels(b, 0, 0, 65, 49, actual.data()));
            print("raw_kernel", radius, 1, pattern, compare(actual, expected.pixels, 65));
        }
        d.destroy_texture(source);
    }
    d.destroy_target(a); d.destroy_target(b);
    return true;
}
void full_composite(context *c, const paint_blur &p, texture_handle texture, i32 width, i32 height)
{
    const rect *clip = c->clip_depth ? &c->clip_stack[c->clip_depth - 1] : nullptr;
    detail::dl_prepare(c, texture, clip);
    auto &vertices = c->dl->scratch_v;
    auto &indices = c->dl->scratch_i;
    vertices.clear(); indices.clear();
    const color tint{255, 255, 255, static_cast<u8>(p.alpha * 255)};
    detail::build_rounded_fan(p.area, detail::clamp_radii(p.area, p.radii), tint,
        [&](f32 x, f32 y, f32 &u, f32 &v)
        {
            u = x * c->render_scale / width;
            v = y * c->render_scale / height;
        }, vertices, indices);
    detail::dl_add(c, vertices.data(), static_cast<i32>(vertices.size()), indices.data(),
                   static_cast<i32>(indices.size()));
    detail::dl_flush(c);
}
bool rounded_regions(vk_detail::device &d)
{
    constexpr i32 width = 193, height = 145;
    view views[2];
    CHECK(views[0].initialize(&d, width, height) && views[1].initialize(&d, width, height));
    auto *a = static_cast<vk_detail::texture *>(d.create_target(width, height));
    auto *b = static_cast<vk_detail::texture *>(d.create_target(width, height));
    CHECK(a && b);
    std::vector<u8> pixels[2];
    for (auto &image : pixels) image.resize(width * height * 4);
    i32 frame = 0, worst = 0;
    for (f32 scale : {1.0f, 1.25f, 1.5f, 2.0f, 3.0f, 4.0f})
        for (f32 logical : {0.5f, 0.75f, 1.0f, 2.0f, 4.0f})
        {
            const f32 radius = logical * scale;
            if (radius > 8) continue;
            const paint_blur blur{{10, 8, 30, 24}, logical, corner_radii::all(5), 1};
            const i32 cut = static_cast<i32>(std::ceil(blur.area.bottom() * scale) + std::ceil(radius));
            cpu_image input(width, height);
            for (i32 y = 0; y < height; ++y)
                for (i32 x = 0; x < width; ++x)
                    for (i32 c = 0; c < 4; ++c)
                        input.pixels[(y * width + x) * 4 + c] = static_cast<u8>(c == 3 || y >= cut ? 255 : 0);
            auto *source = static_cast<vk_detail::texture *>(d.create_texture(width, height, input.pixels.data()));
            CHECK(source && full_blur(d, source, a, b, radius));
            for (i32 variant = 0; variant < 2; ++variant)
            {
                auto &v = views[variant];
                set_window_scale(*v.win, scale);
                begin_frame(v.ctx, *v.win, frame / 60.0, 1.0 / 60.0);
                d.blit(source, nullptr, v.surface->scene_target(), nullptr);
                if (variant == 0)
                {
                    ui u(v.ctx);
                    u.blur(blur.area, blur.radius, blur.radii, blur.alpha);
                }
                else full_composite(v.ctx, blur, b, width, height);
                end_frame(v.ctx);
                CHECK(d.read_pixels(v.surface->scene_target(), 0, 0, width, height, pixels[variant].data()));
            }
            const auto delta = compare(pixels[0], pixels[1], width);
            print("rounded_crop", radius, scale, 0, delta);
            if (delta.maximum > worst)
            {
                worst = delta.maximum;
                bmp("rounded_actual", pixels[0], width, height);
                bmp("rounded_full_reference", pixels[1], width, height);
            }
            d.destroy_texture(source);
            ++frame;
        }
    d.destroy_target(a); d.destroy_target(b);
    return true;
}
bool alpha_composite(vk_detail::device &d)
{
    constexpr i32 width = 65, height = 49, boundary = 32;
    view v;
    CHECK(v.initialize(&d, width, height));
    auto *a = static_cast<vk_detail::texture *>(d.create_target(width, height));
    auto *b = static_cast<vk_detail::texture *>(d.create_target(width, height));
    CHECK(a && b);
    cpu_image input(width, height);
    for (i32 y = 0; y < height; ++y)
        for (i32 x = 0; x < width; ++x)
        {
            input.pixels[(y * width + x) * 4 + 2] = x < boundary ? 255 : 0;
            input.pixels[(y * width + x) * 4 + 3] = x < boundary ? 255 : 0;
        }
    auto *source = static_cast<vk_detail::texture *>(d.create_texture(width, height, input.pixels.data()));
    CHECK(source);
    std::vector<u8> actual(input.pixels.size()), filtered(input.pixels.size());
    for (f32 radius : {1.0f, 2.5f, 8.0f})
    {
        CHECK(full_blur(d, source, a, b, radius));
        CHECK(d.read_pixels(b, 0, 0, width, height, filtered.data()));
        begin_frame(v.ctx, *v.win, radius, 1.0 / 60.0);
        d.clear({0, 0, 0, 0});
        {
            ui u(v.ctx);
            u.draw_rect({0, 0, boundary, height}, {0, 0, 255, 255});
            u.blur({0, 0, width, height}, radius);
        }
        end_frame(v.ctx);
        CHECK(d.read_pixels(v.surface->scene_target(), 0, 0, width, height, actual.data()));
        const usize at = static_cast<usize>((height / 2 * width + boundary) * 4);
        std::printf("alpha_sample,%.6f,1,0,%d,1,%d,%d,2,%u,%u\n", radius,
                    std::abs(static_cast<i32>(actual[at + 2]) - actual[at + 3]), boundary,
                    height / 2, actual[at + 2], actual[at + 3]);
        std::printf("alpha_raw,%.6f,1,0,%d,0,%d,%d,2,%u,%u\n", radius,
                    std::abs(static_cast<i32>(filtered[at + 2]) - filtered[at + 3]), boundary,
                    height / 2, filtered[at + 2], filtered[at + 3]);
    }
    d.destroy_texture(source); d.destroy_target(a); d.destroy_target(b);
    return true;
}
} // namespace gaussian_audit
int main(int argc, char **argv)
{
    if (argc < 2) return 2;
    gaussian_audit::output_dir = argv[1];
    vulkan_device_opts options;
    options.validation = true;
    options.error_callback = diagnostic;
    options.upload_mode = argc > 2 ? vulkan_upload_mode::STAGED : vulkan_upload_mode::DIRECT;
    auto *d = static_cast<vk_detail::device *>(create_vulkan_device(options));
    if (!d) return 1;
    std::puts("stage,radius,scale,pattern,max_error,channels_gt2,x,y,channel,actual,reference");
    const bool ok = gaussian_audit::raw_kernels(*d) && gaussian_audit::rounded_regions(*d) &&
                    gaussian_audit::alpha_composite(*d) && vulkan_wait_idle(d) &&
                    !vulkan_statistics(d).validation_errors;
    destroy_vulkan_device(d);
    return ok && !errors ? 0 : 1;
}
