from pathlib import Path
import csv
import hashlib
import io
import json
import subprocess
import zipfile

root = Path(__file__).resolve().parents[1]
work = Path(__file__).resolve().parent
old = json.loads((work / 'baseline.json').read_text())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
for name in old['tests'] + old['drafts']:
    if name != 'tests/test_vulkan_blur.cpp':
        assert sha(root / name) == old['hashes'][name], name
for gate in ['release', 'debug']:
    content = (work / (gate + '.log')).read_text()
    assert 'all steps passed' in content and 'FAIL' not in content
    assert content.count('==== Vulkan ') == 33
    assert 'golden: 22 scene(s), 0 failure(s)' in content
assert (work / 'goldens.log').read_text().count('exact RGBA passed') == 4
assert (work / 'goldens.log').read_text().count('exact_pairs=288 idle_hits=72') == 2
assert (work / 'off.log').read_text().count('exact_pairs=288 idle_hits=72') == 2
def audit(path):
    lines = path.read_text().splitlines()
    start = next(i for i, line in enumerate(lines) if line.startswith('stage,radius,'))
    rows = list(csv.DictReader(lines[start:]))
    rounded = [row for row in rows if row['stage'] == 'rounded_crop']
    return {'rounded_cases': len(rounded),
            'rounded_max_channel_error': max(int(row['max_error']) for row in rounded),
            'rounded_cases_with_error_gt2': sum(int(row['max_error']) > 2 for row in rounded),
            'alpha_witnesses': [{'radius': float(row['radius']), 'x': int(row['x']),
                                 'y': int(row['y']), 'channel': int(row['channel']),
                                 'actual': int(row['actual']), 'reference': int(row['reference']),
                                 'absolute_error': abs(int(row['actual']) - int(row['reference']))}
                                for row in rows if row['stage'] == 'alpha_sample'],
            'csv_sha256': sha(path)}
audits = {}
for upload in ['direct', 'staged']:
    before = audit(root / ('build-vulkan-gaussian-audit/' + upload + '.csv'))
    after = audit(work / ('audit-' + upload + '.csv'))
    assert before['rounded_max_channel_error'] == 7 and after['rounded_max_channel_error'] == 0
    assert all(row['actual'] == row['reference'] for row in after['alpha_witnesses'])
    audits[upload] = {'before': before, 'after': after}
frames = io.StringIO()
writer = csv.writer(frames, lineterminator='\n')
writer.writerow(['upload', 'frame', 'bytes', 'sha256'])
for upload in ['direct', 'staged']:
    files = sorted((work / ('spiral-' + upload)).glob('frame-*.rgba'))
    assert len(files) == 180
    for i, path in enumerate(files):
        assert path.name == f'frame-{i:03d}.rgba'
        assert path.stat().st_size == 1360 * 860 * 4
        writer.writerow([upload, i, path.stat().st_size, sha(path)])
frame_csv = frames.getvalue()
frozen = {}
for group, pattern in [('compatibility-goldens', '*.bmp'), ('correct-goldens', '*.bmp'),
                       ('actual-direct', '*.bmp'), ('actual-staged', '*.bmp')]:
    files = sorted((work / group).glob(pattern))
    assert len(files) == (8 if group.startswith('compatibility') else 36)
    frozen[group] = {path.name: sha(path) for path in files}
for i in range(36):
    assert frozen['correct-goldens'][f'reference-{i:02d}.bmp'] == frozen['actual-direct'][f'actual-{i:02d}.bmp']
    assert frozen['correct-goldens'][f'reference-{i:02d}.bmp'] == frozen['actual-staged'][f'actual-{i:02d}.bmp']
names = subprocess.check_output(['git', 'diff', old['commit'], '--name-only'], cwd=root, text=True).splitlines()
names.append('tests/test_vulkan_gaussian.cpp')
source_hashes = {name: sha(root / name) for name in names if not name.startswith('docs/perf/')}
binaries = {}
for config in ['release', 'debug']:
    for name in ['pui_vulkan_gaussian_tests', 'pui_vulkan_blur_tests', 'pui_vulkan_native_spiral_tests']:
        path = root / f'out/build/x64-{config}/{config.title()}/{name}.exe'
        binaries[path.relative_to(root).as_posix()] = sha(path)
for name in ['pui_showcase_vulkan', 'pui_demo']:
    path = root / f'out/build/x64-release/Release/{name}.exe'
    binaries[path.relative_to(root).as_posix()] = sha(path)
baseline_binaries = {}
for name in ['before/gaussian-controls.exe', 'policy15/reference.exe', 'policy15/spiral.exe']:
    baseline_binaries[name] = sha(work / name)
archive = root / 'docs/perf/vulkan_gaussian_validation_raw.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name in ['baseline.json', 'controls-before.log', 'policy-reference.log', 'policy-spiral.log',
                 'build.log', 'goldens.log', 'release.log', 'debug-build.log', 'debug.log',
                 'off.log', 'audit-after.log', 'audit-direct.csv', 'audit-staged.csv',
                 'live.json', 'driver.py', 'freeze.py', 'policy_spiral.cpp', 'report.py']:
        bundle.write(work / name, 'run/' + name)
    bundle.write(work / 'policy15/source-sha256.json', 'policy15/source-sha256.json')
    for name in ['vulkan_device.inl', 'vulkan_blur.inl', 'vulkan_shaders.inl']:
        bundle.write(work / ('policy15/include/pufferui/impl/' + name), 'policy15/include/pufferui/impl/' + name)
    bundle.write(root / 'tests/test_vulkan_gaussian.cpp', 'repro/test_vulkan_gaussian.cpp')
    original_helper = subprocess.check_output(['git', 'show', old['commit'] + ':tests/test_vulkan_blur.cpp'], cwd=root)
    bundle.writestr('repro/test_vulkan_blur.ab060.cpp', original_helper)
    bundle.write(root / 'build-vulkan-gaussian-audit/audit.cpp', 'audit/audit.cpp')
    for upload in ['direct', 'staged']:
        bundle.write(root / ('build-vulkan-gaussian-audit/' + upload + '.csv'), 'audit/before-' + upload + '.csv')
    for group in frozen:
        for path in sorted((work / group).glob('*.bmp')):
            bundle.write(path, group + '/' + path.name)
    bundle.writestr('spiral-frame-sha256.csv', frame_csv)
    bundle.writestr('frozen-image-sha256.json', json.dumps(frozen, indent=2) + '\n')
    bundle.writestr('candidate-source-sha256.json', json.dumps(source_hashes, indent=2) + '\n')
    bundle.writestr('binary-sha256.json', json.dumps(binaries, indent=2) + '\n')
    bundle.writestr('baseline-binary-sha256.json', json.dumps(baseline_binaries, indent=2) + '\n')
    bundle.writestr('README.txt', '''Gaussian correction qualification, Windows AMD RX 9070 XT, 2026-11-01.

Reference origins are independent:
1. compatibility-goldens: actual ab060 renderer before the 15px policy or fixes.
2. correct-goldens: full-image Gaussian and ordinary rounded mask composite,
   with a separately prepared straight-alpha blue texture for transparency.
   Captured using the 15px policy before either native ROI/composite fix.
3. Spiral: 15px policy before the two fixes, 180 full 1360x860 RGBA frames per
   upload mode. The 8-15px policy change itself is explicitly intentional.

Run the current pui_vulkan_gaussian_tests with --goldens <correct-goldens>,
then separately --compatibility <compatibility-goldens>, each with and without
--staged. Default invocation computes an independent oracle on the selected GPU.
Use new directories for capture options; do not overwrite or update goldens.
Current full checks: python tools/run_tests.py --vulkan --format [--release].

The policy15 header replacements plus the ab060 include tree reproduce the
intermediate renderer; no shader compiler is needed to use its frozen SPIR-V.
The original test_vulkan_blur helper is provided for recompiling the controls
against ab060 (its newer helper references the new private pair-count constant).
run/driver.py records complete compiler/link/run commands for this host.
policy-reference.log includes an initial transient wrapper compilation error
from Windows near/small macros. The corrected wrapper in policy-spiral.log
successfully captured both 180-frame baselines. Final Release/Debug gates pass.

Raw Spiral captures total 1,684,224,000 bytes and are retained in the ignored
build-vulkan-gaussian-fix/spiral-{direct,staged} workspace folders. Their complete
SHA256 manifest and all four exact comparison logs are archived here. All other
frozen/actual Gaussian BMPs are included. No performance/FPS claim is made.
Exact static captures qualify this device/driver; cross-device parity is not
assumed. Existing committed golden bytes and unrelated report drafts are fixed.
For legacy audit alpha_sample rows, channels_gt2 is a fixed one-sample marker;
use actual/reference or max_error for the error. The JSON uses scalar errors.
''')
report = {
    'date': '2026-11-01', 'source_base': old['commit'],
    'branch': subprocess.check_output(['git', 'branch', '--show-current'], cwd=root, text=True).strip(),
    'device': {'name': 'AMD Radeon RX 9070 XT', 'vendor_id': 4098, 'device_id': 30032, 'driver_version': 8389024},
    'policy': {'gaussian_max_inclusive_framebuffer_px': 15,
               'selection': 'logical radius * render_scale', 'above_limit': 'Dual Kawase',
               'max_gaussian_taps': 31, 'max_bilinear_fetches_per_axis': 17,
               'fragment_push_bytes': 92, 'last_push_byte_exclusive': 108},
    'fixes': ['Gaussian associated RGB is unassociated only for the final normal alpha blend',
              'Gaussian ROI includes rounded AA pixel centers before kernel support at high DPI'],
    'audits': audits,
    'golden_qualification': {
        'correct_reference_cases': 36, 'reference_origin': 'independent full-image filtering and ordinary mask composite, frozen before either bug fix using the 15px policy',
        'scales': [1, 1.25, 1.5, 2, 3, 4], 'upload_modes': ['direct', 'staged'],
        'exact_corrected_frame_comparisons': 576, 'idle_cache_hits': 144,
        'pre_fix_compatibility_images': 8, 'pre_fix_exact_frame_comparisons': 64,
        'pre_fix_compatibility_origin': old['commit'],
        'spiral': {'items': '5000 -> 5003', 'frames_per_run': 180, 'exact_full_frame_comparisons': 720,
                   'width': 1360, 'height': 860, 'channels': 'RGBA8',
                   'variants': ['direct', 'direct cache', 'staged', 'staged cache'],
                   'reference_origin': '15px policy before either bug fix; 8-15px policy changes are intentional',
                   'raw_capture_files_retained': 360, 'raw_bytes': 360 * 1360 * 860 * 4,
                   'raw_capture_location': 'build-vulkan-gaussian-fix/spiral-{direct,staged}',
                   'archive_manifest': 'spiral-frame-sha256.csv'}},
    'gates': {'release': 'python tools/run_tests.py --vulkan --format --release: passed',
              'debug': 'python tools/run_tests.py --vulkan --format: passed',
              'native_cases_per_configuration': 33, 'sdl_golden_scenes_per_configuration': 22,
              'harfbuzz_off_sdl_off': 'both blur and Gaussian tests passed in direct/staged',
              'new_test_format': 'clang-format 22.1.3 --dry-run --Werror passed',
              'live': json.loads((work / 'live.json').read_text())},
    'preservation': {'old_test_oracle_files_byte_unchanged': 80,
                     'exception': 'tests/test_vulkan_blur.cpp: only 15px policy boundary cases, pair count, max-radius CPU case and status text; no tolerance weakening',
                     'old_golden_references_changed': False, 'unrelated_drafts_unchanged_and_untracked': old['drafts'],
                     'no_performance_claim': 'Functional and pixel qualification; background builds were active during live inspection'},
    'source_hash_kind': 'working-tree bytes at validation time',
    'candidate_sources_sha256': source_hashes, 'binary_sha256': binaries,
    'baseline_binary_sha256': baseline_binaries,
    'archive': {'path': archive.relative_to(root).as_posix(), 'bytes': archive.stat().st_size, 'sha256': sha(archive)},
}
(root / 'docs/perf/vulkan_gaussian_validation.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
(work / 'spiral-frame-sha256.csv').write_text(frame_csv, encoding='utf-8')
print('Sealed Gaussian validation report and evidence archive; all protected hashes verified')
