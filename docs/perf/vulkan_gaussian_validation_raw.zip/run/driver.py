from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
work = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'tools'))
from run_tests import import_msvc_env
import_msvc_env()
os.environ['VULKAN_SDK'] = 'E:/VulkanSDK/1.4.335.0'
os.environ['CMAKE_BUILD_PARALLEL_LEVEL'] = '3'
formatter = root / 'build-perf-review/format-tool/clang_format/data/bin/clang-format.exe'
os.environ['PATH'] = str(formatter.parent) + os.pathsep + os.environ['PATH']
libs = root / 'out/build/x64-release'
manifest = Path(os.environ['VSINSTALLDIR']) / 'VC/Tools/MSVC' / os.environ['VCToolsVersion'] / 'include/manifest/segmentheap.manifest'
system = ['kernel32', 'user32', 'gdi32', 'winmm', 'imm32', 'version', 'uuid', 'advapi32',
          'setupapi', 'shell32', 'hid', 'dinput8', 'uiautomationcore', 'comctl32', 'ole32',
          'oleaut32', 'winspool', 'comdlg32']
common = ['cl', '/nologo', '/std:c++20', '/EHsc', '/O2', '/Ob2', '/GL', '/MD', '/DNDEBUG',
          '/DPUFFERUI_ENABLE_VULKAN', '/DPUFFERUI_ENABLE_SDL3', '/DPUFFERUI_ENABLE_HARFBUZZ',
          '/DPUFFERUI_ASSET_DIR="' + (root / 'assets').as_posix() + '"',
          '/I' + str(root / 'vendored/stb'), '/I' + str(root / 'vendored/SDL/include'),
          '/I' + str(libs / 'vendored/SDL/include-revision'),
          '/I' + str(root / 'build-vulkan-compute/harfbuzz-src/src'),
          '/IE:/VulkanSDK/1.4.335.0/Include']
links = ['/link', '/LTCG', '/MANIFEST:EMBED', '/MANIFESTINPUT:' + str(manifest),
         str(libs / 'vendored/SDL/SDL3-static.lib'),
         str(libs / '_deps/pufferui_harfbuzz-build/harfbuzz.lib'),
         str(libs / '_deps/pufferui_harfbuzz-build/harfbuzz-gpu.lib'),
         'E:/VulkanSDK/1.4.335.0/Lib/vulkan-1.lib', *[name + '.lib' for name in system]]
baseline = json.loads((work / 'baseline.json').read_text())
for name in baseline['drafts']:
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == baseline['hashes'][name]
for name in baseline['tests']:
    if name != 'tests/test_vulkan_blur.cpp':
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == baseline['hashes'][name], name
def run(command, log):
    log.write('COMMAND ' + repr([str(x) for x in command]) + '\n'); log.flush()
    subprocess.run([str(x) for x in command], cwd=root, stdout=log, stderr=subprocess.STDOUT, check=True)
def compile(source, binary, include, log, extra=()):
    binary.parent.mkdir(exist_ok=True, parents=True)
    run([*common, '/I' + str(include), *extra, source,
         '/Fo' + str(binary.with_suffix('.obj')), '/Fe' + str(binary), *links], log)
mode = sys.argv[1]
with (work / (mode + '.log')).open('w', encoding='utf-8') as log:
    if mode == 'controls-before':
        binary = work / 'before/gaussian-controls.exe'
        compile(root / 'tests/test_vulkan_gaussian.cpp', binary, work / 'before/include', log)
        run([binary, '--capture-controls', work / 'compatibility-goldens'], log)
    elif mode == 'policy-reference':
        run([sys.executable, root / 'tools/compile_vulkan_shaders.py'], log)
        changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=root, text=True).splitlines()
        run([formatter, '-i', *[p for p in changed if Path(p).suffix in ['.inl', '.cpp', '.h']],
             'tests/test_vulkan_gaussian.cpp'], log)
        policy = work / 'policy15'
        policy.mkdir(exist_ok=True)
        source_hashes = {}
        for source in (root / 'include').rglob('*'):
            if source.is_file():
                rel = source.relative_to(root)
                target = policy / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
                source_hashes[rel.as_posix()] = hashlib.sha256(source.read_bytes()).hexdigest()
        (policy / 'source-sha256.json').write_text(json.dumps(source_hashes, indent=2) + '\n')
        compile(root / 'tests/test_vulkan_gaussian.cpp', policy / 'reference.exe', policy / 'include', log)
        run([policy / 'reference.exe', '--capture-reference', work / 'correct-goldens'], log)
        compile(work / 'policy_spiral.cpp', policy / 'spiral.exe', policy / 'include', log,
                ['/DPUFFERUI_NATIVE_TELEMETRY'])
        for upload in ['direct', 'staged']:
            run([policy / 'spiral.exe', '--capture', work / ('spiral-' + upload),
                 *(['--staged'] if upload == 'staged' else [])], log)
    elif mode == 'policy-spiral':
        policy = work / 'policy15'
        compile(work / 'policy_spiral.cpp', policy / 'spiral.exe', policy / 'include', log,
                ['/DPUFFERUI_NATIVE_TELEMETRY'])
        for upload in ['direct', 'staged']:
            run([policy / 'spiral.exe', '--capture', work / ('spiral-' + upload),
                 *(['--staged'] if upload == 'staged' else [])], log)
    elif mode == 'build':
        run([sys.executable, root / 'tools/compile_vulkan_shaders.py'], log)
        changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=root, text=True).splitlines()
        run([formatter, '-i', *[p for p in changed if Path(p).suffix in ['.inl', '.cpp', '.h']],
             'tests/test_vulkan_gaussian.cpp'], log)
        run(['cmake', '-S', root, '-B', libs, '-DPUFFERUI_WITH_VULKAN=ON'], log)
        run(['cmake', '--build', libs, '--target', 'pui_vulkan_gaussian_tests', 'pui_vulkan_blur_tests',
             'pui_showcase_vulkan', 'pui_demo', 'pui_vulkan_native_spiral_tests', '-j', '3'], log)
    elif mode == 'goldens':
        binary = libs / 'Release/pui_vulkan_gaussian_tests.exe'
        for upload in ['direct', 'staged']:
            extra = ['--staged'] if upload == 'staged' else []
            run([binary, '--compatibility', work / 'compatibility-goldens', *extra], log)
            run([binary, '--goldens', work / 'correct-goldens', '--capture-actual',
                 work / ('actual-' + upload), *extra], log)
        for upload in ['direct', 'staged']:
            for cache in [False, True]:
                run([libs / 'Release/pui_vulkan_native_spiral_tests.exe', '--reference',
                     work / ('spiral-' + upload), *(['--staged'] if upload == 'staged' else []),
                     *(['--cache'] if cache else [])], log)
    elif mode in ['release', 'debug']:
        run([sys.executable, root / 'tools/run_tests.py', '--vulkan', '--format',
             *(['--release'] if mode == 'release' else [])], log)
    elif mode == 'audit-after':
        binary = work / 'audit-after.exe'
        compile(root / 'build-vulkan-gaussian-audit/audit.cpp', binary, root / 'include', log)
        for upload in ['direct', 'staged']:
            directory = work / ('audit-' + upload)
            directory.mkdir(exist_ok=False)
            with (work / ('audit-' + upload + '.csv')).open('w', encoding='utf-8') as csv:
                run([binary, directory, *(['--staged'] if upload == 'staged' else [])], csv)
    elif mode == 'off':
        build = work / 'off-build'
        run(['cmake', '-S', root, '-B', build, '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release',
             '-DCMAKE_MSVC_DEBUG_INFORMATION_FORMAT=Embedded', '-DPUFFERUI_WITH_VULKAN=ON',
             '-DPUFFERUI_WITH_HARFBUZZ=OFF', '-DPUFFERUI_WITH_SDL3=OFF',
             '-DPUFFERUI_BUILD_EXAMPLES=OFF'], log)
        run(['cmake', '--build', build, '--target', 'pui_vulkan_blur_tests',
             'pui_vulkan_gaussian_tests', '-j', '3'], log)
        for target in ['pui_vulkan_blur_tests', 'pui_vulkan_gaussian_tests']:
            for extra in [[], ['--staged']]:
                run([build / ('Release/' + target + '.exe'), *extra], log)
    elif mode == 'debug-build':
        run(['cmake', '-S', root, '-B', root / 'out/build/x64-debug', '-DPUFFERUI_WITH_VULKAN=ON'], log)
        native = json.loads((libs / 'pufferui-vulkan-tests-Release.json').read_text())
        targets = sorted({case['target'] for case in native})
        run(['cmake', '--build', root / 'out/build/x64-debug', '--target', *targets,
             'pui_core_tests', 'pui_pump_tests', 'pui_perf_tests', 'pui_memory_tests',
             'pui_preparation_tests', 'pui_showcase_tests', 'pui_golden_tests',
             'pui_perf_pixels', 'pui_core_perf_pixels', '-j', '3'], log)
    else:
        raise ValueError(mode)
print(mode + ' passed; 80 original test/oracles and nine drafts unchanged', flush=True)
