from pathlib import Path
import hashlib
import json
import shutil
import subprocess

root = Path(__file__).resolve().parents[1]
work = Path(__file__).resolve().parent
assert not (work / 'baseline.json').exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == 'ab060b971c47e173ecad219034dcc52118c4eaf5'
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], cwd=root).strip()
paths = subprocess.check_output(['git', 'ls-files', 'include', 'src', 'examples', 'tests', 'CMakeLists.txt', 'AGENTS.md'], cwd=root, text=True).splitlines()
drafts = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', 'docs'], cwd=root, text=True).splitlines()
assert len(drafts) == 9
hashes = {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths + drafts}
for p in paths:
    if p.startswith('include/'):
        target = work / 'before' / p
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / p, target)
(work / 'baseline.json').write_text(json.dumps({'commit': 'ab060b971c47e173ecad219034dcc52118c4eaf5',
    'hashes': hashes, 'tests': [p for p in paths if p.startswith('tests/')], 'drafts': drafts}, indent=2) + '\n')
for name in ['pui_showcase_vulkan.exe', 'pui_vulkan_native_spiral_tests.exe']:
    shutil.copy2(root / 'out/build/x64-release/Release' / name, work / 'before' / name)
print(f'Frozen {len(paths)} tracked files, {sum(p.startswith("tests/") for p in paths)} test/oracles and {len(drafts)} unrelated drafts')
