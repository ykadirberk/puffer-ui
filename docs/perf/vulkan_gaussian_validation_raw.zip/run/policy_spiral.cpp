#define PUFFERUI_IMPLEMENTATION
#include <pufferui/vulkan.h>
#undef near
#undef far
#undef small
#include "../tests/test_vulkan_native_spiral.cpp"
