from pathlib import Path
import csv
import datetime
import hashlib
import json
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from measure_vulkan_gpu import Query, summarize

OUT = ROOT / "build-vulkan-default-repro/qualified-pdh"
OUT.mkdir(exist_ok=False)
binaries = {side: ROOT / f"build-vulkan-default-repro/qualified-timing/{side}.exe"
            for side in ("before", "after")}
receipt = dict(complete=False, runs=[], binaries={side: hashlib.sha256(path.read_bytes()).hexdigest()
                                               for side, path in binaries.items()},
               protocol="identical INTEGRATED before/after; per-PID PDH, separate engines/adapters; native VSync plus identical 60 Hz cap; visible is not foreground certification")
for repeat in range(3):
    for mode, flags in (("moving", []), ("idle", ["--idle"])):
        for side in (("before", "after") if repeat % 2 == 0 else ("after", "before")):
            stem = OUT / f"{mode}-{repeat}-{side}"
            query = Query()
            samples = []
            command = [str(binaries[side]), "--integrated", *flags, "--visible", "--vsync", "--hz", "60",
                       "--frames", "180", "--tiles", "5000"]
            start = time.perf_counter()
            with stem.with_suffix(".csv").open("w") as output, stem.with_suffix(".log").open("w") as error:
                process = subprocess.Popen(command, cwd=ROOT, stdout=output, stderr=error,
                                           creationflags=subprocess.CREATE_NO_WINDOW)
                try:
                    query.sample(process.pid)
                    while process.poll() is None:
                        if time.perf_counter() - start > 90:
                            process.kill()
                            raise TimeoutError("bounded own-process GPU probe")
                        time.sleep(0.5)
                        for sample in query.sample(process.pid):
                            samples.append(dict(elapsed=time.perf_counter()-start, pid=process.pid,
                                                utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), **sample))
                finally:
                    query.close(query.handle)
                assert process.wait() == 0
            stem.with_suffix(".pdh.json").write_text(json.dumps(samples, indent=2) + "\n")
            rows = list(csv.DictReader(stem.with_suffix(".csv").read_text().splitlines()))
            assert len(rows) == 180
            entry = dict(mode=mode, side=side, repeat=repeat, command=command, summary=summarize(samples),
                         focused_frames=sum(int(row["focused"]) for row in rows),
                         visible_frames=sum(int(row["visible"]) for row in rows), frames=len(rows))
            receipt["runs"].append(entry)
            print(mode, side, repeat, "done", flush=True)
            (OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
receipt["complete"] = True
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
