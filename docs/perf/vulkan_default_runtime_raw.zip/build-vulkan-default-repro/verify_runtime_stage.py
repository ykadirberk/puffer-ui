from pathlib import Path
import subprocess
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "build-vulkan-default-repro/runtime-checks"
OUT.mkdir(exist_ok=True)
receipt = dict(complete=False, runs=[])
for mode in ("release", "debug"):
    for name, flags in (("pui_vulkan_example_font_tests", []),
                        ("pui_vulkan_painter_work_tests", []),
                        ("pui_vulkan_painter_work_tests", ["--staged"]),
                        ("pui_vulkan_compute_default_tests", []),
                        ("pui_vulkan_compute_default_tests", ["--staged"])):
        command = [str(ROOT / f"out/build/x64-{mode}/{mode.title()}/{name}.exe"), *flags]
        print(mode, name, flags, flush=True)
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=240)
        stem = f"{mode}-{name}" + ("-staged" if flags else "")
        (OUT / f"{stem}.log").write_text(result.stdout + result.stderr)
        receipt["runs"].append(dict(command=command, exit=result.returncode, output=result.stdout + result.stderr))
        (OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
        print(result.stdout + result.stderr, flush=True)
        if result.returncode: raise SystemExit(result.returncode)
receipt["complete"] = True
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
