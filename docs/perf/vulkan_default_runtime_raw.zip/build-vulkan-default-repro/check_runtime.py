from pathlib import Path
import csv
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "build-vulkan-default-repro/runtime"
OUT.mkdir(parents=True, exist_ok=False)
current = ROOT / "out/build/x64-release/Release/pui_showcase_vulkan.exe"
previous = ROOT / "build-vulkan-compute-default/baseline/showcase.exe"
cases = [("default", current, []), ("sdf-slug", current, ["--vulkan-painter", "sdf", "--vector-text"]),
         ("sdf-bitmap", current, ["--vulkan-painter", "sdf"]), ("previous-default", previous, [])]
receipt = {}
for name, binary, flags in cases:
    command = [str(binary), "--selftest", "--no-script", "--page", "0", "--frames", "16", "--no-hud",
               "--screenshot", str(OUT / (name + ".bmp")), "--perf-trace", str(OUT / (name + ".csv")), *flags]
    result = subprocess.run(command, capture_output=True, text=True, cwd=ROOT, timeout=60)
    (OUT / (name + ".log")).write_text(result.stdout + result.stderr, encoding="utf8")
    assert result.returncode == 0, (name, result.stdout, result.stderr)
    rows = list(csv.DictReader((OUT / (name + ".csv")).open()))
    receipt[name] = dict(command=command, exit=result.returncode,
                        binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                        image_sha256=hashlib.sha256((OUT / (name + ".bmp")).read_bytes()).hexdigest(),
                        glyph_upload_bytes=sum(float(r.get("glyph_upload_bytes", 0)) for r in rows),
                        glyph_resident_batches=sum(float(r.get("glyph_resident_batches", 0)) for r in rows),
                        gpu_sdf_batches=sum(float(r.get("gpu_sdf_batches", 0)) for r in rows))
    print(name, receipt[name]["image_sha256"], receipt[name]["glyph_upload_bytes"], flush=True)
assert receipt["default"]["image_sha256"] == receipt["sdf-slug"]["image_sha256"]
assert receipt["default"]["image_sha256"] == receipt["previous-default"]["image_sha256"]
assert receipt["default"]["image_sha256"] != receipt["sdf-bitmap"]["image_sha256"]
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print("Current default equals explicit Slug and previous Slug; bitmap differs", flush=True)
