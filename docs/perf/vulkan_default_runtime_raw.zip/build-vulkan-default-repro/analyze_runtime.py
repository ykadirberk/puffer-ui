from pathlib import Path
import csv
import json
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from compare_vulkan_integrated import percentile
from compare_vulkan_program import window_cpu

OUT = ROOT / "build-vulkan-default-repro"
receipt = dict(complete=True, protocol="recover summaries from all 24 complete immutable raw runs; initial sandbox PDH read failed after timing; elevated read-only probe is separate", runs=[], cohorts=[])
frames = []
for path in sorted((OUT / "qualified-extra").glob("*.csv")):
    mode, repeat, side = path.stem.rsplit("-", 2)
    rows = list(csv.DictReader(path.read_text().splitlines()))
    assert len(rows) == 120
    values = [float(row["total_ms"]) for row in rows]
    entry = dict(mode=mode, repeat=int(repeat), side=side, frames=len(rows),
                 mean_ms=statistics.mean(values), max_ms=max(values),
                 gpu_ms=sum(float(row["completed_gpu_ms"]) for row in rows),
                 peak_frames=sorted(range(len(values)), key=lambda i: values[i], reverse=True)[:10],
                 **window_cpu(path.with_suffix(".log").read_text()))
    receipt["runs"].append(entry)
    frames.extend(dict(mode=mode, side=side, repeat=int(repeat), **row) for row in rows)
for mode in ("overview-compute", "overview-sdf-control"):
    for side in ("before", "after"):
        rows = [row for row in frames if (row["mode"], row["side"]) == (mode, side)]
        values = [float(row["total_ms"]) for row in rows]
        entry = dict(mode=mode, side=side, frames=len(rows), mean_ms=statistics.mean(values),
                     p99_ms=percentile(values, .99), max_ms=max(values),
                     gpu_ms_per_frame=sum(float(row["completed_gpu_ms"]) for row in rows) / len(rows))
        receipt["cohorts"].append(entry)
        print(mode, side, entry, flush=True)
(OUT / "qualified-extra/receipt-recovered.json").write_text(json.dumps(receipt, indent=2) + "\n")
spiral = json.loads((OUT / "qualified-timing/measurement.json").read_text())
for c in spiral["cohorts"]:
    print(c["painter"], c["upload"], c["mode"], c["side"],
          "mean", round(c["mean_ms"], 4), "GPU", round(c["gpu_ms_per_frame"], 4),
          "p99", round(c["p99_ms"], 4), "max", round(c["max_ms"], 4))
pdh = json.loads((OUT / "qualified-pdh/receipt.json").read_text())
for mode in ("moving", "idle"):
    for side in ("before", "after"):
        runs = [r for r in pdh["runs"] if (r["mode"], r["side"]) == (mode, side)]
        keys = sorted({key for r in runs for key in r["summary"]})
        for key in keys:
            if "engtype_3D" not in key and "dedicated" not in key: continue
            stats = [r["summary"][key] for r in runs if key in r["summary"]]
            n = sum(x["samples"] for x in stats)
            print("PDH", mode, side, key, sum(x["mean"]*x["samples"] for x in stats)/n,
                  "max", max(x["max"] for x in stats), "samples", n)
for side in ("before", "after"):
    path = OUT / f"profile-{side}/integrated_tiles/gpu-stages.csv"
    rows = list(csv.DictReader(path.read_text().splitlines()))
    totals = {}
    for row in rows: totals[row["stage"]] = totals.get(row["stage"], 0) + float(row["nanoseconds"])/1e6
    print("PROFILE", side, {k:round(v/180,6) for k,v in totals.items()})
