from pathlib import Path
import csv
import hashlib
import io
import json
import subprocess

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "build-vulkan-default-repro/qualified-pixels"
OUT.mkdir(exist_ok=False)
previous = json.loads((ROOT / "docs/perf/vulkan_compute_default_final.json").read_text())["qualification"]
GOLDEN = ROOT / "build-vulkan-locality/final-20261027-234723/pixels"
binaries = {side: ROOT / f"build-vulkan-default-repro/qualified-timing/{side}.exe"
            for side in ("before", "after")}

def hashes():
    result = {}
    for label, frames in previous["captures"].items():
        result[label] = {}
        for name, expected in frames.items():
            value = hashlib.sha256((GOLDEN / label / "rgba" / name).read_bytes()).hexdigest()
            assert value == expected, (label, name, "frozen reference changed")
            result[label][name] = value
    return result

receipt = dict(complete=False, captures_before=hashes(), cases=[], exact_comparisons=0)
for upload in ("direct", "staged"):
    for mode in ("moving", "idle", "local"):
        label = f"{upload}-{mode}"
        flags = (["--staged"] if upload == "staged" else [])
        flags += [] if mode == "moving" else ["--idle" if mode == "idle" else "--local-change"]
        for case, side, policy in (("baseline", "before", []), ("candidate", "after", []),
                                   ("fine-control", "after", ["--no-program-cache"])):
            command = [str(binaries[side]), "--integrated", *policy, *flags,
                       "--reference", str(GOLDEN / label / "rgba")]
            result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=180)
            (OUT / f"{label}-{case}.csv").write_text(result.stdout)
            (OUT / f"{label}-{case}.log").write_text(result.stderr)
            assert result.returncode == 0, result.stderr
            rows = list(csv.DictReader(io.StringIO(result.stdout)))
            assert len(rows) == 180
            receipt["cases"].append(dict(label=label, case=case, command=command, frames=180, exit=0))
            receipt["exact_comparisons"] += 180
            print(label, case, "180 exact", flush=True)
            (OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
receipt["captures_after"] = hashes()
assert receipt["captures_before"] == receipt["captures_after"]
receipt["complete"] = True
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
