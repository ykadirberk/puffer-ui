from pathlib import Path
import csv
import gzip
import hashlib
import json
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "build-vulkan-default-repro"
GATE = ROOT / "build-vulkan-integrated/final-gate/full-20261028-222332-11012"
OUT = ROOT / "docs/perf"
PREFIX = "vulkan_default_runtime"

def read(path): return json.loads(path.read_text())
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()

suite = read(GATE / "validation.json")
assert suite["complete"] and not suite["changed_sources"]
assert all(run["exit"] == 0 for run in suite["runs"])
for name, expected in suite["source_before"].items():
    assert digest(ROOT / name) == expected, name
timing = read(WORK / "qualified-timing/measurement.json")
extra = read(WORK / "qualified-extra/receipt-recovered.json")
pdh = read(WORK / "qualified-pdh/receipt.json")
pixels = read(WORK / "qualified-pixels/receipt.json")
delivered = read(WORK / "delivered/receipt.json")
checks = read(WORK / "runtime-checks/receipt.json")
smoke = read(WORK / "live-smoke/receipt.json")
assert all(entry["complete"] for entry in (timing, extra, pdh, pixels, delivered, checks, smoke))
assert pixels["exact_comparisons"] == 3240 and pixels["captures_before"] == pixels["captures_after"]
assert delivered["same_machine_code"] and delivered["cwd"]["same_image"]
previous = read(ROOT / "docs/perf/vulkan_compute_default_final.json")
preserved = previous["preserved_unrelated"]
for name, expected in preserved.items(): assert digest(ROOT / name) == expected, name

frames = []
for path in sorted((WORK / "qualified-timing").glob("*.csv")):
    painter, upload, mode, repeat, side = path.stem.split("-")
    for row in csv.DictReader(path.open()):
        frames.append(dict(dataset="spiral", painter=painter, upload=upload, mode=mode, repeat=repeat, side=side, **row))
for path in sorted((WORK / "qualified-extra").glob("*.csv")):
    mode, repeat, side = path.stem.rsplit("-", 2)
    for row in csv.DictReader(path.open()):
        frames.append(dict(dataset="overview", mode=mode, repeat=repeat, side=side, **row))
assert len(frames) == 28800
assert all(int(row["draw_memory_allocations"]) == int(row["draw_resource_creations"]) == 0 for row in frames)
assert all(int(row["readbacks"]) == 0 for row in frames)
fields = list(dict.fromkeys(key for row in frames for key in row))
frame_file = OUT / (PREFIX + "_frames.csv.gz")
assert not frame_file.exists()
with gzip.open(frame_file, "wt", encoding="utf8", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    writer.writerows(frames)

peak_neighbors = {}
for upload in ("direct", "staged"):
    for mode in ("moving", "idle", "local"):
        selected = [r for r in timing["runs"] if r["upload"] == upload and r["mode"] == mode]
        neighbors = set()
        for run in selected:
            for peak in run["peak_frames"]:
                index = peak["frame"] if isinstance(peak, dict) else peak
                neighbors.update(x for x in (int(index)-1, int(index), int(index)+1) if 0 <= x < 180)
        peak_neighbors[f"{upload}-{mode}"] = sorted(neighbors)

profiles = {}
for side in ("before", "after"):
    totals = {}
    for row in csv.DictReader((WORK / f"profile-{side}/integrated_tiles/gpu-stages.csv").open()):
        totals[row["stage"]] = totals.get(row["stage"], 0) + float(row["nanoseconds"])/1e6
    profiles[side] = dict(milliseconds_per_frame={key:value/180 for key,value in totals.items()})

patch = subprocess.check_output(["git", "diff", "HEAD", "--", "AGENTS.md", "CMakeLists.txt", "README.md",
                                 "include", "src", "examples", "tests", "docs/harfbuzz.md", "docs/vulkan_gpu_painter.md"], cwd=ROOT)
(WORK / "candidate.patch").write_bytes(patch)
members = set(WORK.glob("*.py")) | set(WORK.glob("*.patch"))
for directory in ("qualified-timing", "qualified-extra", "qualified-pdh", "qualified-pixels", "runtime-checks", "runtime", "cwd", "cwd-after-font", "cwd-final", "delivered", "live-smoke", "profile-before", "profile-after"):
    for path in (WORK / directory).rglob("*"):
        if path.is_file() and path.suffix in (".csv", ".gz", ".log", ".json", ".bmp", ".inl"):
            members.add(path)
for directory in WORK.glob("*-prototype*"):
    if directory.is_dir():
        members.update(p for p in directory.iterdir() if p.suffix in (".csv", ".log", ".json"))
members.update((GATE / name) for name in ("validation.json", "release.log", "debug.log"))
raw_file = OUT / (PREFIX + "_raw.zip")
assert not raw_file.exists()
with zipfile.ZipFile(raw_file, "w", zipfile.ZIP_DEFLATED, compresslevel=7) as archive:
    for path in sorted(members): archive.write(path, path.relative_to(ROOT).as_posix())
with zipfile.ZipFile(raw_file, "r") as archive:
    assert len(archive.namelist()) == len(set(archive.namelist()))
    assert archive.testzip() is None
    member_count = len(archive.namelist())

registry = read(ROOT / "out/build/x64-release/pufferui-vulkan-tests-Release.json")
assert len(registry) == len(read(ROOT / "out/build/x64-debug/pufferui-vulkan-tests-Debug.json"))
result = dict(complete=True, base_commit=previous["qualification"].get("baseline_commit"),
              suite=suite, native_cases_per_configuration=len(registry), measurement=timing,
              overview=extra, gpu_usage=pdh, pixels=pixels, peak_neighbors=peak_neighbors,
              profiles=profiles, runtime=delivered, runtime_checks=checks, live_smoke=smoke,
              font_before=read(WORK / "cwd/receipt.json"), font_after=read(WORK / "cwd-final/receipt.json"),
              preserved_unrelated=preserved, timed_frames=len(frames), paced_frames=2160,
              limits=["Hidden acceptance timings and unfocused PDH are not foreground FPS certification",
                      "Native SDF remains faster than compute-first on animated Overview",
                      "Some p99/max frametimes regressed; every cold and peak frame is retained",
                      "VRAM peaks did not improve; Linux runtime not exercised on this Windows host"],
              artifacts={"frames":dict(path=frame_file.name, sha256=digest(frame_file)),
                         "raw":dict(path=raw_file.name, sha256=digest(raw_file), members=member_count)})
result["base_commit"] = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
target = OUT / (PREFIX + "_final.json")
assert not target.exists()
target.write_text(json.dumps(result, indent=2) + "\n")
print("Sealed", len(frames), "timed frames;", pixels["exact_comparisons"], "exact images;", len(registry), "native cases/configuration;", member_count, "raw members", flush=True)
