from pathlib import Path
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from run_tests import import_msvc_env
import_msvc_env()
os.environ["VULKAN_SDK"] = "E:/VulkanSDK/1.4.335.0"
with (ROOT / "build-vulkan-default-repro/runtime-stage-build.log").open("w", encoding="utf8") as log:
    commands = [[sys.executable, "tools/compile_vulkan_shaders.py"]]
    commands += [["cmake", "--build", str(ROOT / f"out/build/x64-{mode}"), "--target",
                  "pui_showcase_vulkan", "pui_demo", "pui_vulkan_program_bench",
                  "pui_vulkan_compute_default_tests", "pui_vulkan_example_font_tests",
                  "pui_vulkan_painter_work_tests", "-j", "3"] for mode in ("release", "debug")]
    for command in commands:
        print("Runtime stage:", command[1:4], flush=True)
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        if result.returncode:
            print("Build failed; inspect runtime-stage-build.log", flush=True)
            raise SystemExit(result.returncode)
print("Runtime stage built in Release and Debug", flush=True)
