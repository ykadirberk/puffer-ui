from pathlib import Path
import csv
import hashlib
import json
import os
import re
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from run_tests import import_msvc_env
import_msvc_env()
os.environ["VULKAN_SDK"] = "E:/VulkanSDK/1.4.335.0"
OUT = ROOT / "build-vulkan-default-repro/delivered"
OUT.mkdir(exist_ok=False)
command = ["cmake", "--build", str(ROOT / "out/build/x64-release"), "--target", "pui_vulkan_program_bench", "-j", "3"]
with (OUT / "build.log").open("w") as log:
    result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
assert result.returncode == 0

def text_section(path):
    raw = path.read_bytes()
    offset = struct.unpack_from("<I", raw, 0x3c)[0]
    assert raw[offset:offset+4] == b"PE\0\0"
    sections, optional = struct.unpack_from("<H", raw, offset+6)[0], struct.unpack_from("<H", raw, offset+20)[0]
    base = offset + 24 + optional
    for index in range(sections):
        at = base + index*40
        if raw[at:at+8].rstrip(b"\0") == b".text":
            size, position = struct.unpack_from("<II", raw, at+16)
            return hashlib.sha256(raw[position:position+size]).hexdigest()
    raise ValueError("no text section")

frozen = ROOT / "build-vulkan-default-repro/qualified-timing/after.exe"
delivered = ROOT / "out/build/x64-release/Release/pui_vulkan_program_bench.exe"
receipt = dict(frozen_sha256=hashlib.sha256(frozen.read_bytes()).hexdigest(),
               delivered_sha256=hashlib.sha256(delivered.read_bytes()).hexdigest(),
               frozen_text_sha256=text_section(frozen), delivered_text_sha256=text_section(delivered))
receipt["same_machine_code"] = receipt["frozen_text_sha256"] == receipt["delivered_text_sha256"]
header = (ROOT / "include/pufferui/impl/vulkan_shaders.inl").read_text()
receipt["shader_modules"] = {}
for symbol in ("vulkan_integrated_paint", "vulkan_glyph_source_fill", "vulkan_integrated_frag", "vulkan_sdf_frag"):
    match = re.search(r"static constexpr u32 " + symbol + r"\[\] = \{(.*?)\};", header, re.S)
    assert match, symbol
    words = [int(value, 16) for value in re.findall(r"0x[0-9a-fA-F]+", match[1])]
    data = struct.pack("<" + "I"*len(words), *words)
    assert data in frozen.read_bytes() and data in delivered.read_bytes(), symbol
    receipt["shader_modules"][symbol] = hashlib.sha256(data).hexdigest()
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
assert receipt["same_machine_code"], "test-only include unexpectedly changed production code; requalify the binary"
binary = ROOT / "out/build/x64-release/Release/pui_showcase_vulkan.exe"
result = subprocess.run([str(binary), "--vulkan-device-info"], cwd=binary.parent, capture_output=True, text=True, timeout=30)
(OUT / "device-info.log").write_text(result.stdout + result.stderr)
assert result.returncode == 0
print(result.stdout + result.stderr, flush=True)
subprocess.run([sys.executable, str(ROOT / "build-vulkan-default-repro/check_cwd.py"), "cwd-final"], cwd=ROOT, check=True)
cwd = json.loads((ROOT / "build-vulkan-default-repro/cwd-final/receipt.json").read_text())
assert cwd["same_image"]
assert cwd["project-root"]["image_sha256"] == "005789d507ac4d8cca552ce38629e8a432c53bb3693b936c49de948abe4592dc"
receipt["complete"] = True
receipt["cwd"] = cwd
receipt["standard_default_counters"] = {}
for label in ("project-root", "visual-studio-output"):
    rows = list(csv.DictReader((ROOT / f"build-vulkan-default-repro/cwd-final/{label}.csv").open()))
    counts = {name:sum(float(row[name]) for row in rows) for name in
              ("glyph_upload_bytes", "glyph_resident_batches", "gpu_sdf_batches")}
    assert all(value > 0 for value in counts.values())
    receipt["standard_default_counters"][label] = counts
receipt["device_info"] = result.stdout + result.stderr
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
