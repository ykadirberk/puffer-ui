from pathlib import Path
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from run_tests import import_msvc_env

import_msvc_env()
os.environ["VULKAN_SDK"] = "E:/VulkanSDK/1.4.335.0"
log_name = sys.argv[1] if len(sys.argv) > 1 else "route-stage-build.log"
with (ROOT / "build-vulkan-default-repro" / log_name).open("w", encoding="utf8") as log:
    commands = [("shaders", [sys.executable, "tools/compile_vulkan_shaders.py"])]
    commands += [(mode, ["cmake", "--build", str(ROOT / f"out/build/x64-{mode}"), "--target",
                         "pui_vulkan_program_bench", "pui_vulkan_compute_default_tests", "-j", "3"])
                 for mode in ("release", "debug")]
    for name, command in commands:
        print("Building route stage:", name, flush=True)
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        if result.returncode:
            print("Build failed; inspect route-stage-build.log", flush=True)
            raise SystemExit(result.returncode)
print("Route stage builds in Release and Debug", flush=True)
