from pathlib import Path
import csv
import hashlib
import io
import json
import shutil
import statistics
import subprocess

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "build-vulkan-default-repro/overview-before"
OUT.mkdir(parents=True, exist_ok=False)
current = ROOT / "out/build/x64-release/Release/pui_vulkan_program_bench.exe"
previous = ROOT / "build-vulkan-compute-default/baseline/program.exe"
for name, source in (("before-showcase.exe", ROOT / "out/build/x64-release/Release/pui_showcase_vulkan.exe"),
                     ("current.exe", current), ("previous.exe", previous)):
    shutil.copy2(source, OUT / name)
cases = [("compute-default", OUT / "current.exe", ["--integrated"]),
         ("native-first", OUT / "previous.exe", ["--integrated"]),
         ("sdf-slug", OUT / "current.exe", ["--sdf", "--vector-text"])]
receipt = {"complete": False, "protocol": "Diagnostic only; 14-item Overview, HUD on, 120 frames, "
           "no Add, no readback, unpaced hidden WSI; all first/peak frames retained", "runs": []}
for repeat in range(3):
    order = cases if repeat % 2 == 0 else list(reversed(cases))
    for name, binary, flags in order:
        command = [str(binary), *flags, "--tiles", "14", "--tour", "--hud", "--no-add", "--frames", "120"]
        result = subprocess.run(command, capture_output=True, text=True, cwd=ROOT, timeout=60)
        stem = OUT / f"{repeat}-{name}"
        stem.with_suffix(".csv").write_text(result.stdout)
        stem.with_suffix(".log").write_text(result.stderr)
        assert result.returncode == 0, result.stderr
        rows = list(csv.DictReader(io.StringIO(result.stdout)))
        assert len(rows) == 120
        times = [float(row["total_ms"]) for row in rows]
        summary = dict(name=name, repeat=repeat, command=command, mean_ms=statistics.mean(times),
                       max_ms=max(times), gpu_ms_per_frame=sum(float(row["completed_gpu_ms"]) for row in rows)/len(rows),
                       glyph_bytes=sum(int(row["glyph_upload_bytes"]) for row in rows),
                       binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
        receipt["runs"].append(summary)
        print(name, repeat, summary["mean_ms"], summary["gpu_ms_per_frame"], flush=True)
receipt["complete"] = True
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
