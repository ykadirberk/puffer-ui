from pathlib import Path
import csv
import datetime
import hashlib
import io
import json
import os
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from compare_vulkan_integrated import percentile, retain_native
from compare_vulkan_program import window_cpu
from measure_vulkan_gpu import Query, summarize

OUT = ROOT / "build-vulkan-default-repro/qualified-extra"
OUT.mkdir(exist_ok=False)
binaries = {side: ROOT / f"build-vulkan-default-repro/qualified-timing/{side}.exe"
            for side in ("before", "after")}
receipt = dict(complete=False, runs=[], pdh=[], binaries={side: hashlib.sha256(path.read_bytes()).hexdigest()
                                                      for side, path in binaries.items()})
all_frames = []
for repeat in range(6):
    for mode, painter in (("overview-compute", ["--integrated"]),
                          ("overview-sdf-control", ["--sdf", "--vector-text"])):
        paired = {}
        for side in (("before", "after") if repeat % 2 == 0 else ("after", "before")):
            command = [str(binaries[side]), *painter, "--tiles", "14", "--tour", "--hud",
                       "--no-add", "--frames", "120"]
            stem = OUT / f"{mode}-{repeat}-{side}"
            stdout, stderr, wall, cpu = retain_native(command, stem)
            rows = list(csv.DictReader(io.StringIO(stdout)))
            assert len(rows) == 120
            assert all(int(row["draw_memory_allocations"]) == int(row["draw_resource_creations"]) == 0 for row in rows)
            paired[side] = [tuple(row[key] for key in ("count", "draws", "vertices", "indices")) for row in rows]
            values = [float(row["total_ms"]) for row in rows]
            peaks = sorted(range(len(rows)), key=lambda f: values[f], reverse=True)[:10]
            entry = dict(mode=mode, side=side, repeat=repeat, frames=len(rows), command=command,
                         mean_ms=statistics.mean(values), p99_ms=percentile(values, .99),
                         max_ms=max(values), peak_frames=peaks, wall_ms=wall,
                         gpu_ms=sum(float(row["completed_gpu_ms"]) for row in rows), **cpu, **window_cpu(stderr))
            receipt["runs"].append(entry)
            all_frames.extend(dict(mode=mode, side=side, repeat=repeat, **row) for row in rows)
            print(mode, side, repeat, entry["mean_ms"], entry["gpu_ms"] / len(rows), flush=True)
        assert paired["before"] == paired["after"]

for repeat in range(3):
    for mode, flags in (("moving", []), ("idle", ["--idle"])):
        for side in (("before", "after") if repeat % 2 == 0 else ("after", "before")):
            stem = OUT / f"pdh-{mode}-{repeat}-{side}"
            query = Query()
            samples = []
            command = [str(binaries[side]), "--integrated", *flags, "--visible", "--vsync", "--hz", "60",
                       "--frames", "180", "--tiles", "5000"]
            start = time.perf_counter()
            with stem.with_suffix(".csv").open("w") as output, stem.with_suffix(".log").open("w") as error:
                process = subprocess.Popen(command, cwd=ROOT, stdout=output, stderr=error,
                                           creationflags=subprocess.CREATE_NO_WINDOW)
                try:
                    query.sample(process.pid)
                    while process.poll() is None:
                        if time.perf_counter() - start > 90:
                            process.kill()
                            raise TimeoutError("bounded own-process GPU probe")
                        time.sleep(0.5)
                        for sample in query.sample(process.pid):
                            samples.append(dict(elapsed=time.perf_counter()-start, pid=process.pid,
                                                utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), **sample))
                finally:
                    query.close(query.handle)
                assert process.wait() == 0
            stem.with_suffix(".pdh.json").write_text(json.dumps(samples, indent=2) + "\n")
            rows = list(csv.DictReader(stem.with_suffix(".csv").read_text().splitlines()))
            assert len(rows) == 180
            entry = dict(mode=mode, side=side, repeat=repeat, command=command, summary=summarize(samples),
                         focused_frames=sum(int(row["focused"]) for row in rows),
                         visible_frames=sum(int(row["visible"]) for row in rows), frames=len(rows))
            receipt["pdh"].append(entry)
            print("PDH", mode, side, repeat, "done", flush=True)
            (OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")

fields = list(dict.fromkeys(key for row in all_frames for key in row))
with (OUT / "frames.csv").open("w", newline="") as output:
    writer = csv.DictWriter(output, fieldnames=fields)
    writer.writeheader()
    writer.writerows(all_frames)
receipt["complete"] = True
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
