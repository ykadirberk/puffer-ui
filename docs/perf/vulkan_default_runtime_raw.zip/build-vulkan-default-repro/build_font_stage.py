from pathlib import Path
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from run_tests import import_msvc_env

import_msvc_env()
os.environ["VULKAN_SDK"] = "E:/VulkanSDK/1.4.335.0"
with (ROOT / "build-vulkan-default-repro/font-stage-build.log").open("w", encoding="utf8") as log:
    for mode in ("release", "debug"):
        print("Building font stage:", mode, flush=True)
        result = subprocess.run(["cmake", "--build", str(ROOT / f"out/build/x64-{mode}"), "--target",
                                 "pui_vulkan_example_font_tests", "pui_showcase_vulkan", "pui_demo", "-j", "3"],
                                cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        if result.returncode:
            print("Build failed; inspect font-stage-build.log", flush=True)
            raise SystemExit(result.returncode)
print("Font stage builds in Release and Debug", flush=True)
