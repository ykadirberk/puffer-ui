from pathlib import Path
import csv
import hashlib
import io
import json
import shutil
import statistics
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "build-vulkan-default-repro" / (sys.argv[1] if len(sys.argv) > 1 else "route-prototype")
OUT.mkdir(parents=True, exist_ok=False)
for side, source in (("before", ROOT / "build-vulkan-default-repro/overview-before/current.exe"),
                     ("after", ROOT / "out/build/x64-release/Release/pui_vulkan_program_bench.exe")):
    shutil.copy2(source, OUT / (side + ".exe"))
receipt = dict(complete=False, runs=[])
for repeat in range(3):
    for scenario, flags in (("overview", ["--tiles", "14", "--tour", "--hud", "--no-add", "--frames", "120"]),
                            ("spiral", ["--tiles", "5000", "--frames", "180"])):
        for side in (("before", "after") if repeat % 2 == 0 else ("after", "before")):
            binary = OUT / (side + ".exe")
            command = [str(binary), "--integrated", *flags]
            result = subprocess.run(command, capture_output=True, text=True, cwd=ROOT, timeout=60)
            stem = OUT / f"{repeat}-{scenario}-{side}"
            stem.with_suffix(".csv").write_text(result.stdout)
            stem.with_suffix(".log").write_text(result.stderr)
            assert result.returncode == 0, result.stderr
            rows = list(csv.DictReader(io.StringIO(result.stdout)))
            values = [float(row["total_ms"]) for row in rows]
            summary = dict(scenario=scenario, side=side, repeat=repeat, command=command,
                           frames=len(rows), mean_ms=statistics.mean(values), max_ms=max(values),
                           gpu_ms_per_frame=sum(float(row["completed_gpu_ms"]) for row in rows)/len(rows),
                           binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
            receipt["runs"].append(summary)
            print(scenario, side, repeat, summary["mean_ms"], summary["gpu_ms_per_frame"], flush=True)
receipt["complete"] = True
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
