from pathlib import Path
import csv
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "build-vulkan-default-repro" / (sys.argv[1] if len(sys.argv) > 1 else "cwd")
OUT.mkdir(parents=True, exist_ok=False)
binary = ROOT / "out/build/x64-release/Release/pui_showcase_vulkan.exe"
receipt = {}
for name, directory in (("project-root", ROOT), ("visual-studio-output", binary.parent)):
    command = [str(binary), "--selftest", "--no-script", "--page", "0", "--frames", "16", "--no-hud",
               "--screenshot", str(OUT / (name + ".bmp")), "--perf-trace", str(OUT / (name + ".csv"))]
    result = subprocess.run(command, capture_output=True, text=True, cwd=directory, timeout=60)
    (OUT / (name + ".log")).write_text(result.stdout + result.stderr, encoding="utf8")
    assert result.returncode == 0, result.stdout + result.stderr
    rows = list(csv.DictReader((OUT / (name + ".csv")).open()))
    receipt[name] = dict(command=command, cwd=str(directory),
        image_sha256=hashlib.sha256((OUT / (name + ".bmp")).read_bytes()).hexdigest(),
        glyph_upload_bytes=sum(float(r.get("glyph_upload_bytes", 0)) for r in rows))
    print(name, receipt[name]["image_sha256"], receipt[name]["glyph_upload_bytes"], flush=True)
receipt["same_image"] = receipt["project-root"]["image_sha256"] == receipt["visual-studio-output"]["image_sha256"]
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print("Working-directory images equal:", receipt["same_image"])
